import SounioIntervalExtended

/-!
ADR-019 followup: exact four-corner endpoint products, then reciprocal/division.
The additive model remains unchanged. Infinity is not a finite member. The
endpoint product handles 0*infinity as a set-bound case before arithmetic.
No IEEE instruction, decimal conversion or signed-zero encoding is modeled.
-/
namespace Sounio.IntervalExtended.MulDiv
open Std Sounio.IntervalExtended

/-- Total endpoint order; the rational order is the canonical Std order. -/
def ELe : ExtendedRat → ExtendedRat → Prop
  | .negInf,_ => True
  | _,.posInf => True
  | .finite a,.finite b => a ≤ b
  | _,_ => False

instance (a b : ExtendedRat) : Decidable (ELe a b) := by
  cases a <;> cases b <;> unfold ELe <;> infer_instance

def minE (a b : ExtendedRat) := if ELe a b then a else b

def maxE (a b : ExtendedRat) := if ELe a b then b else a

theorem le_refl (a : ExtendedRat) : ELe a a := by
  cases a with
  | finite q => exact Rat.le_refl
  | _ => trivial

theorem le_trans (a b c : ExtendedRat) (hab : ELe a b) (hbc : ELe b c) : ELe a c := by
  cases a <;> cases b <;> cases c <;> simp_all [ELe] <;> exact Rat.le_trans hab hbc

theorem le_total (a b : ExtendedRat) : ELe a b ∨ ELe b a := by
  cases a <;> cases b <;> simp_all [ELe] <;> grind

theorem min_le_left (a b : ExtendedRat) : ELe (minE a b) a := by
  unfold minE;split
  · exact le_refl _
  · rename_i h;exact (le_total a b).resolve_left h

theorem min_le_right (a b : ExtendedRat) : ELe (minE a b) b := by
  unfold minE;split
  · assumption
  · exact le_refl _

theorem le_max_left (a b : ExtendedRat) : ELe a (maxE a b) := by
  unfold maxE;split
  · assumption
  · exact le_refl _

theorem le_max_right (a b : ExtendedRat) : ELe b (maxE a b) := by
  unfold maxE;split
  · exact le_refl _
  · rename_i h;exact (le_total a b).resolve_left h

theorem le_min (a b c : ExtendedRat) (hab : ELe a b) (hac : ELe a c) : ELe a (minE b c) := by
  unfold minE;split <;> assumption

theorem max_le (a b c : ExtendedRat) (hac : ELe a c) (hbc : ELe b c) : ELe (maxE a b) c := by
  unfold maxE;split <;> assumption

theorem min_mono (a b c d : ExtendedRat) (hac : ELe a c) (hbd : ELe b d) :
    ELe (minE a b) (minE c d) :=
  le_min _ _ _ (le_trans _ _ _ (min_le_left _ _) hac)
    (le_trans _ _ _ (min_le_right _ _) hbd)

theorem max_mono (a b c d : ExtendedRat) (hac : ELe a c) (hbd : ELe b d) :
    ELe (maxE a b) (maxE c d) :=
  max_le _ _ _ (le_trans _ _ _ hac (le_max_left _ _))
    (le_trans _ _ _ hbd (le_max_right _ _))

/-- Extended endpoint product. Zero is handled before infinite sign selection. -/
def mulE : ExtendedRat → ExtendedRat → ExtendedRat
  | .finite x,.finite y => .finite (x*y)
  | .finite x,.negInf => if x=0 then .finite 0 else if 0<x then .negInf else .posInf
  | .negInf,.finite x => if x=0 then .finite 0 else if 0<x then .negInf else .posInf
  | .finite x,.posInf => if x=0 then .finite 0 else if 0<x then .posInf else .negInf
  | .posInf,.finite x => if x=0 then .finite 0 else if 0<x then .posInf else .negInf
  | .negInf,.negInf => .posInf
  | .posInf,.posInf => .posInf
  | _,_ => .negInf

theorem mulE_comm (a b : ExtendedRat) : mulE a b = mulE b a := by
  cases a <;> cases b <;> simp [mulE,Rat.mul_comm]

theorem mul_mono_nonneg (a x y : ExtendedRat) (ha : ELe (.finite 0) a)
    (hxy : ELe x y) : ELe (mulE a x) (mulE a y) := by
  cases a with
  | negInf => simp [ELe] at ha
  | finite a =>
    have hf : ∀ p q : Rat, p ≤ q → a*p ≤ a*q :=
      fun _ _ h => Rat.mul_le_mul_of_nonneg_left h ha
    cases x <;> cases y <;> simp_all [ELe,mulE] <;> grind [ELe]
  | posInf => cases x <;> cases y <;> simp_all [ELe,mulE] <;> grind [ELe]

theorem mul_mono_nonpos (a x y : ExtendedRat) (ha : ELe a (.finite 0))
    (hxy : ELe x y) : ELe (mulE a y) (mulE a x) := by
  cases a with
  | posInf => simp [ELe] at ha
  | finite a =>
    have hf : ∀ p q : Rat, p ≤ q → a*q ≤ a*p :=
      fun p q h => Sounio.IntervalFinite.mul_le_of_nonpos a p q ha h
    cases x <;> cases y <;> simp_all [ELe,mulE] <;> grind [ELe]
  | negInf => cases x <;> cases y <;> simp_all [ELe,mulE] <;> grind [ELe]

theorem scale_bounds (a c d y : ExtendedRat) (hcy : ELe c y) (hyd : ELe y d) :
    ELe (minE (mulE a c) (mulE a d)) (mulE a y) ∧
    ELe (mulE a y) (maxE (mulE a c) (mulE a d)) := by
  by_cases ha : ELe (.finite 0) a
  · exact ⟨le_trans _ _ _ (min_le_left _ _) (mul_mono_nonneg a c y ha hcy),
      le_trans _ _ _ (mul_mono_nonneg a y d ha hyd) (le_max_right _ _)⟩
  · have hn := (le_total (.finite 0) a).resolve_left ha
    exact ⟨le_trans _ _ _ (min_le_right _ _) (mul_mono_nonpos a y d hn hyd),
      le_trans _ _ _ (mul_mono_nonpos a c y hn hcy) (le_max_left _ _)⟩

def low4 (a b c d : ExtendedRat) := minE (minE a b) (minE c d)
def high4 (a b c d : ExtendedRat) := maxE (maxE a b) (maxE c d)

theorem product_corners (a b c d x y : ExtendedRat)
    (hax : ELe a x) (hxb : ELe x b) (hcy : ELe c y) (hyd : ELe y d) :
    ELe (low4 (mulE a c) (mulE a d) (mulE b c) (mulE b d)) (mulE x y) ∧
    ELe (mulE x y) (high4 (mulE a c) (mulE a d) (mulE b c) (mulE b d)) := by
  have ha := scale_bounds a c d y hcy hyd
  have hb := scale_bounds b c d y hcy hyd
  have h := scale_bounds y a b x hax hxb
  have hx : ELe (minE (mulE a y) (mulE b y)) (mulE x y) ∧
      ELe (mulE x y) (maxE (mulE a y) (mulE b y)) := by
    simpa only [mulE_comm] using h
  exact ⟨le_trans _ _ _ (min_mono _ _ _ _ ha.1 hb.1) hx.1,
    le_trans _ _ _ hx.2 (max_mono _ _ _ _ ha.2 hb.2)⟩

/-- Infinite singletons and reversed/invalid endpoint pairs have no members. -/
def ofEndpoints : ExtendedRat → ExtendedRat → Interval
  | .negInf,.posInf => entire
  | .negInf,.finite b => make none (some b)
  | .finite a,.posInf => make (some a) none
  | .finite a,.finite b => make (some a) (some b)
  | _,_ => .empty

theorem ofEndpoints_contains (a b : ExtendedRat) (x : Rat)
    (ha : ELe a (.finite x)) (hb : ELe (.finite x) b) : Contains (ofEndpoints a b) x := by
  cases a <;> cases b <;> simp_all [ELe,ofEndpoints]
  all_goals exact make_contains _ _ _ ⟨ha,hb⟩

theorem member_lower (i : Interval) (x : Rat) (hx : Contains i x) : ELe (lowerEndpoint i) (.finite x) := by
  cases i with
  | empty => exact False.elim hx
  | span a b hp => cases a <;> exact hx.1

theorem member_upper (i : Interval) (x : Rat) (hx : Contains i x) : ELe (.finite x) (upperEndpoint i) := by
  cases i with
  | empty => exact False.elim hx
  | span a b hp => cases b <;> exact hx.2

def mul (i j : Interval) : Interval :=
  match i,j with
  | .empty,_ => .empty
  | _,.empty => .empty
  | _,_ =>
    ofEndpoints
      (low4 (mulE (lowerEndpoint i) (lowerEndpoint j)) (mulE (lowerEndpoint i) (upperEndpoint j))
        (mulE (upperEndpoint i) (lowerEndpoint j)) (mulE (upperEndpoint i) (upperEndpoint j)))
      (high4 (mulE (lowerEndpoint i) (lowerEndpoint j)) (mulE (lowerEndpoint i) (upperEndpoint j))
        (mulE (upperEndpoint i) (lowerEndpoint j)) (mulE (upperEndpoint i) (upperEndpoint j)))

theorem mul_contains (i j : Interval) (x y : Rat) (hx : Contains i x) (hy : Contains j y) :
    Contains (mul i j) (x*y) := by
  cases i with
  | empty => exact False.elim hx
  | span a b hp =>
    cases j with
    | empty => exact False.elim hy
    | span c d hq =>
      exact ofEndpoints_contains _ _ _
        (product_corners _ _ _ _ _ _ (member_lower _ _ hx) (member_upper _ _ hx)
          (member_lower _ _ hy) (member_upper _ _ hy)).1
        (product_corners _ _ _ _ _ _ (member_lower _ _ hx) (member_upper _ _ hx)
          (member_lower _ _ hy) (member_upper _ _ hy)).2

end Sounio.IntervalExtended.MulDiv
