#!/bin/bash
# Root-approved transport-only fallback; same exact source03 and one worker admission controller.
set -euo pipefail
h=/tmp/SIO183-complement-controller03
b=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026-complement03
seal=fdd7e7f6302ba7529cb590146f597c9417717522614000873984709363aa7756
exec 9> "$h/ATTEMPT03.lock"
flock -n 9
mkdir "$h/ATTEMPT03"
a=$h/ATTEMPT03
exec > >(tee "$a/stdout.log") 2> >(tee "$a/stderr.log" >&2)
trap 'echo $? > "$a/STATUS"' EXIT
date -u +%FT%TZ > "$a/STARTED_AT"
printf '%s  %s\n' 3482bc735b9b7231d2d125ad3523d002c1f9ed5e071fbeff800acd9ef8b3b042 "$h/source03.tar.gz" | sha256sum -c -
# Reconciliation first; fail if any earlier source/stage/admission already exists.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$b" <<'WORKER'
set -euo pipefail
b=$1
[[ $(id -u) == 1000 && ! -e $b/JOB_ID && ! -e $b/SUBMISSION_ATTEMPT && ! -e $b/source03 && ! -e $b/focused03 ]]
mkdir -p "$b"
mkdir "$b/source03"
WORKER
# Serial mkdir, extraction, manifest verification; no SSH alias inside workspace.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xzf - -C "$b/source03" < "$h/source03.tar.gz"
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$b" "$seal" <<'WORKER' > "$a/worker.source.verify"
set -euo pipefail
b=$1;seal=$2
printf '%s  %s\n' "$seal" "$b/source03/FILES.sha256" | sha256sum -c -
cd "$b/source03"
sha256sum -c FILES.sha256
WORKER
date -u +%FT%TZ > "$a/STAGED_VERIFIED_AT"
# Exact approved worker controller: >=20GiB effective, <=7 preexisting, one sbatch, synced ID.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash "$b/source03/worker_submit_once.sh" "$b" "$seal" > "$a/worker.submit.stdout" 2> "$a/worker.submit.stderr"
job=$(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- cat "$b/JOB_ID")
[[ $job =~ ^[0-9]+$ ]]
printf '%s\n' "$job" > "$h/JOB_ID"
sync "$h/JOB_ID"
printf 'SUBMITTED_ONCE_JOB=%s\n' "$job"
