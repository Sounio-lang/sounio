bash bin/souc check tests/stdlib/stats/test_ols_diag_e2e.sio 
SOUNIO_SOUC_ENGINE=lean_single
SOUNIO_STDLIB_PATH=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026-complement03/source03/after/stdlib
MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
