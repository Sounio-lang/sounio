bash bin/souc compile tests/stdlib/particle_physics/test_particle_physics_core.sio -o /scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026-complement03/focused03/before/lean_single/test_particle_physics_core.elf 
SOUNIO_SOUC_ENGINE=lean_single
SOUNIO_STDLIB_PATH=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026-complement03/source03/before/stdlib
MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
