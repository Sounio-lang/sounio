bash bin/souc check tests/stdlib/stats/test_ols_madaros_e2e.sio 
SOUNIO_SOUC_ENGINE=madaros
SOUNIO_STDLIB_PATH=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026-complement03/source03/before/stdlib
MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
