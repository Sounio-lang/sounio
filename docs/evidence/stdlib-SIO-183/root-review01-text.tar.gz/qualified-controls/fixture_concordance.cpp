// SIO183 focused C++23 concordance; reuse canonical existing independent references.
// Shared Royston coefficient approximation is disclosed; long-double quantiles/W identity differ.
#define main sio183_prior_shapiro_main
#include "../tests/reference/shapiro_reference.cpp"
#undef main
#define main sio183_prior_ols_main
#include "../tests/reference/ols_influence_reference.cpp"
#undef main
#include <sstream>
#include <filesystem>
long double read_value(const std::string& text,const std::string& key) {
 auto p=text.find(key+"=");if(p==std::string::npos)throw std::runtime_error("missing:"+key);
 std::size_t used=0;auto v=std::stold(text.substr(p+key.size()+1),&used);
 if(used==0||!std::isfinite(v))throw std::runtime_error("invalid:"+key);return v;
}
std::string read_log(const std::filesystem::path& p){std::ifstream f(p);if(!f)throw std::runtime_error("missing log:"+p.string());std::ostringstream s;s<<f.rdbuf();return s.str();}
void close_value(const std::string& s,const std::string& key,long double expected) {
 const auto got=read_value(s,key);const auto limit=2.0e-6L*(1+std::abs(expected));
 if(std::abs(got-expected)>limit)throw std::runtime_error("printed concordance:"+key);
 std::cout<<key<<" got="<<got<<" C++23="<<expected<<" printed_limit="<<limit<<"\n";
}
int main(int argc,char**argv) try {
 if(argc!=2)return 2;const std::filesystem::path logs=argv[1];
 const auto sh=read_log(logs/"test_shapiro_e2e.native.stdout");
 const auto a=reference({1,2,3,4,5}),b=reference({2,3,4,5,6,7,8,9,10,11}),c=reference({1,1.1,1.2,1.3,1.5,2,3,5,8,13});
 close_value(sh,"n5_w",a.w);close_value(sh,"n5_p",a.p);close_value(sh,"n10_w",b.w);close_value(sh,"n10_p",b.p);close_value(sh,"skew_w",c.w);close_value(sh,"skew_p",c.p);
 A x{},y{},yt{};for(int i=0;i<5;i++)x[i]=i+1;y[0]=1;y[1]=2;y[2]=3;y[3]=4;y[4]=10;yt[0]=2;yt[1]=4;yt[2]=5;yt[3]=4;yt[4]=5;
 const Fit f=qr(x,y,5),t=qr(x,yt,5);const auto slope=f.b1*f.ys/f.xs,intercept=f.ya-slope*f.xa+f.ys*f.b0;
 std::array<long double,5> cook{};for(int i=0;i<5;i++){const Fit del=qr(x,y,5,i);for(int j=0;j<5;j++){const auto z=difference(f,del,x[j])/f.sigma;cook[i]+=z*z/2;}}
 const auto resid=reference({1,0,-1,-2,2});const auto tslope=t.b1*t.ys/t.xs,tinter=t.ya-tslope*t.xa+t.ys*t.b0;
 long double mean=0,sst=0,sse=0;for(int i=0;i<5;i++)mean+=yt[i]/5;for(int i=0;i<5;i++){sst+=(yt[i]-mean)*(yt[i]-mean);const auto e=t.e[i]*t.ys;sse+=e*e;}const auto r2=1-sse/sst;
 for(const auto* name:{"test_ols_diag_e2e","test_ols_madaros_e2e"}){const auto s=read_log(logs/(std::string(name)+".native.stdout"));close_value(s,"cook_slope",slope);if(std::string(name)=="test_ols_diag_e2e"){close_value(s,"cook_intercept",intercept);close_value(s,"d1",cook[0]);close_value(s,"d5",cook[4]);close_value(s,"resid_shapiro_p",resid.p);}close_value(s,"max_cooks",*std::max_element(cook.begin(),cook.end()));close_value(s,"ols_slope",tslope);close_value(s,"ols_intercept",tinter);close_value(s,"ols_r2",r2);close_value(s,"resid_shapiro_w",resid.w);}
 const auto m=read_log(logs/"measurement_four_sources.native.stdout");close_value(m,"total_error",std::sqrt(29.L));
 std::cout<<"SIO183_CPP23_FIXTURE_CONCORDANCE_OK\n";return 0;
} catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
