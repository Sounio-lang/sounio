#!/bin/bash
# Root-approved transport-only fallback; same exact source02 and one worker admission controller.
set -euo pipefail
h=/tmp/SIO183-host-controller03
b=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-shapes-20261026
seal=4a91755d62416765059a0d7acb2c6bb30892d5c6e4315b86e0480b09797dbf0f
exec 9> "$h/ATTEMPT03.lock"
flock -n 9
mkdir "$h/ATTEMPT03"
a=$h/ATTEMPT03
exec > >(tee "$a/stdout.log") 2> >(tee "$a/stderr.log" >&2)
trap 'echo $? > "$a/STATUS"' EXIT
date -u +%FT%TZ > "$a/STARTED_AT"
printf '%s  %s\n' a377beb5d48dcceeb2a9f52885b1a28efce250eb7c1fc0853d0f175fc4de1eed "$h/source02.tar.gz" | sha256sum -c -
# Reconciliation first; fail if any earlier source/stage/admission already exists.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$b" <<'WORKER'
set -euo pipefail
b=$1
[[ $(id -u) == 1000 && ! -e $b/JOB_ID && ! -e $b/SUBMISSION_ATTEMPT && ! -e $b/source02 && ! -e $b/focused02 ]]
mkdir -p "$b"
mkdir "$b/source02"
WORKER
# Serial mkdir, extraction, manifest verification; no SSH alias inside workspace.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xzf - -C "$b/source02" < "$h/source02.tar.gz"
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$b" "$seal" <<'WORKER' > "$a/worker.source.verify"
set -euo pipefail
b=$1;seal=$2
printf '%s  %s\n' "$seal" "$b/source02/FILES.sha256" | sha256sum -c -
cd "$b/source02"
sha256sum -c FILES.sha256
WORKER
date -u +%FT%TZ > "$a/STAGED_VERIFIED_AT"
# Exact approved worker controller: >=20GiB effective, <=7 preexisting, one sbatch, synced ID.
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash "$b/source02/worker_submit_once.sh" "$b" "$seal" > "$a/worker.submit.stdout" 2> "$a/worker.submit.stderr"
job=$(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- cat "$b/JOB_ID")
[[ $job =~ ^[0-9]+$ ]]
printf '%s\n' "$job" > "$h/JOB_ID"
sync "$h/JOB_ID"
printf 'SUBMITTED_ONCE_JOB=%s\n' "$job"
