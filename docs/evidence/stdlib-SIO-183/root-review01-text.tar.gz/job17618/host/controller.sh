#!/bin/bash
# Root-authorized existing-ELF-only diagnostic. No compiler or source inputs are invoked.
set -euo pipefail
h=/tmp/SIO183-core-native-diag01
b=/scratch/sounio-stdlib-inference-scale-20261024/SIO183-core-native-diag01
seal=8f9bb03bc088610117dfef1c83a53c5cee693b214555b0aeafcbcf6cbeaf009f
exec 9> "$h/ATTEMPT.lock"
flock -n 9
mkdir "$h/ATTEMPT"
a=$h/ATTEMPT
exec > >(tee "$a/stdout.log") 2> >(tee "$a/stderr.log" >&2)
trap 'echo $? > "$a/STATUS"' EXIT
printf '%s  %s\n' "$seal" "$h/compare_core.sbatch" | sha256sum -c -
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$b" <<'WORKER'
set -euo pipefail
[[ $(id -u) == 1000 && ! -e $1 ]]
mkdir "$1"
WORKER
for n in compare_core.sbatch worker_submit_once.sh;do
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tee "$b/$n" < "$h/$n" > /dev/null
done
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash "$b/worker_submit_once.sh" "$b" "$seal" > "$a/worker.stdout" 2> "$a/worker.stderr"
job=$(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- cat "$b/JOB_ID")
[[ $job =~ ^[0-9]+$ ]]
printf '%s\n' "$job" > "$h/JOB_ID"
sync "$h/JOB_ID"
printf 'SUBMITTED_DIAGNOSTIC_ONCE_JOB=%s\n' "$job"
