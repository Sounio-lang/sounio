#!/bin/bash
# Prepared only: root approval required. Operational worker controller; exactly one sbatch call.
set -euo pipefail
b=$1;seal=$2
[[ $seal =~ ^[0-9a-f]{64}$ && $(id -u) == 1000 ]]
[[ ! -e $b/JOB_ID && ! -e $b/artifacts ]]
mkdir "$b/SUBMISSION_ATTEMPT"
a=$b/SUBMISSION_ATTEMPT
exec > >(tee "$a/stdout.log") 2> >(tee "$a/stderr.log" >&2)
trap 'echo $? > "$a/CONTROLLER_STATUS"' EXIT
date -u +%FT%TZ > "$a/STARTED_AT"
printf '%s  %s\n' "$seal" "$b/compare_core.sbatch" | sha256sum -c - > "$a/script.presubmit.verify"
[[ $(id -u) == 1000 ]]
id;date -u +%FT%TZ
kb=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo);effective=$((kb*1024));seen=0
p=/sys/fs/cgroup$(awk -F: '$1==0 {print $3}' /proc/self/cgroup)
while [[ $p == /sys/fs/cgroup* ]];do
 if [[ -f $p/memory.max ]];then
  max=$(cat "$p/memory.max");used=$(cat "$p/memory.current")
  printf 'cgroup=%s max=%s current=%s\n' "$p" "$max" "$used"
  if [[ $max != max ]];then [[ $max =~ ^[0-9]+$ && $used =~ ^[0-9]+$ ]];free=$((max-used));((free<effective)) && effective=$free;seen=1;fi
 fi
 [[ $p == /sys/fs/cgroup ]] && break;p=${p%/*}
done
[[ $seen == 1 && $effective -ge 21474836480 ]]
printf 'effective_headroom_bytes=%s\n' "$effective"
df -Pk /scratch
[[ $(df -Pk /scratch | awk 'NR==2 {print $4}') -ge 20971520 ]]
squeue -u sounio -h -o '%i|%j|%T|%P' > "$a/SQUEUE.before.txt"
cat "$a/SQUEUE.before.txt"
[[ $(awk 'END {print NR}' "$a/SQUEUE.before.txt") -le 7 ]]
[[ -z $(grep '|SIO183-core-compare|' "$a/SQUEUE.before.txt" || true) ]]
printf '%s  %s\n' a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3 /scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready 81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90 /scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node | sha256sum -c -
date -u +%FT%TZ > "$a/SBATCH_CALL_STARTED_AT"
# Any ambiguity requires readback, never retry this call.
sbatch --parsable "$b/compare_core.sbatch" "$seal" > "$a/RAW_SUBMISSION" 2> "$a/sbatch.stderr"
job=$(cat "$a/RAW_SUBMISSION");[[ $job =~ ^[0-9]+$ ]]
printf '%s\n' "$job" > "$b/JOB_ID"
sync "$b/JOB_ID"
scontrol show job "$job" > "$a/SLURM_ADMISSION.txt"
printf 'SUBMITTED_ONCE_JOB=%s\n' "$job"
