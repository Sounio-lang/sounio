#!/bin/bash
set -euo pipefail
H=/tmp/SIO282-nativewire01
mkdir "$H/EFFECTIVE_PREFLIGHT"
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s >"$H/EFFECTIVE_PREFLIGHT/resources.txt" 2>"$H/EFFECTIVE_PREFLIGHT/stderr.txt" <<'RESOURCE'
set -euo pipefail
[[ $(id -u) == 1000 ]]
id;date -u +%FT%TZ
mem=$(awk '/MemAvailable:/ {print $2*1024}' /proc/meminfo)
# /proc value may be rendered scientific by awk; use Bash integer conversion.
kb=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
effective=$((kb*1024))
p=/sys/fs/cgroup$(awk -F: '$1==0 {print $3}' /proc/self/cgroup)
seen=0
while [[ $p == /sys/fs/cgroup* ]];do
 if [[ -f $p/memory.max ]];then
  max=$(cat "$p/memory.max");used=$(cat "$p/memory.current")
  printf 'cgroup=%s max=%s current=%s\n' "$p" "$max" "$used"
  if [[ $max != max ]];then [[ $max =~ ^[0-9]+$ && $used =~ ^[0-9]+$ ]];headroom=$((max-used));((headroom<effective)) && effective=$headroom;seen=1;fi
 fi
 [[ $p == /sys/fs/cgroup ]] && break
 p=${p%/*}
done
[[ $seen == 1 ]]
printf 'effective_memory_headroom_bytes=%s\n' "$effective"
[[ $effective -ge 21474836480 ]]
df -Pk /scratch
disk=$(df -Pk /scratch | awk 'NR==2 {print $4}')
printf 'scratch_headroom_kib=%s\n' "$disk"
[[ $disk -ge 20971520 ]]
squeue -u sounio -h -o '%i|%j|%T|%P'
# Conservatively bound ALL jobs for UID1000, stronger than sprint-only <=8.
count=$(squeue -u sounio -h -o '%i' | awk 'END {print NR}')
printf 'all_uid1000_jobs=%s\n' "$count"
[[ $count -le 8 ]]
echo EFFECTIVE_PREFLIGHT_PASS
RESOURCE
sha256sum /tmp/SIO282-nativewire01-host_submit.stage04.sh >"$H/EFFECTIVE_PREFLIGHT/controller.sha256"
echo 'e0518195e5491f6ffff02dbff17527be50a8d2b2ba49ce511e094653c2889e2e  /tmp/SIO282-nativewire01-host_submit.stage04.sh' | sha256sum -c -
bash /tmp/SIO282-nativewire01-host_submit.stage04.sh
