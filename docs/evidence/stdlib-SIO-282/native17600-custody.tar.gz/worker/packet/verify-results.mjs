import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const [out,raw]=process.argv.slice(2),read=n=>fs.readFileSync(`${out}/${n}`,'utf8'),json=n=>JSON.parse(read(n));
const elfsha=n=>crypto.createHash('sha256').update(fs.readFileSync(`${out}/${n}`)).digest('hex');
for(const kind of ['source','project'])for(const op of ['check','compile','run']){
 const name=`${kind}-${op}`,r=json(`${name}.json`);assert.equal(r.verdict,'OK',name);assert.equal(r.engine.boundary_collector,'madaros-raw-ast-v1');
 assert.equal(r.hashes.compiler_sha256,'a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3');
 if(op!=='check')assert.equal(r.hashes.elf_sha256,elfsha(`${kind}-compile.elf`),`${name}: run receipt must bind retained identical compile ELF`);
 if(op==='run')assert.equal(read(`${name}.stdout`).trim().split('\n').at(-1),'Hello, Sounio!');
 const trace=read(`${name}.trace`);assert(trace.includes(`${raw} --science-boundary-closure`),name);
 assert(trace.includes('node ')&&trace.includes('/tools/science_boundary/attestor.mjs'),name);
 if(op==='check')assert(trace.includes(`${raw} --check `),name);else assert(trace.includes(`${raw} build `),name);
 assert(!new RegExp('exec (?:timeout [^\\n]* )?[^\\n ]*/bin/madaros-linux-x86_64(?: |$)','m').test(trace),`${name}: cache execution`);
}
const neg=json('candidate-evaluate.json');assert.equal(neg.verdict,'UNKNOWN');assert.equal(neg.engine.boundary_collector,'madaros-raw-ast-v1');
assert.equal(read('candidate-evaluate.status').trim(),'21');assert.equal(read('candidate-wrapper.status').trim(),'1');assert(!fs.existsSync(`${out}/candidate.elf`));
assert.equal(fs.statSync(`${out}/python-denied.nul`).size,0);
for(const [name,marker]of [['core','SCIENCE_BOUNDARY_CORE_PASS 34'],['closure','SCIENCE_BOUNDARY_CLOSURE_OPERATIONAL_PASS tests=67'],['policy','# pass 30'],['cli','SCIENCE_BOUNDARY_ATTESTOR_PASS 28']])assert(read(`${name}.stdout`).includes(marker),name);
console.log('NATIVE_WIRE_METADATA_RESULTS_PASS source/project check/compile/run; candidate UNKNOWN21; zero Python attempts; 159 controls');
