#!/usr/bin/env bash
# BASH_ENV logging only; no gate, route, compiler or timeout changes.
if [[ -n ${NATIVE_WIRE_TRACE_FILE:-} ]];then
 exec 19>>"$NATIVE_WIRE_TRACE_FILE"
 export BASH_XTRACEFD=19
 PS4="+nativewire pid=\$BASHPID source=\${BASH_SOURCE[0]} line=\$LINENO "
 set -x
fi
