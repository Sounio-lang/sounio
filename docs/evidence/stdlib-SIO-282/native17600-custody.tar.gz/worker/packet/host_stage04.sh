#!/bin/bash
set -euo pipefail
HOST=/tmp/SIO282-nativewire01
WS=/workspace/.tmp/SIO282-nativewire01
BASE=/scratch/sounio-stdlib-inference-scale-20261024/SIO282-nativewire01
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
W=(kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
mkdir "$HOST/FREEZE_STAGE04"
exec > >(tee "$HOST/FREEZE_STAGE04/stdout.log") 2> >(tee "$HOST/FREEZE_STAGE04/stderr.log" >&2)
trap 'echo $? >"$HOST/FREEZE_STAGE04/STATUS"' EXIT
"${R[@]}" bash -c 'set -euo pipefail;B=$1;[[ $(id -u) == 1000 ]];df -Pk /scratch;free -k;[[ $(df -Pk /scratch | awk "NR==2 {print \$4}") -gt 20971520 ]];mkdir "$B/stage04";cp -a "$B/stage02/source" "$B/stage02/fixtures" "$B/stage04/";mkdir "$B/stage04/packet"' nativewire "$BASE"
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- tar -cf - -C "$WS/packet.stage04" . |
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xf - -C "$BASE/stage04/packet"
"${R[@]}" bash -c 'set -euo pipefail;B=$1;N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node;(cd "$B/packet";sha256sum -c PACKET.sha256);sha256sum -c "$B/packet/ENGINES.sha256";sha256sum -c "$B/packet/NODE_RUNTIME_BASELINE.sha256";"$N" "$B/packet/catalog.mjs" verify "$B/source" "$B/packet/SOURCE.json" "$B/SOURCE.stage.json";"$N" "$B/packet/catalog.mjs" verify "$B/fixtures" "$B/packet/FIXTURES.json" "$B/FIXTURES.stage.json";bash "$B/packet/toolchain_manifest.sh" "$B/WRAPPER_TOOLCHAIN.stage.sha256";sha256sum -c "$B/WRAPPER_TOOLCHAIN.stage.sha256";sha256sum "$B/packet/PACKET.sha256" "$B/packet/worker.sbatch" "$B/packet/toolchain_manifest.sh";echo STAGE04_NOT_SUBMITTED' nativewire "$BASE/stage04" >"$HOST/FREEZE_STAGE04/worker.txt"
"${W[@]}" bash -c 'set -euo pipefail;P=$1;W=/workspace/sounio-boundary-node-20261026;N=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node;"$N" "$P/catalog.mjs" select "$W" b81b5bcf447e441e9cb45806d7451c6b104882ec "$P/SOURCE.after-stage04.json";cmp "$P/packet.stage04/SOURCE.json" "$P/SOURCE.after-stage04.json";echo WORKSPACE_CLEAN_SOURCE_IDENTICAL' nativewire "$WS"
