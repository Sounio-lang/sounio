// Operational source/artifact identity only; no scientific numerical oracle.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const sha=(b,alg='sha256')=>crypto.createHash(alg).update(b).digest('hex');
const blob=b=>sha(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b]),'sha1');
function inventory(root){
 const rows=[];
 function visit(rel){for(const name of fs.readdirSync(path.join(root,rel)).sort()){
  const r=rel?`${rel}/${name}`:name,p=path.join(root,r),s=fs.lstatSync(p);
  if(s.isDirectory())visit(r);
  else {assert(s.isFile()||s.isSymbolicLink(),`unsupported type ${r}`);const b=s.isSymbolicLink()?Buffer.from(fs.readlinkSync(p)):fs.readFileSync(p);
   rows.push({path:r,mode:s.isSymbolicLink()?'120000':(s.mode&0o777).toString(8).padStart(6,'0'),git_blob:blob(b),sha256:sha(b),bytes:b.length,...(s.isSymbolicLink()?{target:b.toString()}: {})});}
 }}visit('');return rows.sort((a,b)=>a.path.localeCompare(b.path,'en'));
}
const [cmd,root,arg,out]=process.argv.slice(2);
if(cmd==='select'){
 const head=arg, selects=['stdlib','scripts/lib','tools/science_boundary','bin/souc','bin/madaros','bin/madaros-linux-x86_64.gz','bin/madaros-linux-x86_64.sha256','tests/run-pass/hello.sio'];
 const git=(...a)=>execFileSync('git',['-C',root,...a],{maxBuffer:64*1024*1024});
 assert.equal(git('rev-parse','HEAD').toString().trim(),head);assert.equal(git('status','--porcelain=v1').length,0);
 const entries=git('ls-tree','-rz',head,'--',...selects).toString().split('\0').filter(Boolean).map(line=>{
  const m=/^(\d+) blob ([0-9a-f]{40})\t([\s\S]+)$/.exec(line);assert(m,line);const [,mode,id,rel]=m;
  const p=path.join(root,rel),s=fs.lstatSync(p),b=mode==='120000'?Buffer.from(fs.readlinkSync(p)):fs.readFileSync(p);assert.equal(blob(b),id,rel);
  return {path:rel,mode:mode==='100755'?'000755':mode==='100644'?'000644':mode,git_blob:id,sha256:sha(b),bytes:b.length,...(mode==='120000'?{target:b.toString()}: {})};
 }).sort((a,b)=>a.path.localeCompare(b.path,'en'));
 assert(entries.some(x=>x.path==='tools/science_boundary/core.mjs'));assert(entries.length>0);
 fs.writeFileSync(out,JSON.stringify({head,selects,entries},null,2)+'\n');
}else if(cmd==='verify'||cmd==='verify-materialized'){
 const expected=JSON.parse(fs.readFileSync(arg)),actual=inventory(root);let base=actual;
 if(cmd==='verify-materialized'){
  const names=['bin/madaros-linux-x86_64','bin/.madaros-linux-x86_64.verified'];const extra=actual.filter(x=>names.includes(x.path));assert.equal(extra.length,2);
  const want=fs.readFileSync(path.join(root,'bin/madaros-linux-x86_64.sha256'),'utf8').trim().split(/\s+/)[0];assert.equal(extra.find(x=>x.path===names[0]).sha256,want);
  const stat=execFileSync('bash',['-c','source "$1/scripts/lib/materialize_madaros_prebuilt.sh"; _sounio_madaros_stat_inode_mtime_ctime "$1/bin/madaros-linux-x86_64"','wire',root],{encoding:'utf8'}).trim();
  const elf=extra.find(x=>x.path===names[0]);assert.equal(elf.mode,'000755');
  assert.equal(fs.readFileSync(path.join(root,names[1]),'utf8'),`${want} ${elf.bytes} ${stat}\n`);
  base=actual.filter(x=>!names.includes(x.path));fs.writeFileSync(out+'.generated.json',JSON.stringify(extra,null,2)+'\n');
 }
 assert.deepEqual(base,expected.entries);fs.writeFileSync(out,JSON.stringify({head:expected.head,entries:actual,tracked_equal:true},null,2)+'\n');
}else if(cmd==='snapshot')fs.writeFileSync(out,JSON.stringify({entries:inventory(root)},null,2)+'\n');
else throw Error('unknown catalogue mode');
