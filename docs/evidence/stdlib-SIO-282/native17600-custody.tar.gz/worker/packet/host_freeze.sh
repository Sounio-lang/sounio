#!/bin/bash
# Durable t560 prepare/stage only. NEVER submits a job.
set -euo pipefail
HOST=/tmp/SIO282-nativewire01
WS=/workspace/.tmp/SIO282-nativewire01
WT=/workspace/sounio-boundary-node-20261026
BASE=/scratch/sounio-stdlib-inference-scale-20261024/SIO282-nativewire01/stage02
HEAD=b81b5bcf447e441e9cb45806d7451c6b104882ec
W=(kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
WI=(kubectl -n beagle exec -i sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
mkdir -p "$HOST"
mkdir "$HOST/FREEZE_ATTEMPT02"
exec > >(tee "$HOST/FREEZE_ATTEMPT02/stdout.log") 2> >(tee "$HOST/FREEZE_ATTEMPT02/stderr.log" >&2)
trap 'echo $? >"$HOST/FREEZE_ATTEMPT02/STATUS"' EXIT
"${R[@]}" bash -c 'id;df -Pk /scratch;free -k;squeue -u sounio -h -o "%i %j %T";[[ $(id -u) == 1000 ]];[[ $(df -Pk /scratch | awk "NR==2 {print \$4}") -gt 20971520 ]]' >"$HOST/FREEZE_ATTEMPT02/resources.txt"
"${WI[@]}" bash -s -- "$WS" "$WT" "$HEAD" <<'WS_SCRIPT'
set -euo pipefail
P=$1;WT=$2;HEAD=$3
NODE=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node
[[ $(git -C "$WT" rev-parse HEAD) == "$HEAD" ]]
[[ -z $(git -C "$WT" status --porcelain=v1) ]]
mkdir "$P/packet"
cp "$P"/{catalog.mjs,verify-results.mjs,worker.sbatch,python-deny.sh,trace-env.sh,host_freeze.sh,FIXTURE_ORIGIN.json} "$P/packet/"
cp /workspace/.tmp/SIO161-joint01/REVIEW04/NODE_RUNTIME_BASELINE.sha256 "$P/packet/"
"$NODE" "$P/catalog.mjs" select "$WT" "$HEAD" "$P/packet/SOURCE.json"
"$NODE" "$P/catalog.mjs" snapshot "$P/fixtures" unused "$P/packet/FIXTURES.json"
git -C "$WT" -c tar.umask=0022 archive --format=tar "$HEAD" -- stdlib scripts/lib tools/science_boundary bin/souc bin/madaros bin/madaros-linux-x86_64.gz bin/madaros-linux-x86_64.sha256 tests/run-pass/hello.sio >"$P/source.tar"
"$NODE" "$P/catalog.mjs" select "$WT" "$HEAD" "$P/SOURCE.after-export.json"
cmp "$P/packet/SOURCE.json" "$P/SOURCE.after-export.json"
printf '%s\n' 'a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3  /scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready' '81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90  /scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node' >"$P/packet/ENGINES.sha256"
chmod 755 "$P/packet/python-deny.sh"
(cd "$P/packet";find . -type f ! -name PACKET.sha256 -print0 | sort -z | xargs -0 sha256sum >PACKET.sha256)
(cd "$P";tar -cf packet-fixtures.tar packet fixtures)
sha256sum "$P/source.tar" "$P/packet-fixtures.tar" "$P/packet/SOURCE.json" "$P/packet/PACKET.sha256" >"$P/STAGE_SEALS.txt"
WS_SCRIPT
"${R[@]}" mkdir "$BASE"
"${R[@]}" mkdir "$BASE/source"
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- cat "$WS/source.tar" |
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xf - -C "$BASE/source"
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- cat "$WS/packet-fixtures.tar" |
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xf - -C "$BASE"
"${R[@]}" bash -c 'set -euo pipefail;B=$1;N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node;(cd "$B/packet";sha256sum -c PACKET.sha256);sha256sum -c "$B/packet/ENGINES.sha256";sha256sum -c "$B/packet/NODE_RUNTIME_BASELINE.sha256";"$N" "$B/packet/catalog.mjs" verify "$B/source" "$B/packet/SOURCE.json" "$B/SOURCE.stage.json";"$N" "$B/packet/catalog.mjs" verify "$B/fixtures" "$B/packet/FIXTURES.json" "$B/FIXTURES.stage.json";bash -n "$B/packet/worker.sbatch";echo STAGED_NOT_SUBMITTED' nativewire "$BASE" >"$HOST/FREEZE_ATTEMPT02/worker-stage.txt"
"${W[@]}" bash -c 'set -euo pipefail;P=$1;W=$2;H=$3;N=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node;"$N" "$P/catalog.mjs" select "$W" "$H" "$P/SOURCE.after-transfer.json";cmp "$P/packet/SOURCE.json" "$P/SOURCE.after-transfer.json";git -C "$W" status --porcelain=v1;cat "$P/STAGE_SEALS.txt"' nativewire "$WS" "$WT" "$HEAD" >"$HOST/FREEZE_ATTEMPT02/workspace-final.txt"
echo FROZEN_NOT_SUBMITTED
