#!/usr/bin/env bash
set -euo pipefail
: "${NATIVE_WIRE_DENY_LOG:?deny log path required}"
printf "%s\0" "$0" "$@" >> "$NATIVE_WIRE_DENY_LOG"
printf "NATIVE_WIRE_PYTHON_ATTEMPT_REFUSED command=%s\n" "$0" >&2
exit 125
