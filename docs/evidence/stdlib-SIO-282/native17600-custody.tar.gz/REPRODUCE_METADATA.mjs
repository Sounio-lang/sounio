// Offline operational receipt reproduction only; does not execute compiler/ELFs.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const base=process.argv[2],w=path.join(base,'worker'),r=path.join(w,'results'),p=path.join(w,'packet');
const txt=f=>fs.readFileSync(f,'utf8'),json=f=>JSON.parse(txt(f)),hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
assert.equal(hash(path.join(p,'PACKET.sha256')),'890f24d0a2c5507c81d7b20ede8e31d8181c8ad7ba58409ce22f3cce748007b9');
for(const line of txt(path.join(p,'PACKET.sha256')).trim().split('\n')){const m=/^([0-9a-f]{64})  \.\/(.+)$/.exec(line);assert(m);assert(!m[2].includes('..'));assert.equal(hash(path.join(p,m[2])),m[1]);}
for(const n of ['BODY_STATUS','FINAL_INTEGRITY_STATUS','ALL_STATUS'])assert.equal(txt(path.join(r,n)).trim(),'0');
const src=json(path.join(p,'SOURCE.json')),before=json(path.join(r,'source.before.json')),after=json(path.join(r,'source.final.json'));
assert.equal(src.entries.length,2109);assert.deepEqual(src.entries,before.entries);
assert.deepEqual(src,json(path.join(base,'SOURCE.after-job17600.json')));
const extras=['bin/.madaros-linux-x86_64.verified','bin/madaros-linux-x86_64'];assert.deepEqual(after.entries.filter(x=>!extras.includes(x.path)),src.entries);assert.deepEqual(after.entries.filter(x=>extras.includes(x.path)).map(x=>x.path).sort(),extras);
assert.equal(after.entries.find(x=>x.path===extras[1]).sha256,'125c25703ac4062fc6befb7acf77e945abb13405f0adb5ab09fbc5a8d4b5b29f');
assert.deepEqual(json(path.join(r,'fixtures.before.json')).entries,json(path.join(r,'fixtures.final.json')).entries);
const raw='a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3',elf='eed608a000135801a8dbaf3a8607c2934af4e34eac91b2765023d5fe29594531';
for(const kind of ['source','project'])for(const op of ['check','compile','run']){const name=`${kind}-${op}`,receipt=json(path.join(r,`${name}.json`));assert.equal(txt(path.join(r,`${name}.status`)).trim(),'0');assert.equal(receipt.verdict,'OK');assert.equal(receipt.engine.boundary_collector,'madaros-raw-ast-v1');assert.equal(receipt.assurance_level,'identity-only');assert.equal(receipt.hashes.compiler_sha256,raw);if(op!=='check')assert.equal(receipt.hashes.elf_sha256,elf);if(op==='run')assert.equal(txt(path.join(r,`${name}.stdout`)).trim().split('\n').at(-1),'Hello, Sounio!');}
assert.equal(json(path.join(r,'candidate-evaluate.json')).verdict,'UNKNOWN');assert.equal(txt(path.join(r,'candidate-evaluate.status')).trim(),'21');assert.equal(txt(path.join(r,'candidate-wrapper.status')).trim(),'1');
for(const name of ['python','python3'])assert.equal(txt(path.join(r,`${name}.control.status`)).trim(),'125');
assert.equal(fs.statSync(path.join(r,'python-denied.nul')).size,0);const control=txt(path.join(r,'python-control.nul')).split('\0');assert.equal(control.filter(x=>x==='--controlled-deny-probe').length,2);assert(control.some(x=>x.endsWith('/python'))&&control.some(x=>x.endsWith('/python3')));
for(const [name,marker]of [['core','SCIENCE_BOUNDARY_CORE_PASS 34'],['closure','SCIENCE_BOUNDARY_CLOSURE_OPERATIONAL_PASS tests=67'],['policy','# pass 30'],['cli','SCIENCE_BOUNDARY_ATTESTOR_PASS 28']])assert(txt(path.join(r,`${name}.stdout`)).includes(marker));
assert.equal(txt(path.join(r,'WRAPPER_TOOLCHAIN.sha256')).trim().split('\n').length,47);
for(const f of ['packet.final.txt','engines.final.txt','runtime.final.txt','wrapper-toolchain.final.txt','elfs.final.txt'])assert(txt(path.join(r,f)).trim().split('\n').every(x=>x.endsWith(': OK')));
assert(txt(path.join(w,'JOB_TERMINAL.txt')).startsWith('17600|COMPLETED|0:0|00:00:13|2|4G|cpuops-t560-proxmox|'));
console.log(JSON.stringify({job:17600,state:'COMPLETED',exit:'0:0',elapsed:'00:00:13',source_head:src.head,tracked_entries:2109,fixtures:6,node_controls:159,strict_routes:6,runtime_python_attempts:0,controlled_deny_probes:2,tool_and_helper_entries:47,generated_prebuilt_paths:extras,retained_worker_elf_sha256:elf,offline_receipt_reproduction:'PASS',scope:'Operational native wire only. Temporary run ELF removed by unchanged wrapper; receipt binds identical retained compile ELF. No full E2E or science qualification.'},null,2));
