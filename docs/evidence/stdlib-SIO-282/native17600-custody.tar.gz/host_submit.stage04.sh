#!/bin/bash
# Prepared command; execute ONLY after coordinator authorizes this exact seal.
set -euo pipefail
HOST=/tmp/SIO282-nativewire01
BASE=/scratch/sounio-stdlib-inference-scale-20261024/SIO282-nativewire01/stage04
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
[[ $(cat "$HOST/FREEZE_STAGE04/STATUS") == 0 ]]
[[ ! -e "$HOST/SUBMISSION_ATTEMPT" ]]
mkdir "$HOST/SUBMISSION_ATTEMPT"
date -u +%FT%TZ >"$HOST/SUBMISSION_ATTEMPT/STARTED_AT"
exec > >(tee "$HOST/SUBMISSION_ATTEMPT/stdout.log") 2> >(tee "$HOST/SUBMISSION_ATTEMPT/stderr.log" >&2)
trap 'echo $? >"$HOST/SUBMISSION_ATTEMPT/CONTROLLER_STATUS"' EXIT
"${R[@]}" bash -c 'set -euo pipefail;B=$1;[[ $(id -u) == 1000 ]];[[ ! -e "$B/results" ]];id;df -Pk /scratch;free -k;squeue -u sounio -h -o "%i %j %T";[[ $(df -Pk /scratch | awk "NR==2 {print \$4}") -gt 20971520 ]];echo "890f24d0a2c5507c81d7b20ede8e31d8181c8ad7ba58409ce22f3cce748007b9  $B/packet/PACKET.sha256" | sha256sum -c -;(cd "$B/packet";sha256sum -c PACKET.sha256);sha256sum -c "$B/packet/ENGINES.sha256";sha256sum -c "$B/packet/NODE_RUNTIME_BASELINE.sha256";/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node "$B/packet/catalog.mjs" verify "$B/source" "$B/packet/SOURCE.json" "$B/SOURCE.presubmit.json"' nativewire "$BASE" >"$HOST/SUBMISSION_ATTEMPT/preflight.txt"
date -u +%FT%TZ >"$HOST/SUBMISSION_ATTEMPT/SBATCH_CALL_STARTED_AT"
# Exactly one submission call. Any uncertain error must be reconciled, never retried.
"${R[@]}" sbatch --parsable "$BASE/packet/worker.sbatch" >"$HOST/SUBMISSION_ATTEMPT/sbatch.stdout" 2>"$HOST/SUBMISSION_ATTEMPT/sbatch.stderr"
job=$(cat "$HOST/SUBMISSION_ATTEMPT/sbatch.stdout")
[[ $job =~ ^[0-9]+$ ]]
printf '%s\n' "$job" >"$HOST/JOB_ID"
"${R[@]}" scontrol show job "$job" >"$HOST/SUBMISSION_ATTEMPT/admission.txt"
echo "SUBMITTED_ONCE_JOB=$job"
