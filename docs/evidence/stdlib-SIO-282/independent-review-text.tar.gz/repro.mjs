import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
const base='/workspace/sounio-boundary-node-20261026/tools/science_boundary';
const core=await import(base+'/core.mjs'),policy=await import(base+'/policy.mjs'),attestor=await import(base+'/attestor.mjs');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'boundary-attestor-review-'));
const results={scope:'Synthetic operational metadata fixtures only; no compiler/native/Python execution',core_sha256:core.sha256_file(base+'/core.mjs'),attestor_sha256:core.sha256_file(base+'/attestor.mjs')};
try{
 for(const [name,text]of [['a.sio','// input A'],['b.sio','// different input B'],['compiler','compiler identity fixture'],['artifact.bin','nonempty artifact identity fixture']])fs.writeFileSync(path.join(root,name),text);
 const row={path:'.',ring:'pl-core',evidence_status:'declared',context_of_use:'identity',visibility:'public',enforcement:'strict',next_gate:'identity',allowed_claim_classes:'algorithmic',evidence_refs:'source:a.sio',declared_by:'review',declared_at:'fixture',review_state:'draft'};
 fs.writeFileSync(path.join(root,'science-rings.tsv'),core.TSV_COLUMNS.join('\t')+'\n'+core.TSV_COLUMNS.map(k=>row[k]).join('\t')+'\n');
 fs.writeFileSync(path.join(root,'closure.txt'),'SOUNIO_BOUNDARY_CLOSURE_V1\nstatus\tcomplete\ncapacity\t256\nsaturated\tfalse\nparse_failed\tfalse\nnode\ta.sio\n');
 const pol=policy.discover_policy(path.join(root,'a.sio'),'','strict');
 const [receipt,verdict,diagnostics]=attestor.build_receipt({source:path.join(root,'a.sio'),policy:pol,requested_mode:'strict',compiler_path:path.join(root,'compiler'),engine_identity:'metadata-fixture',closure_report_path:path.join(root,'closure.txt')});
 core.write_json_atomic(path.join(root,'preflight.json'),receipt);
 const rc=attestor.finalize_command({preflight_receipt:path.join(root,'preflight.json'),source:path.join(root,'b.sio'),manifest:'',claim_contract:'',compiler:path.join(root,'compiler'),elf:path.join(root,'artifact.bin'),artifact_label:'artifact.bin',receipt:path.join(root,'final.json')});
 results.finalize_different_source={preflight_verdict:verdict,preflight_diagnostics:diagnostics.map(d=>d.to_dict()),actual_finalize_rc:rc,requested_source:'b.sio',receipt_root:fs.existsSync(path.join(root,'final.json'))?JSON.parse(fs.readFileSync(path.join(root,'final.json'),'utf8')).graph.root_artifact:null,legacy_source_review:'Shared with original Python finalize: root derived from args.source but no comparison of source to graph.root_artifact; not a newly introduced port regression.'};
 fs.writeFileSync(path.join(root,'bad-claim.toml'),`schema = "${core.CLAIM_SCHEMA}"\nclaim-id = "x"\nrequested-class = "algorithmic"\ncontext-of-use = "identity"\nroot-artifact = "a.sio"\n[evidence]\nx = "invalid table shape"\n`);
 try{const [,v,ds]=attestor.build_receipt({source:path.join(root,'a.sio'),policy:pol,requested_mode:'advisory',claim_path:path.join(root,'bad-claim.toml'),compiler_path:path.join(root,'compiler'),engine_identity:'metadata-fixture'});results.malformed_evidence={actual:'receipt',verdict:v,diagnostics:ds.map(d=>d.to_dict())};}catch(e){results.malformed_evidence={actual:'throws',message:e.message,legacy_source_review:'load_claim_contract emits UNKNOWN diagnostic; original summary comprehensions iterate table keys and skip non-dicts, whereas Node summary calls evidence.filter on an object.'};}
}finally{fs.rmSync(root,{recursive:true,force:true});}
results.core_sha256_after=core.sha256_file(base+'/core.mjs');results.attestor_sha256_after=core.sha256_file(base+'/attestor.mjs');fs.writeFileSync('/workspace/.tmp/SIO282-root-review01/findings.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
