#!/bin/bash
#SBATCH --job-name=science-native-gate06
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/science_native_gate06/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/science_native_gate06/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/science_native_gate06/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
export SCIENCE_NATIVE_SEED_BIN=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64
export SCIENCE_NATIVE_OUTPUT=/scratch/sounio-stdlib-inference-scale-20261024/science_native_gate06/artifacts
trap 'rc=$?;printf "%s\n" "$rc" > /scratch/sounio-stdlib-inference-scale-20261024/science_native_gate06/ALL_STATUS' EXIT
bash scripts/stdlib/scientific_native_workflows_gate.sh
out=$SCIENCE_NATIVE_OUTPUT
printf 'engine\texpected_exit\tactual_exit\tdiagnostic\n' > "$out/LABEL_BEFORE_RESULTS.tsv"
for engine in madaros seed;do
 rc=0
 "$out/reference" --normalization tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt "/scratch/sounio-stdlib-inference-scale-20261024/science_native_gate03/artifacts/$engine.normalization.native.stdout" > "$out/$engine.normalization.before-label.stdout" 2> "$out/$engine.normalization.before-label.stderr" || rc=$?
 printf '%s\t1\t%s\tnormalization caption exceeds its panel column\n' "$engine" "$rc" >> "$out/LABEL_BEFORE_RESULTS.tsv"
 [[ $rc == 1 ]]
 grep -Fq 'normalization caption exceeds its panel column' "$out/$engine.normalization.before-label.stderr"
done
