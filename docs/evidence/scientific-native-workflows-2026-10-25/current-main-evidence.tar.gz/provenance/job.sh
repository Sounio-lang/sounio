#!/usr/bin/env bash
#SBATCH --job-name=SIO273-main02
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO273-main02/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO273-main02/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO273-main02/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
base=/scratch/sounio-stdlib-inference-scale-20261024/SIO273-main02
trap 'rc=$?;printf "%s\n" "$rc" > "$base/ALL_STATUS"' EXIT
id > "$base/IDENTITY.txt"
[[ $(id -u) == 1000 ]]
printf '%s\n' 7c5b2cbcae7862950e41b09ebc06c9c0ff744d4a > "$base/SOURCE_HEAD.txt"
printf '%s\n' 8eca8e0c086bbd074485bbfd8716accc4063ef1c > "$base/REMOTE_MAIN.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$base/COMPLETE_SOURCE.sha256"
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
export SCIENCE_NATIVE_SEED_BIN=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64
printf '%s  %s\n' a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3 "$MADAROS_RAW_BIN" 8956946def36004d11ec4eca0d20c75c1e7d3d0b17ee0f0a1fdda9cd6ec0e4cc "$SCIENCE_NATIVE_SEED_BIN" > "$base/EXPECTED_COMPILERS.sha256"
sha256sum --check "$base/EXPECTED_COMPILERS.sha256" > "$base/EXPECTED_COMPILERS.initial.verify"
export SCIENCE_NATIVE_OUTPUT="$base/artifacts"
bash scripts/stdlib/scientific_native_workflows_gate.sh
sha256sum --check "$base/COMPLETE_SOURCE.sha256" > "$base/COMPLETE_SOURCE.final.verify"
sha256sum --check "$base/EXPECTED_COMPILERS.sha256" > "$base/EXPECTED_COMPILERS.final.verify"
printf '%s\n' SIO273_CURRENT_MAIN_DUAL_ENGINE_PASS
