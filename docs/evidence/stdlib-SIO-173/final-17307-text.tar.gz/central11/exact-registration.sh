# Checked FEM / Poisson manufactured solutions, legacy imports and work controls.
rc=0
MADAROS_RAW_BIN="$MADAROS_RAW_BIN" bash scripts/stdlib/fem_poisson_gate.sh "$out/fem-poisson" > "$out/fem-poisson.gate.stdout" 2> "$out/fem-poisson.gate.stderr" || rc=$?
record focused-gate fem-poisson "$rc"
