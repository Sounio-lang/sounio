# stdlib/hardware

Hardware interface.