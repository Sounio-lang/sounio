# stdlib/neuro

Neuroscience module.