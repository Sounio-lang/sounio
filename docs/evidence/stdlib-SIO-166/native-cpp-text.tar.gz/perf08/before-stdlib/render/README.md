# stdlib/render

Rendering module.