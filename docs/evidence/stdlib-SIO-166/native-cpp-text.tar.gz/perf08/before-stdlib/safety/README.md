# stdlib/safety

Safety utilities.