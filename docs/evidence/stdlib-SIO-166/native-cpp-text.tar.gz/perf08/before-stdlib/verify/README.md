# stdlib/verify

Verification module.