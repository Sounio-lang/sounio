#!/bin/bash
# PREPARED ONLY. Root must approve this exact controller and frozen packet first.
set -euo pipefail
H=/tmp/SIO161-E2E-node01
B=/scratch/sounio-stdlib-inference-scale-20261024/SIO161-E2E-node01
SEAL=5a81e9fd2bd73cb60a24960de8b7f26fe3e43c0b4e424e5180d2e2a3283ca932
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
[[ $(cat "$H/FREEZE_ATTEMPT/STATUS") == 0 ]]
mkdir "$H/SUBMISSION_ATTEMPT"
date -u +%FT%TZ >"$H/SUBMISSION_ATTEMPT/STARTED_AT"
exec > >(tee "$H/SUBMISSION_ATTEMPT/stdout.log") 2> >(tee "$H/SUBMISSION_ATTEMPT/stderr.log" >&2)
trap 'echo $? >"$H/SUBMISSION_ATTEMPT/CONTROLLER_STATUS"' EXIT
kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- bash -s -- "$B" "$SEAL" >"$H/SUBMISSION_ATTEMPT/preflight.txt" <<'PREFLIGHT'
set -euo pipefail
B=$1;seal=$2;N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node
[[ $(id -u) == 1000 && ! -e "$B/artifacts" ]]
id;date -u +%FT%TZ
kb=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo);effective=$((kb*1024));seen=0
p=/sys/fs/cgroup$(awk -F: '$1==0 {print $3}' /proc/self/cgroup)
while [[ $p == /sys/fs/cgroup* ]];do
 if [[ -f $p/memory.max ]];then max=$(cat "$p/memory.max");used=$(cat "$p/memory.current");printf 'cgroup=%s max=%s current=%s\n' "$p" "$max" "$used";if [[ $max != max ]];then [[ $max =~ ^[0-9]+$ && $used =~ ^[0-9]+$ ]];free=$((max-used));((free<effective)) && effective=$free;seen=1;fi;fi
 [[ $p == /sys/fs/cgroup ]] && break;p=${p%/*}
done
[[ $seen == 1 && $effective -ge 21474836480 ]];printf 'effective_headroom_bytes=%s\n' "$effective"
df -Pk /scratch;[[ $(df -Pk /scratch | awk 'NR==2 {print $4}') -ge 20971520 ]]
squeue -u sounio -h -o '%i|%j|%T|%P'
[[ $(squeue -u sounio -h -o '%i' | awk 'END {print NR}') -le 7 ]]
[[ -z $(squeue -u sounio -h -o '%j' | grep '^SIO161-E2E-node01$' || true) ]]
echo "$seal  $B/packet/PACKET.sha256" | sha256sum -c -
(cd "$B/packet";sha256sum -c PACKET.sha256)
sha256sum -c "$B/packet/NODE_RUNTIME_BASELINE.sha256"
echo 'a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3  /scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready' | sha256sum -c -
echo "81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90  $N" | sha256sum -c -
"$N" "$B/packet/source_custody.mjs" verify "$B/source" "$B/packet" "$B/SOURCE.presubmit.json"
cmp "$B/SOURCE.stage.json" "$B/SOURCE.presubmit.json"
echo EFFECTIVE_RESOURCE_AND_FROZEN_SOURCE_PREFLIGHT_PASS
PREFLIGHT
date -u +%FT%TZ >"$H/SUBMISSION_ATTEMPT/SBATCH_CALL_STARTED_AT"
# ONE call only. Any uncertainty requires reconciliation, never a retry.
"${R[@]}" sbatch --parsable "$B/packet/worker.sbatch" "$SEAL" >"$H/SUBMISSION_ATTEMPT/sbatch.stdout" 2>"$H/SUBMISSION_ATTEMPT/sbatch.stderr"
job=$(cat "$H/SUBMISSION_ATTEMPT/sbatch.stdout");[[ $job =~ ^[0-9]+$ ]]
echo "$job" >"$H/JOB_ID"
"${R[@]}" scontrol show job "$job" >"$H/SUBMISSION_ATTEMPT/admission.txt"
echo "SUBMITTED_ONCE_JOB=$job"
