#!/bin/bash
# Read-only reconciliation/receipt acquisition for the one recorded job.
set -euo pipefail
H=/tmp/SIO161-E2E-node01
B=/scratch/sounio-stdlib-inference-scale-20261024/SIO161-E2E-node01
P=/workspace/.tmp/SIO161-E2E-node01
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
W=(kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
job=$(cat "$H/JOB_ID");[[ $job =~ ^[0-9]+$ ]];mkdir "$H/MONITOR_ATTEMPT"
deadline=$(($(date +%s)+3900));terminal=0
while [[ $(date +%s) -lt $deadline ]];do
 date -u +%FT%TZ >>"$H/MONITOR_ATTEMPT/times.txt"
 if "${R[@]}" sacct -j "$job" --parsable2 --noheader -o JobID,State,ExitCode,Elapsed,AllocCPUS,ReqMem,NodeList,Start,End >"$H/MONITOR_ATTEMPT/sacct.latest.txt" 2>>"$H/MONITOR_ATTEMPT/transport.stderr";then
  cat "$H/MONITOR_ATTEMPT/sacct.latest.txt" >>"$H/MONITOR_ATTEMPT/history.txt"
  state=$(awk -F'|' -v job="$job" '$1==job {print $2}' "$H/MONITOR_ATTEMPT/sacct.latest.txt")
  case $state in COMPLETED|FAILED|CANCELLED*|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL|BOOT_FAIL|DEADLINE|PREEMPTED)terminal=1;break;;esac
 fi
 sleep 30
done
[[ $terminal == 1 ]] || { echo UNRECONCILED >"$H/MONITOR_ATTEMPT/STATUS";exit 1; }
cp "$H/MONITOR_ATTEMPT/sacct.latest.txt" "$H/JOB_TERMINAL.txt"
"${W[@]}" bash -c 'set -euo pipefail;P=$1;N=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node;"$N" "$P/packet/source_custody.mjs" verify-workspace /workspace/sounio-SIO275-fulltree-node-20261026 "$P/packet" "$P/WORKSPACE.terminal.json";cmp "$P/WORKSPACE.before-export.json" "$P/WORKSPACE.terminal.json"' monitor "$P" >"$H/MONITOR_ATTEMPT/workspace-terminal.txt" 2>"$H/MONITOR_ATTEMPT/workspace-terminal.stderr"
# Keep originals intact. Only textual packet/controller/receipts are transported.
"${R[@]}" bash -c 'set -euo pipefail;B=$1;J=$2;sacct -j "$J" --parsable2 --noheader -o JobID,State,ExitCode,Elapsed,AllocCPUS,ReqMem,NodeList,Start,End >"$B/JOB_TERMINAL.txt";tar --exclude="*.elf" -czf "$B/current-e2e-text.tar.gz" -C "$B" artifacts packet SOURCE.stage.json SOURCE.presubmit.json JOB_TERMINAL.txt "slurm-$J.out" "slurm-$J.err";sha256sum "$B/current-e2e-text.tar.gz"' monitor "$B" "$job" >"$H/MONITOR_ATTEMPT/worker-archive.txt"
kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- cat "$B/current-e2e-text.tar.gz" |
 kubectl -n beagle exec -i sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server -- bash -c 'cat >"$1/current-e2e-text.tar.gz"' monitor "$P"
echo RECONCILED_TRANSPORTED >"$H/MONITOR_ATTEMPT/STATUS"
