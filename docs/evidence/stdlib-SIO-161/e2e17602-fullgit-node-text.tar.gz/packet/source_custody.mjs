// Operational full-Git materialization custody. No scientific numeric routine.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';
const hash=(b,a='sha256')=>crypto.createHash(a).update(b).digest('hex');
const blob=b=>hash(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b]),'sha1');
const baseline='3c7c8073411a7e7254d0d9424f59f8e49eb49180';
const tree=b=>b.toString().split('\0').filter(Boolean).map(row=>{const m=/^(\d{6}) blob ([0-9a-f]{40}) +([0-9]+)\t([\s\S]+)$/.exec(row);assert(m,`unsupported Git entry ${row}`);const [,mode,id,size,p]=m;assert(['100644','100755','120000'].includes(mode));assert(!path.isAbsolute(p)&&!p.split('/').includes('..')&&!/[\r\n\\]/.test(p));return{path:p,git_mode:mode,git_blob:id,blob_bytes:Number(size)};}).sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
const walk=(root,rel='')=>fs.readdirSync(path.join(root,rel),{withFileTypes:true}).flatMap(d=>{const p=rel?`${rel}/${d.name}`:d.name;return d.isDirectory()?walk(root,p):[p];}).sort();
const [cmd,root,packet,out]=process.argv.slice(2);
if(cmd==='prepare'){
 const head=out;assert(/^[0-9a-f]{40}$/.test(head));
 const git=(...a)=>execFileSync('git',['-C',root,...a],{maxBuffer:64*1024*1024});
 assert.equal(git('rev-parse','HEAD').toString().trim(),head);assert.equal(git('status','--porcelain=v1').length,0);
 const raw=git('ls-tree','-rlz',head),old=git('ls-tree','-rlz',baseline),current=tree(raw),previous=tree(old);
 assert.equal(hash(old),'5a5a03e7226491a6f0d92ef0236ff6371ed119d0909812eb01c128e055a5f2fa');
 const protectedPath=p=>['stdlib/','tests/','examples/'].some(x=>p.startsWith(x))||['scripts/stdlib/run_stdlib_e2e.sh','scripts/stdlib/emit_stdlib_e2e_result.mjs','scripts/stdlib/test_emit_stdlib_e2e_result.mjs'].includes(p);
 assert.deepEqual(current.filter(e=>protectedPath(e.path)),previous.filter(e=>protectedPath(e.path)),'stdlib/tests/examples/E2E closure drift from3c7');
 assert(current.some(e=>e.path==='tools/science_boundary/core.mjs'),'core must be tracked');
 const missingBytes=fs.readFileSync(path.join(packet,'MISSING_TRACKED_INPUTS.txt'));assert.equal(hash(missingBytes),'fe5a6e87a87ad4b68a9337ffb70700e1df113dbd0d2760ecc8d86cce4544cdd7');
 const missing=missingBytes.toString().trim().split(/\r?\n/);assert.equal(missing.length,17);assert.equal(new Set(missing).size,17);
 for(const p of missing){const a=current.find(e=>e.path===p),b=previous.find(e=>e.path===p);assert(a&&b,`formerly missing input absent ${p}`);assert.deepEqual(a,b,`formerly missing input changed ${p}`);}
 const nativeHead='b81b5bcf447e441e9cb45806d7451c6b104882ec',native=tree(git('ls-tree','-rlz',nativeHead));
 const runtimePath=p=>['bin/souc','bin/madaros'].includes(p)||(p.startsWith('tools/science_boundary/')&&(p.endsWith('.mjs')||p.startsWith('tools/science_boundary/vendor/')));
 assert.deepEqual(current.filter(e=>runtimePath(e.path)),native.filter(e=>runtimePath(e.path)),'native17600 operational component drift');
 fs.writeFileSync(path.join(packet,'GIT_TREE.raw.nul'),raw);fs.writeFileSync(path.join(packet,'BASELINE_TREE.raw.nul'),old);
 const config={source_head:head,baseline_head:baseline,native_component_head:nativeHead,native_component_entries:current.filter(e=>runtimePath(e.path)).length,tree_sha256:hash(raw),baseline_tree_sha256:hash(old),tracked_entries:current.length,symlinks:current.filter(e=>e.git_mode==='120000').length,gitlinks:0,total_blob_bytes:current.reduce((n,e)=>n+e.blob_bytes,0),unchanged_protected_paths:current.filter(e=>protectedPath(e.path)).length,e2e_census:current.filter(e=>e.path.startsWith('tests/stdlib/')&&e.path.endsWith('.sio')&&e.path.split('/').every(x=>!x.startsWith('.'))).map(e=>e.path),formerly_missing17:missing};
 assert.equal(config.e2e_census.length,627);fs.writeFileSync(path.join(packet,'SOURCE_CONFIG.json'),JSON.stringify(config,null,2)+'\n');console.log(JSON.stringify(config));
}else if(cmd==='verify-workspace'){
 const cfg=JSON.parse(fs.readFileSync(path.join(packet,'SOURCE_CONFIG.json'))),git=(...a)=>execFileSync('git',['-C',root,...a],{maxBuffer:64*1024*1024});
 assert.equal(git('rev-parse','HEAD').toString().trim(),cfg.source_head);assert.equal(git('status','--porcelain=v1').length,0);assert.equal(hash(git('ls-tree','-rlz',cfg.source_head)),cfg.tree_sha256);
 fs.writeFileSync(out,JSON.stringify({source_head:cfg.source_head,tree_sha256:cfg.tree_sha256,clean:true,sparse_worktree_allowed:true,export_authority:'Committed Git objects, never worktree overlay'},null,2)+'\n');console.log('COMMITTED_SOURCE_HEAD_TREE_CLEAN_PASS');
}else if(cmd==='verify'||cmd==='verify-materialized'){
 const cfg=JSON.parse(fs.readFileSync(path.join(packet,'SOURCE_CONFIG.json'))),raw=fs.readFileSync(path.join(packet,'GIT_TREE.raw.nul'));assert.equal(hash(raw),cfg.tree_sha256);
 const expected=tree(raw);assert.equal(expected.length,cfg.tracked_entries);assert.equal(new Set(expected.map(e=>e.path)).size,expected.length);
 assert(!fs.existsSync(path.join(root,'.git')),'Git history forbidden');let names=walk(root),generated=[];
 if(cmd==='verify-materialized'){
  const extras=['bin/.madaros-linux-x86_64.verified','bin/madaros-linux-x86_64'];assert(extras.every(x=>names.includes(x)));names=names.filter(x=>!extras.includes(x));
  const want=fs.readFileSync(path.join(root,'bin/madaros-linux-x86_64.sha256'),'utf8').trim().split(/\s+/)[0],elf=path.join(root,extras[1]),stamp=path.join(root,extras[0]);
  const s=fs.lstatSync(elf),t=fs.lstatSync(stamp);assert(s.isFile()&&t.isFile());assert.equal(s.mode&0o777,0o755);assert.equal(hash(fs.readFileSync(elf)),want);
  const meta=execFileSync('/bin/bash',['-c','source "$1/scripts/lib/materialize_madaros_prebuilt.sh"; _sounio_madaros_stat_inode_mtime_ctime "$1/bin/madaros-linux-x86_64"','custody',root],{encoding:'utf8'}).trim();
  assert.equal(fs.readFileSync(stamp,'utf8'),`${want} ${s.size} ${meta}\n`);
  generated=extras.map(p=>{const b=fs.readFileSync(path.join(root,p)),s=fs.lstatSync(path.join(root,p),{bigint:true});return{path:p,sha256:hash(b),bytes:b.length,mode:Number(s.mode&0o777n),inode:s.ino.toString(),mtime_ns:s.mtimeNs.toString(),ctime_ns:s.ctimeNs.toString()};});
 }
 assert.deepEqual(names,expected.map(e=>e.path),'unplanned/missing full Git physical path');
 const observed=expected.map(e=>{const p=path.join(root,e.path),s=fs.lstatSync(p),link=e.git_mode==='120000';assert(link?s.isSymbolicLink():s.isFile(),e.path);assert.equal(s.mode&0o777,link?0o777:e.git_mode==='100755'?0o755:0o644,e.path);const b=link?Buffer.from(fs.readlinkSync(p)):fs.readFileSync(p);assert.equal(b.length,e.blob_bytes,e.path);assert.equal(blob(b),e.git_blob,e.path);return{...e,sha256:hash(b),...(link?{link:b.toString()}: {})};});
 const receipt={source_head:cfg.source_head,tracked_entries:observed.length,entries:observed,generated_artifacts:generated};fs.writeFileSync(out,JSON.stringify(receipt,null,2)+'\n');console.log(`SOURCE_CUSTODY_PASS tracked=${observed.length} generated=${generated.length}`);
}else throw Error('unknown custody command');
