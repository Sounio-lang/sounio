// Current-run operational rows only: observe an original read-only inode.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const [hint,out,done,deadlineText]=process.argv.slice(2),deadline=Number(deadlineText),pause=()=>new Promise(r=>setTimeout(r,100));
fs.mkdirSync(out);let fd,opened;
while(Date.now()<deadline){
 if(fs.existsSync(hint)){
  const [pid,input,meta,tail]=fs.readFileSync(hint,'utf8').split('\0');assert.equal(tail,'');assert(/^[0-9]+$/.test(pid));assert(path.isAbsolute(input));assert(/^\d+ \d+$/.test(meta));
  const status=fs.readFileSync(`/proc/${pid}/status`,'utf8');assert(/^Uid:\s+1000\s+1000\s+1000\s+1000$/m.test(status));
  const argv=fs.readFileSync(`/proc/${pid}/cmdline`,'utf8').split('\0');assert(argv.some(x=>x.endsWith('scripts/stdlib/run_stdlib_e2e.sh')));
  fd=fs.openSync(input,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);const s=fs.fstatSync(fd);assert(s.isFile());assert.equal(`${s.dev} ${s.ino}`,meta);assert.equal(s.uid,1000);
  opened={runner_pid:pid,source:input,dev:s.dev,inode:s.ino,hint_dev_inode:meta,opened_utc:new Date().toISOString(),read_only_fd:true,no_follow:true};fs.writeFileSync(path.join(out,'OPENED.json'),JSON.stringify(opened,null,2)+'\n');break;
 }
 if(fs.existsSync(done))throw Error('runner ended before actual TSV inode was opened');await pause();
}
assert(fd!==undefined,'capture open deadline');
while(!fs.existsSync(done)){assert(Date.now()<deadline,'capture terminal deadline');await pause();}
await pause();const before=fs.fstatSync(fd),bytes=fs.readFileSync(fd),after=fs.fstatSync(fd);fs.closeSync(fd);assert.equal(before.size,after.size);assert.equal(bytes.length,after.size);assert.equal(after.dev,opened.dev);assert.equal(after.ino,opened.inode);
fs.writeFileSync(path.join(out,'RESULTS.actual.tsv'),bytes);fs.writeFileSync(path.join(out,'CAPTURE.json'),JSON.stringify({...opened,captured_utc:new Date().toISOString(),bytes:bytes.length,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),source_unlinked_by_runner:!fs.existsSync(opened.source),stable_size_before_after:true,scope:'Only this execution original inode. Completion requires separate fresh JSON/census verification.'},null,2)+'\n');
console.log('ACTUAL_CURRENT_INODE_CAPTURE_PASS');
