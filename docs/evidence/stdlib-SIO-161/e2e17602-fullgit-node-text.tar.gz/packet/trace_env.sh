#!/bin/bash
# Selective operational instrumentation; never trace runner output assignments.
case $0 in
 */scripts/stdlib/run_stdlib_e2e.sh|scripts/stdlib/run_stdlib_e2e.sh)
  # Observe the runner-owned file once, after its existing mktemp assignment.
  # The independent reader opens O_RDONLY; this hook never writes the TSV.
  __sio_e2e_capture_hint(){
   local meta
   if [[ -n ${E2E_CAPTURE_HINT:-} ]] && meta=$(stat -c '%d %i' -- "$RESULTS_FILE" 2>/dev/null);then
    { printf '%s\0%s\0%s\0' "$BASHPID" "$RESULTS_FILE" "$meta" >"$E2E_CAPTURE_HINT.tmp" && mv "$E2E_CAPTURE_HINT.tmp" "$E2E_CAPTURE_HINT"; } 2>/dev/null || :
   fi
   return 0
  }
  trap 'if [[ -n ${RESULTS_FILE:-} ]];then __sio_e2e_capture_hint || :;trap - DEBUG;unset -f __sio_e2e_capture_hint;fi' DEBUG
  ;;
 */bin/souc|*/bin/madaros|*/scripts/lib/materialize_madaros_prebuilt.sh)
  [[ -n ${E2E_WRAPPER_TRACE:-} ]] || return 0
  exec 19>>"$E2E_WRAPPER_TRACE"
  export BASH_XTRACEFD=19
  PS4='+e2e pid=$BASHPID source=${BASH_SOURCE[0]} line=$LINENO '
  set -x
  ;;
esac
