// Operational shell-instrumentation controls; no scientific computation.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
const hook=path.resolve(process.argv[2]),out=path.resolve(process.argv[3]);fs.mkdirSync(out);const fixture=path.join(out,'scripts/stdlib/run_stdlib_e2e.sh');fs.mkdirSync(path.dirname(fixture),{recursive:true});
fs.writeFileSync(fixture,`#!/bin/bash
set -euo pipefail
RESULTS_FILE=$(mktemp)
trap 'rm -f "$RESULTS_FILE"' EXIT
printf 'flags=%s\\n' "$-"
printf 'debugtrap=%s\\n' "$(trap -p DEBUG)"
case $1 in
 rc0) printf 'ok\\n';printf 'err0\\n' >&2;exit 0;;
 rc1) printf 'fail\\n';printf 'err1\\n' >&2;exit 1;;
 rc124) printf 'bound\\n';printf 'err124\\n' >&2;exit 124;;
 substitution) value=$(printf 'first';false;printf 'last');printf 'value=%s status=%s\\n' "$value" "$?";;
 handled) rc=0;false || rc=$?;printf 'handled=%s\\n' "$rc";if value=$(printf 'captured';exit 7);then echo impossible;else printf 'subfailure=%s value=%s\\n' "$?" "$value";fi;;
 errexit) printf 'before-errexit\\n';false;echo UNREACHABLE;;
 timeout) printf 'before-timeout\\n';sleep 2;;
 hint-failure) printf 'hint-unavailable-body-unaffected\\n';exit 0;;
esac
`);
const results=[];
for(const mode of ['rc0','rc1','rc124','substitution','handled','errexit','timeout','hint-failure']){
 const work=fs.mkdtempSync(path.join(os.tmpdir(),'e2e-hook-control-')),hint=mode==='hint-failure'?path.join(work,'missing','hint'):path.join(work,'hint');
 const env={...process.env,TMPDIR:work};delete env.BASH_ENV;
 const argv=mode==='timeout'?['timeout','--kill-after=1','0.1','bash',fixture,mode]:['bash',fixture,mode];
 const run=e=>spawnSync(argv[0],argv.slice(1),{env:e,encoding:'utf8',timeout:4000});
 const before=run(env),after=run({...env,BASH_ENV:hook,E2E_CAPTURE_HINT:hint});
 assert.equal(before.error,undefined);assert.equal(after.error,undefined);assert.equal(after.status,before.status,mode);assert.equal(after.signal,before.signal,mode);assert.equal(after.stdout,before.stdout,mode);assert.equal(after.stderr,before.stderr,mode);
 assert(after.stdout.includes('debugtrap=\n'),`DEBUG trap must remove itself ${mode}`);
 if(mode!=='hint-failure'){const fields=fs.readFileSync(hint,'utf8').split('\0');assert.equal(fields.length,4);assert(/^\d+$/.test(fields[0]));assert(/^\d+ \d+$/.test(fields[2]));assert.equal(fields[3],'');}
 else assert(!fs.existsSync(hint));
 const result={mode,status:after.status,signal:after.signal,stdout:after.stdout,stderr:after.stderr,options_stdout_stderr_exit_and_errexit_equal:true};results.push(result);
}
fs.writeFileSync(path.join(out,'RESULTS.json'),JSON.stringify(results,null,2)+'\n');console.log(`SHELL_HINT_BEFORE_AFTER_PASS controls=${results.length}`);
