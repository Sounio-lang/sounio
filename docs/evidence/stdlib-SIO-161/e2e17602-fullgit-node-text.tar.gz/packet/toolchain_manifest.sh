#!/bin/bash
# Operational executable and loader closure for this bounded Linux wrapper job.
set -euo pipefail
out=$1
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT
for name in bash sh env dirname basename readlink head awk grep sed base64 cut date cp tar cmp sleep timeout gzip sha256sum stat wc tr sort find xargs install chmod mv cat rm mktemp uname ldd mkdir ln id scontrol;do
 resolved=$(readlink -f "$(command -v "$name")")
 [[ -f $resolved && -x $resolved ]]
 printf '%s\n' "$resolved" >>"$tmp"
 if [[ $(head -c2 "$resolved") == '#!' ]];then
  interpreter=$(head -n1 "$resolved")
  case $interpreter in '#!/bin/bash'|'#!/bin/sh'|'#! /bin/sh'|'#!/usr/bin/bash')continue;;
   *)echo "Undeclared script interpreter: $resolved $interpreter" >&2;exit 1;;esac
 fi
 if deps=$(ldd "$resolved" 2>&1);then
  [[ $deps != *'not found'* ]]
  printf '%s\n' "$deps" | awk '/=> \// {print $3} /^[[:space:]]*\// {print $1}' >>"$tmp"
 else
  printf 'Unresolved runtime closure: %s\n%s\n' "$resolved" "$deps" >&2;exit 1
 fi
done
sort -u "$tmp" | xargs -r sha256sum >"$out"
[[ -s $out ]]
