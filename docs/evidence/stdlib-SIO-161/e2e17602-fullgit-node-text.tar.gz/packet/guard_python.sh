#!/bin/bash
# Never executes Python. The caller validates interpreter/name/realpath/hash first.
set -eu
: "${E2E_PYTHON_DENY_LOG:?}"
printf '%s\0' "$0" "$@" >>"$E2E_PYTHON_DENY_LOG"
printf 'E2E_PYTHON_REFUSED %s\n' "$0" >&2
exit 125
