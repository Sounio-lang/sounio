#!/bin/bash
set -euo pipefail
base=$1;packet=$2;out=$3
[[ -x "$packet/guard_python.sh" ]]
tmp=$(mktemp);trap 'rm -f "$tmp"' EXIT
printf '%s\n' python python3 >"$tmp"
for dir in /usr/bin /bin;do for p in "$dir"/python*;do if [[ -e $p ]];then basename "$p" >>"$tmp";fi;done;done
sort -u "$tmp" -o "$tmp";cmp "$out/PYTHON_NAMES.txt" "$tmp"
while IFS= read -r name;do
 [[ $(command -v "$name") == "$base/path/$name" ]]
 [[ $(readlink -f "$(command -v "$name")") == "$packet/guard_python.sh" ]]
 [[ -x "$base/path/$name" ]]
done <"$out/PYTHON_NAMES.txt"
sha256sum -c "$out/PYTHON_GUARDS.sha256"
[[ ! -s "$out/python.runtime.nul" ]]
