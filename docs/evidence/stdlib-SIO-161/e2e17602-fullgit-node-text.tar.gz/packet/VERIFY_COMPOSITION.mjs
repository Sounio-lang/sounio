// Operational Git object verification only; no wrapper/compiler invocation.
import fs from 'node:fs';import cp from 'node:child_process';import crypto from 'node:crypto';import assert from 'node:assert/strict';import path from 'node:path';
const dir=path.dirname(new URL(import.meta.url).pathname),p=JSON.parse(fs.readFileSync(path.join(dir,'COMPOSITION_PROOF.json'),'utf8'));
const git=(...args)=>cp.execFileSync('git',args,{maxBuffer:64*1024*1024});
const text=(...args)=>git(...args).toString('utf8').trim();
assert.equal(text('rev-parse','HEAD'),p.head);assert.equal(text('status','--porcelain'),'');
const expected=JSON.parse(fs.readFileSync(path.join(dir,'FULL_GIT_OBJECTS.json'),'utf8'));assert.equal(expected.commit,p.head);
const actual=git('ls-tree','-rlz',p.head).toString('utf8').split('\0').filter(Boolean).map(line=>{const at=line.indexOf('\t'),v=line.slice(0,at).trim().split(/\s+/),e={path:line.slice(at+1),mode:v[0],type:v[1],object:v[2],bytes:v[3]==='-'?null:Number(v[3])};if(e.mode==='120000')e.linkTarget=git('cat-file','blob',e.object).toString('utf8');return e;});
assert.deepEqual(actual,expected.entries);assert.equal(actual.length,p.fullGit.entries);assert.equal(actual.reduce((a,e)=>a+BigInt(e.bytes||0),0n).toString(),p.fullGit.blobBytes);
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,'FULL_GIT_OBJECTS.json'))).digest('hex'),p.fullGit.inventorySha256);
for(const [file,identity]of Object.entries(p.scientificAndRunnerParity)){assert.equal(text('rev-parse',p.head+':'+file),identity.composed);assert.equal(text('rev-parse','3c7c8073411a7e7254d0d9424f59f8e49eb49180:'+file),identity.original);assert.equal(identity.original,identity.composed);}
for(const r of p.nativeRuntimeParity){assert.equal(text('rev-parse',p.head+':'+r.path),r.composedObject);assert.equal(text('rev-parse',p.selectedOriginalCommits[0]+':'+r.path),r.nativeObject);assert.equal(r.nativeObject,r.composedObject);}
assert.equal(crypto.createHash('sha256').update(git('cat-file','blob',p.core.object)).digest('hex'),p.core.sha256);
assert.equal(p.core.mode,'100644');assert.equal(p.core.path,'tools/science_boundary/core.mjs');assert.ok(actual.some(e=>e.path===p.core.path&&e.object===p.core.object&&e.mode===p.core.mode));
const census=JSON.parse(fs.readFileSync(path.join(dir,'STDLIB_CENSUS.json'),'utf8'));assert.equal(census.commit,p.head);assert.deepEqual(census.paths,actual.filter(e=>e.path.startsWith('tests/stdlib/')&&e.path.endsWith('.sio')).map(e=>e.path));assert.equal(census.paths.length,627);assert.equal(new Set(census.paths).size,627);
for(const file of p.pireus17)assert.equal(text('rev-parse',p.head+':'+file),text('rev-parse','3c7c8073411a7e7254d0d9424f59f8e49eb49180:'+file));
assert.equal(text('rev-parse',p.head+':.github/workflows/ci.yml'),text('rev-parse',p.base+':.github/workflows/ci.yml'));
assert.deepEqual(text('rev-list','--reverse',p.base+'..'+p.head).split('\n'),p.composedCommits);
console.log('SOURCE_COMPOSITION_OBJECT_VERIFICATION_PASS head='+p.head+' entries='+actual.length+' census='+census.paths.length);
