// Operational read-only FD witness controls; fixture rows are never measurements.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';
const [reader,hook,out]=process.argv.slice(2).map(x=>path.resolve(x));fs.mkdirSync(out);
const fixture=path.join(out,'scripts/stdlib/run_stdlib_e2e.sh');fs.mkdirSync(path.dirname(fixture),{recursive:true});
const row='pass\tfixture-only.sio\tcheck-only\t\t\t\t0\tb2s=\n';
fs.writeFileSync(fixture,'#!/bin/bash\nset -euo pipefail\nRESULTS_FILE=$(mktemp)\ntrap \'rm -f "$RESULTS_FILE"\' EXIT\nprintf \'pass\\tfixture-only.sio\\tcheck-only\\t\\t\\t\\t0\\tb2s=\\n\' >>"$RESULTS_FILE"\nsleep 1\n');
const wait=p=>new Promise(resolve=>p.on('close',(status,signal)=>resolve({status,signal}))),pause=()=>new Promise(r=>setTimeout(r,10)),results=[];
for(const mode of ['exact-original-inode','symlink-refused','wrong-inode-refused','stale-pid-refused']){
 const dir=path.join(out,mode);fs.mkdirSync(dir);const hint=path.join(dir,'hint'),done=path.join(dir,'done');
 const child=spawn('bash',[fixture],{env:{...process.env,BASH_ENV:hook,E2E_CAPTURE_HINT:hint,TMPDIR:dir},stdio:['ignore','pipe','pipe']});const childDone=wait(child).then(v=>{fs.writeFileSync(done,JSON.stringify(v));return v;});
 for(let i=0;i<150&&!fs.existsSync(hint);i++)await pause();assert(fs.existsSync(hint));let fields=fs.readFileSync(hint,'utf8').split('\0');const original=fields[1];
 if(mode==='symlink-refused'){const link=path.join(dir,'link');fs.symlinkSync(original,link);fields[1]=link;}
 if(mode==='wrong-inode-refused')fields[2]='0 0';if(mode==='stale-pid-refused')fields[0]='999999999';
 fs.writeFileSync(hint,fields.join('\0'));const stdout=fs.openSync(path.join(dir,'reader.stdout'),'w'),stderr=fs.openSync(path.join(dir,'reader.stderr'),'w');
 const observer=spawn(process.execPath,[reader,hint,path.join(dir,'captured'),done,String(Date.now()+5000)],{stdio:['ignore',stdout,stderr]});const result=await wait(observer);fs.closeSync(stdout);fs.closeSync(stderr);await childDone;
 if(mode==='exact-original-inode'){
  assert.equal(result.status,0);const c=JSON.parse(fs.readFileSync(path.join(dir,'captured/CAPTURE.json')));assert(c.read_only_fd&&c.no_follow&&c.source_unlinked_by_runner);assert.equal(`${c.dev} ${c.inode}`,c.hint_dev_inode);assert.equal(fs.readFileSync(path.join(dir,'captured/RESULTS.actual.tsv'),'utf8'),row);
 }else{assert.equal(result.status,1);assert(!fs.existsSync(path.join(dir,'captured/RESULTS.actual.tsv')));}
 results.push({mode,...result,fixture_only:true});
}
fs.writeFileSync(path.join(out,'RESULTS.json'),JSON.stringify(results,null,2)+'\n');console.log('READ_ONLY_CURRENT_INODE_CONTROLS_PASS controls=4');
