// Independent current-run TSV/JSON metadata reconstruction, no emitter imports.
import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const [base]=process.argv.slice(2),out=base+'/artifacts',rows=out+'/rows',src=base+'/source',cfg=JSON.parse(fs.readFileSync(base+'/packet/SOURCE_CONFIG.json'));
const digest=b=>crypto.createHash('sha256').update(b).digest('hex'),raw=fs.readFileSync(rows+'/RESULTS.actual.tsv'),cap=JSON.parse(fs.readFileSync(rows+'/CAPTURE.json')),bytes=fs.readFileSync(out+'/e2e/measured.v1.json'),actual=JSON.parse(bytes);
assert.equal(digest(raw),cap.sha256);assert.equal(cap.source_unlinked_by_runner,true);assert(cap.read_only_fd&&cap.stable_size_before_after);
const start=fs.readFileSync(out+'/e2e/STARTED_UTC','utf8').trim();assert(Date.parse(actual.generated_at_utc)>=Date.parse(start));assert(Date.parse(actual.generated_at_utc)<=Date.parse(cap.captured_utc)+1000);
const tree=fs.readFileSync(base+'/packet/GIT_TREE.raw.nul');assert.equal(digest(tree),cfg.tree_sha256);
const census=tree.toString().split('\0').filter(Boolean).map(x=>x.slice(x.indexOf('\t')+1)).filter(x=>x.startsWith('tests/stdlib/')&&x.endsWith('.sio')&&x.split('/').every(y=>!y.startsWith('.'))).sort();assert.deepEqual(census,cfg.e2e_census);assert.equal(census.length,627);
const results=[],counts={pass:0,fail:0,skip:0};
for(const line of new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw).split('\n')){
 if(!line)continue;const f=line.split('\t');assert.equal(f.length,8);const[status,test_path,mode,reason,owner,unblock_condition,exit,b64]=f;assert(Object.hasOwn(counts,status));counts[status]++;
 assert(/^(?:0|[1-9][0-9]*)$/.test(exit));const exit_code=Number(exit);assert(Number.isSafeInteger(exit_code));assert(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(b64));
 results.push({status,test_path,mode,reason,owner,unblock_condition,exit_code,detail_excerpt:Buffer.from(b64,'base64').toString('utf8')});
}
assert.equal(results.length,census.length);assert.equal(new Set(results.map(x=>x.test_path)).size,census.length);assert.deepEqual(results.map(x=>x.test_path).sort(),census);
const document={schema:'sounio.stdlib.e2e.result.v1',generated_at_utc:actual.generated_at_utc,command:'bash scripts/stdlib/run_stdlib_e2e.sh',context:{root_dir:src,souc_bin:src+'/bin/souc',stdlib_path:src+'/stdlib',filter:''},totals:{...counts,total:results.length},results,failures:results.filter(x=>x.status==='fail'),ignored:results.filter(x=>x.mode==='ignore').map(({test_path,reason,owner,unblock_condition})=>({test_path,reason,owner,unblock_condition}))};
assert.deepEqual(document,actual);const encoded=(JSON.stringify(document,null,2)+'\n').replace(/[\u007f-\uffff]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));assert.equal(encoded,bytes.toString('utf8'));
fs.writeFileSync(rows+'/DOCUMENT.reproduced.json',encoded);fs.writeFileSync(rows+'/REPRODUCTION.json',JSON.stringify({source_head:cfg.source_head,rows:results.length,unique_paths:census.length,original_tsv_sha256:digest(raw),actual_json_sha256:digest(bytes),reproduced_json_sha256:digest(Buffer.from(encoded)),semantic_equal:true,byte_equal:true,scope:'Only this job original current TSV/JSON. Clock field copied after actual-run bounds validation. No prior rows, fallback, emitter import or test rerun.'},null,2)+'\n');
console.log('CURRENT_RUN_TSV_JSON_CENSUS_REPRODUCTION_PASS');
