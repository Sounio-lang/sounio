#!/bin/bash
# Operational PATH census and controlled shim checks only.
set -euo pipefail
base=$1;packet=$2;out=$3;node=$4
mkdir "$base/path"
ln -s "$node" "$base/path/node"
[[ -x "$packet/guard_python.sh" ]]
printf '%s\n' python python3 >"$out/PYTHON_NAMES.txt"
for dir in /usr/bin /bin;do
 for p in "$dir"/python*;do if [[ -e $p ]];then basename "$p" >>"$out/PYTHON_NAMES.txt";fi;done
done
sort -u "$out/PYTHON_NAMES.txt" -o "$out/PYTHON_NAMES.txt"
while IFS= read -r name;do [[ $name =~ ^python[A-Za-z0-9._+-]*$ ]];ln -s "$packet/guard_python.sh" "$base/path/$name";done <"$out/PYTHON_NAMES.txt"
export PATH=$base/path:/usr/bin:/bin
export E2E_PYTHON_DENY_LOG=$out/python.runtime.nul
: >"$E2E_PYTHON_DENY_LOG";: >"$out/python.controls.nul"
while IFS= read -r name;do
 [[ $(command -v "$name") == "$base/path/$name" ]]
 [[ $(readlink -f "$(command -v "$name")") == "$packet/guard_python.sh" ]]
 [[ -x "$base/path/$name" ]]
 sha256sum "$base/path/$name" >>"$out/PYTHON_GUARDS.sha256"
 set +e;E2E_PYTHON_DENY_LOG="$out/python.controls.nul" "$name" --controlled-deny-probe >"$out/$name.control.stdout" 2>"$out/$name.control.stderr";rc=$?;set -e
 printf '%s\n' "$rc" >"$out/$name.control.status";[[ $rc == 125 ]]
done <"$out/PYTHON_NAMES.txt"
[[ ! -s "$E2E_PYTHON_DENY_LOG" ]]
