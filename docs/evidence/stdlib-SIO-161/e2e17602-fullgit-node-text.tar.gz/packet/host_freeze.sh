#!/bin/bash
# Stage/export only. No sbatch call exists in this controller.
set -euo pipefail
H=/tmp/SIO161-E2E-node01
P=/workspace/.tmp/SIO161-E2E-node01
WT=/workspace/sounio-SIO275-fulltree-node-20261026
HEAD=0d7d349cc8d02bfc44fb8ded1507ff83ada8941b
B=/scratch/sounio-stdlib-inference-scale-20261024/SIO161-E2E-node01
W=(kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
WI=(kubectl -n beagle exec -i sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server --)
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
mkdir -p "$H";mkdir "$H/FREEZE_ATTEMPT"
exec > >(tee "$H/FREEZE_ATTEMPT/stdout.log") 2> >(tee "$H/FREEZE_ATTEMPT/stderr.log" >&2)
trap 'echo $? >"$H/FREEZE_ATTEMPT/STATUS"' EXIT
"${R[@]}" bash -c 'set -euo pipefail;id;[[ $(id -u) == 1000 ]];df -Pk /scratch;free -k;[[ $(df -Pk /scratch | awk "NR==2 {print \$4}") -ge 20971520 ]];squeue -u sounio -h -o "%i|%j|%T|%P"' >"$H/FREEZE_ATTEMPT/resources.txt"
"${WI[@]}" bash -s -- "$P" "$WT" "$HEAD" <<'WORKSPACE'
set -euo pipefail
P=$1;WT=$2;HEAD=$3;N=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node
[[ $(git -C "$WT" rev-parse HEAD) == "$HEAD" && -z $(git -C "$WT" status --porcelain=v1) ]]
df -Pk "$P";[[ $(df -Pk "$P" | awk 'NR==2 {print $4}') -ge 2097152 ]]
for f in source_custody.mjs capture_rows.mjs trace_env.sh guard_python.sh install_guards.sh verify_guards.sh toolchain_manifest.sh test_hook.mjs test_capture.mjs verify_e2e.mjs reproduce_rows.mjs host_freeze.sh;do cp "$P/$f" "$P/packet/";done
cp "$P/worker.sbatch.in" "$P/packet/worker.sbatch"
cp /workspace/.tmp/SIO161-joint01/REVIEW04/NODE_RUNTIME_BASELINE.sha256 "$P/packet/"
cp /workspace/.tmp/SIO275-source-composition01/{COMPOSITION_PROOF.json,FULL_GIT_OBJECTS.json,STDLIB_CENSUS.json,VERIFY_COMPOSITION.mjs} "$P/packet/"
chmod 755 "$P/packet/guard_python.sh"
"$N" "$P/source_custody.mjs" verify-workspace "$WT" "$P/packet" "$P/WORKSPACE.before-export.json"
git -C "$WT" -c tar.umask=0022 archive --format=tar "$HEAD" >"$P/source.tar"
"$N" "$P/source_custody.mjs" verify-workspace "$WT" "$P/packet" "$P/WORKSPACE.after-export.json"
cmp "$P/WORKSPACE.before-export.json" "$P/WORKSPACE.after-export.json"
sha256sum "$P/source.tar" >"$P/packet/SOURCE_ARCHIVE.sha256"
(cd "$P/packet";find . -type f ! -name PACKET.sha256 -print0 | sort -z | xargs -0 sha256sum >PACKET.sha256)
sha256sum "$P/packet/PACKET.sha256" "$P/packet/SOURCE_CONFIG.json" "$P/packet/GIT_TREE.raw.nul" "$P/packet/worker.sbatch" >"$P/FREEZE_SEALS.txt"
WORKSPACE
"${R[@]}" mkdir "$B"
"${R[@]}" mkdir "$B/source" "$B/packet"
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- cat "$P/source.tar" |
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xf - -C "$B/source"
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- tar -cf - -C "$P/packet" . |
 kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- tar -xf - -C "$B/packet"
"${R[@]}" bash -c 'set -euo pipefail;B=$1;N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node;(cd "$B/packet";sha256sum -c PACKET.sha256);sha256sum -c "$B/packet/NODE_RUNTIME_BASELINE.sha256";echo "a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3  /scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready" | sha256sum -c -;echo "81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90  $N" | sha256sum -c -;"$N" "$B/packet/source_custody.mjs" verify "$B/source" "$B/packet" "$B/SOURCE.stage.json";bash -n "$B/packet/worker.sbatch";sha256sum "$B/packet/PACKET.sha256";echo STAGED_FULLGIT_NOT_SUBMITTED' stage "$B" >"$H/FREEZE_ATTEMPT/worker-stage.txt"
"${W[@]}" bash -c 'set -euo pipefail;P=$1;WT=$2;N=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node;"$N" "$P/source_custody.mjs" verify-workspace "$WT" "$P/packet" "$P/WORKSPACE.after-transfer.json";cmp "$P/WORKSPACE.before-export.json" "$P/WORKSPACE.after-transfer.json";cat "$P/FREEZE_SEALS.txt"' stage "$P" "$WT" >"$H/FREEZE_ATTEMPT/workspace-final.txt"
echo FROZEN_NOT_SUBMITTED
