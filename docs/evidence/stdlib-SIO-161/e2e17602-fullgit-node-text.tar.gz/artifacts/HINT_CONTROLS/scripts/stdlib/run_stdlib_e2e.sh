#!/bin/bash
set -euo pipefail
RESULTS_FILE=$(mktemp)
trap 'rm -f "$RESULTS_FILE"' EXIT
printf 'flags=%s\n' "$-"
printf 'debugtrap=%s\n' "$(trap -p DEBUG)"
case $1 in
 rc0) printf 'ok\n';printf 'err0\n' >&2;exit 0;;
 rc1) printf 'fail\n';printf 'err1\n' >&2;exit 1;;
 rc124) printf 'bound\n';printf 'err124\n' >&2;exit 124;;
 substitution) value=$(printf 'first';false;printf 'last');printf 'value=%s status=%s\n' "$value" "$?";;
 handled) rc=0;false || rc=$?;printf 'handled=%s\n' "$rc";if value=$(printf 'captured';exit 7);then echo impossible;else printf 'subfailure=%s value=%s\n' "$?" "$value";fi;;
 errexit) printf 'before-errexit\n';false;echo UNREACHABLE;;
 timeout) printf 'before-timeout\n';sleep 2;;
 hint-failure) printf 'hint-unavailable-body-unaffected\n';exit 0;;
esac
