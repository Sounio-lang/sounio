#!/bin/bash
set -euo pipefail
RESULTS_FILE=$(mktemp)
trap 'rm -f "$RESULTS_FILE"' EXIT
printf 'pass\tfixture-only.sio\tcheck-only\t\t\t\t0\tb2s=\n' >>"$RESULTS_FILE"
sleep 1
