#!/usr/bin/env bash
set -euo pipefail
cd /tmp/SIO161-joint01
exec 9>FREEZE.lock
flock -n 9 || exit 75
set -o noclobber
printf '%s\n' 3c7c8073411a7e7254d0d9424f59f8e49eb49180 > FREEZE_ATTEMPT
set +e
bash /tmp/SIO161-joint01/host_freeze.sh 3c7c8073411a7e7254d0d9424f59f8e49eb49180 > freeze.stdout 2> freeze.stderr
freeze_rc=$?
set -e
printf '%s\n' "$freeze_rc" > FREEZE_STATUS
exit "$freeze_rc"
