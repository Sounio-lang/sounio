#!/usr/bin/env bash
set -euo pipefail
cd /tmp/SIO161-joint01
exec 9>SUBMIT_CONTROLLER.lock
flock -n 9 || exit 75
set -o noclobber
printf '%s\n' 3c7c8073411a7e7254d0d9424f59f8e49eb49180 > SUBMIT_CONTROLLER_ATTEMPT
set +e
bash /tmp/SIO161-joint01/host_submit.sh 3c7c8073411a7e7254d0d9424f59f8e49eb49180 > submit.stdout 2> submit.stderr
submit_rc=$?
set -e
printf '%s\n' "$submit_rc" > SUBMIT_CONTROLLER_STATUS
exit "$submit_rc"
