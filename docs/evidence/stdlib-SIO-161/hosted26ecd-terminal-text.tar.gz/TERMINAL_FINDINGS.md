# Exact-head hosted terminal triage

Run40248656923 belongs to PR head26ecd3cd1bea2a70b7166f85c32c676d1d01b099.
Actual checkout/compiler receipt is GitHub merge54e02c8f1f755f322b3e262a1f3bddb18df627f7
of that head into maina886ce9bdb9b6b9ca4f748028fca0248bfa9f125. Workflow bytes
are equal between head/merge; the parent, ChangedTests, v2 harness and native
phase helper match the tested compiler input catalog. Compiler SHA256 is
b30def13149e1d95d07dde2cf107a82c7bc99e8ec8c910d8b7f6098f5ef8d2c9.

Main run terminal conclusion is CANCELLED. The F64 job121336010502 is SUCCESS.
Deep121337549946 is CANCELLED, and CI Decision121348641869 is FAILURE at
Require selected deep scientific replay, with the explicit selected-deep guard.

## F64 selection and actual phases

f64-job.log lines2808-2837 record12 selected,12pass/0fail/0skip, parallel4.
The selection compares base26c to head26ecd even though execution uses the tested
merge. Eleven positives have retained split receipts: compilation0, native0 and
result0, with separate30s budgets. Compiler/source/ELF before/after verification
text is retained. The twelfth selected case is compile-fail interval_contract_private;
this subset does not retain a separate split-phase receipt for that negative.
Lines2838-2872 show a DIFFERENT17-case known-failure recheck:0newpasses,
0unexpectedfailures,17knownfailures. Do not promote them into17native passes.
F64_PHASE_SUMMARY.json preserves all11 commands/statuses/timestamps/identities.

## Why Deep was cancelled

The provider check annotation explicitly reports: The job has exceeded the
maximum execution time of45m0s. This is direct timeout evidence, rather than an
inference from cancelled. tested-merge-ci.yml line2137 configures45min.
Job starts00:25:59Z, completes01:11:16Z; replay step00:26:34Z to01:11:12Z.
deep-job.log line5733 reports operation cancellation. No rerun was requested.

The compact scientific artifact has509 completed records, all0, including15
focused child passes. Last completed child is genomics_batch. The parent then
creates scientific-native-workflows topstdout/stderr (both empty), invokes that
16th child at source26-deep.sh line348 and never records completion at349.
Interval17 and phonon18 do not complete. Global3170 is ABSENT from this source;
it is not a19th selected child here. No parentSTATUS/final custody loop exists.
Consequently this is an interrupted successful prefix, not a full scientific pass
and not evidence of a numerical failure in the in-flight child.

The exact inner figure workflow/compile/native phase is unresolved: workflow
upload lines2183-2196 retain top-level files only and omit child subdirectories.
An empty child stdout does not prove where the child was executing. Artifact
12621428155 ZIP SHA256f701813119cd959e1fe2a553be4e643f7baeefad0aa2930f99342d1ad9c05377
matches the hosted upload digest; all774 members extracted are text/catalogs.

## Bounded next action for the lease owner

Send this evidence to sio-119-ci-layers-fresh, owner of .github/workflows/ci.yml.
Request a metadata-only change retaining recursive per-child RESULT/STATUS,
phase commands/timestamps, compile/native logs and resources, with an explicit
text-only whitelist excluding native ELF/source-snapshot payloads. Add an
append-only child start/finish ledger under the root-owned parent with normal
coordination. Keep all18 selected gates and the required-deep decision intact.
This closes the demonstrated evidence gap before considering complete-coverage
partitions or a justified budget; it does not authorize blindly increasing45min,
turning cancellation into pass or manually rerunning the old source. Node3175
and global3170 retain their own sources/qualification requirements.

## Custody limits

Selected F64 text was fetched by16 explicit HTTP ranges totaling74928 bytes,
plus863467 central-directory/tail bytes;303 members passed ZIP CRC32 and have
fresh SHA256 records. Full84MB ZIP/ELF payloads were not downloaded/rehashed.
Suffix ranges/API range forwarding initially failed; explicit offsets succeeded.
No credentials or signed download URLs are stored in receipts. No Python,
compiler/native execution, source/workflow edits, new jobs or quota changes were
performed by this read-only triage. Hosted logs describe earlier independent
workflow executions; reading them does not re-execute their legacy tooling.
