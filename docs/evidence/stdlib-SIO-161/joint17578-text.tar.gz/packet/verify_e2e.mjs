#!/usr/bin/env node
// Validate a fresh operational E2E measurement, including a failing real suite.
import fs from 'node:fs';
import path from 'node:path';
function census(root, relative='tests/stdlib') {
 const names=[];
 for(const item of fs.readdirSync(path.join(root,relative),{withFileTypes:true})) {
  if(item.name.startsWith('.'))continue;
  const rel=relative+'/'+item.name;
  if(item.isDirectory())names.push(...census(root,rel));
  else if(item.name.endsWith('.sio'))names.push(rel);
 }
 return names.sort();
}
const [input, output, root, runnerCode, started] = process.argv.slice(2);
const receipt = { schema: 'sounio.stdlib.e2e.receipt.v1', attempted: true,
 runner_rc: Number(runnerCode), measurement: 'unavailable', totals: null, errors: [] };
try {
 const obj = JSON.parse(fs.readFileSync(input, 'utf8'));
 const need = (value, message) => { if (!value) throw new Error(message); };
 need(obj.schema === 'sounio.stdlib.e2e.result.v1', 'schema mismatch');
 need(obj.command === 'bash scripts/stdlib/run_stdlib_e2e.sh', 'command mismatch');
 need(obj.context.root_dir === root && obj.context.souc_bin === root + '/bin/souc'
  && obj.context.stdlib_path === root + '/stdlib' && obj.context.filter === '', 'unfiltered frozen-source context mismatch');
 need(Array.isArray(obj.results), 'results array required');
 const paths=obj.results.map(r=>r.test_path);
 need(paths.every(p=>typeof p==='string') && new Set(paths).size===paths.length,'duplicate/invalid test_path');
 const expectedPaths=census(root);
 need(expectedPaths.length>0 && JSON.stringify([...paths].sort())===JSON.stringify(expectedPaths),'E2E path set differs from complete frozen tests/stdlib census');
 const scaleRows = obj.results.filter(r => r.test_path === 'tests/stdlib/genomics_batch/scale_main.sio');
 need(scaleRows.length === 1 && scaleRows[0].status === 'pass' && scaleRows[0].mode === 'check-only', 'allocated scale caller must pass check-only in generic E2E');
 const totals = obj.totals;
 for (const key of ['pass', 'fail', 'skip', 'total']) need(Number.isSafeInteger(totals[key]) && totals[key] >= 0, 'invalid total: ' + key);
 need(totals.total > 0 && totals.total === totals.pass + totals.fail + totals.skip, 'empty/inconsistent totals');
 need(Array.isArray(obj.results) && obj.results.length === totals.total, 'empty/inconsistent result rows');
 for (const status of ['pass', 'fail', 'skip']) need(obj.results.filter(r => r.status === status).length === totals[status], 'result status count mismatch: ' + status);
 need(JSON.stringify(obj.failures) === JSON.stringify(obj.results.filter(r => r.status === 'fail')), 'failure projection mismatch');
 const ignored = obj.results.filter(r => r.mode === 'ignore').map(r => ({ test_path: r.test_path, reason: r.reason, owner: r.owner, unblock_condition: r.unblock_condition }));
 need(JSON.stringify(obj.ignored) === JSON.stringify(ignored), 'ignored projection mismatch');
 const generated = Date.parse(obj.generated_at_utc);
 need(obj.generated_at_utc.endsWith('Z') && Number.isFinite(generated) && generated >= Date.parse(started)
  && generated <= Date.now() + 1000, 'measurement timestamp outside actual run');
 need(Number.isInteger(receipt.runner_rc) && receipt.runner_rc >= 0, 'runner status metadata');
 need(!(receipt.runner_rc === 0 && totals.fail > 0), 'runner returned success with failed results');
 receipt.measurement = 'valid'; receipt.totals = totals;
 receipt.generated_at_utc = obj.generated_at_utc; receipt.result_rows = obj.results.length; receipt.frozen_census_count=expectedPaths.length;
} catch (error) { receipt.errors.push(error.message); }
fs.writeFileSync(output, JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt));
if (receipt.measurement !== 'valid') process.exitCode = 1;
