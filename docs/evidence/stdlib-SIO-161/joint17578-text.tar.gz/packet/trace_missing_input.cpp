// Operational syscall witness only; no scientific computation.
#if !defined(__linux__) || !defined(__x86_64__)
#error This witness supports only x86_64 Linux.
#endif
#include <sys/ptrace.h>
#include <sys/prctl.h>
#include <linux/audit.h>
#include <sys/wait.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
struct Child {
    pid_t pid{-1};
    ~Child() { if (pid > 0) { kill(pid, SIGKILL); while (waitpid(pid, nullptr, 0) < 0 && errno == EINTR) {} } }
};
void checked(long result, const char* what) {
    if (result == -1) throw std::runtime_error(std::string(what) + ": " + std::strerror(errno));
}
std::string child_string(pid_t pid, std::uint64_t address) {
    std::string result;
    for (std::size_t offset = 0; offset < 4096; offset += sizeof(long)) {
        errno = 0;
        const long word = ptrace(PTRACE_PEEKDATA, pid, address + offset, nullptr);
        if (word == -1 && errno != 0) throw std::runtime_error("unreadable syscall pathname");
        char bytes[sizeof(long)]; std::memcpy(bytes, &word, sizeof(word));
        for (char byte : bytes) { if (byte == '\0') return result; result.push_back(byte); }
    }
    throw std::runtime_error("unterminated syscall pathname");
}
int fixture(const std::string& mode) {
    if (mode == "--fixture-noopen") return 1;
    if (mode == "--fixture-other") { (void)syscall(SYS_openat, AT_FDCWD, "other_missing.txt", O_RDONLY, 0); return 1; }
    if (mode == "--fixture-open") { (void)syscall(SYS_open, "shard_start.txt", O_RDONLY, 0); return 1; }
    if (mode == "--fixture-openat") { (void)syscall(SYS_openat, AT_FDCWD, "shard_start.txt", O_RDONLY, 0); return 1; }
    if (mode == "--fixture-wrong-exit") { (void)syscall(SYS_openat, AT_FDCWD, "shard_start.txt", O_RDONLY, 0); return 0; }
    return 64;
}
}
int main(int argc, char** argv) {
    if (argc == 2 && std::string(argv[1]).starts_with("--fixture-")) return fixture(argv[1]);
    if (argc < 3) { std::cerr << "usage: witness RECEIPT EXECUTABLE [ARGUMENTS...]\n"; return 64; }
    try {
        std::ofstream log(argv[1], std::ios::out | std::ios::trunc);
        if (!log) throw std::runtime_error("cannot create witness receipt");
        log << "schema=sounio.missing-input-syscall.v1\nplatform=x86_64-linux\n";
        alarm(20); // Independent wall bound; EXITKILL/PDEATHSIG prevent a surviving tracee.
        Child child; child.pid = fork(); checked(child.pid, "fork");
        if (child.pid == 0) {
            if (prctl(PR_SET_PDEATHSIG, SIGKILL) == -1 || getppid() == 1) _exit(126);
            if (ptrace(PTRACE_TRACEME, 0, nullptr, nullptr) == -1) _exit(126);
            raise(SIGSTOP);
            execv(argv[2], argv + 2); _exit(127);
        }
        int status = 0;
        checked(waitpid(child.pid, &status, 0), "initial waitpid");
        if (!WIFSTOPPED(status) || WSTOPSIG(status) != SIGSTOP) throw std::runtime_error("child did not establish tracing");
        checked(ptrace(PTRACE_SETOPTIONS, child.pid, nullptr,
            PTRACE_O_TRACESYSGOOD | PTRACE_O_TRACEEXEC | PTRACE_O_EXITKILL), "setoptions");
        bool target_open = false;
        long current_syscall = -1;
        unsigned witnessed = 0, stops = 0;
        int deliver = 0;
        for (;;) {
            checked(ptrace(PTRACE_SYSCALL, child.pid, nullptr, deliver), "syscall resume"); deliver = 0;
            pid_t waited;
            do { waited = waitpid(child.pid, &status, 0); } while (waited < 0 && errno == EINTR);
            checked(waited, "waitpid");
            if (WIFEXITED(status)) {
                const int code = WEXITSTATUS(status); child.pid = -1;
                const bool accepted = code == 1 && witnessed > 0;
                log << "child_exit=" << code << "\nmissing_target_count=" << witnessed
                    << "\naccepted=" << (accepted ? "true" : "false") << '\n';
                log.flush(); if (!log) throw std::runtime_error("receipt write failed");
                std::cout << "MISSING_INPUT_WITNESS accepted=" << accepted << " child_exit=" << code << " witnesses=" << witnessed << '\n';
                return accepted ? 0 : 2;
            }
            if (WIFSIGNALED(status)) { child.pid = -1; throw std::runtime_error("child terminated by signal " + std::to_string(WTERMSIG(status))); }
            if (!WIFSTOPPED(status)) throw std::runtime_error("unexpected child state");
            if (++stops > 200000) throw std::runtime_error("syscall stop bound exceeded");
            const int signal = WSTOPSIG(status);
            if (signal == (SIGTRAP | 0x80)) {
                __ptrace_syscall_info info{};
                checked(ptrace(PTRACE_GET_SYSCALL_INFO, child.pid, sizeof(info), &info), "get syscall info");
                if (info.arch != AUDIT_ARCH_X86_64) throw std::runtime_error("unexpected tracee syscall architecture");
                if (info.op == PTRACE_SYSCALL_INFO_ENTRY) {
                    current_syscall = static_cast<long>(info.entry.nr); target_open = false;
                    if (current_syscall == SYS_clone || current_syscall == SYS_fork || current_syscall == SYS_vfork
#ifdef SYS_clone3
                        || current_syscall == SYS_clone3
#endif
                    ) throw std::runtime_error("unexpected child process creation");
                    if (current_syscall == SYS_open || current_syscall == SYS_openat) {
                        const auto address = current_syscall == SYS_open ? info.entry.args[0] : info.entry.args[1];
                        target_open = child_string(child.pid, address) == "shard_start.txt";
                    }
                } else if (info.op == PTRACE_SYSCALL_INFO_EXIT) {
                    if (target_open) {
                        const auto result = info.exit.rval;
                        log << "syscall=" << (current_syscall == SYS_open ? "open" : "openat")
                            << " path=shard_start.txt result=" << result << '\n';
                        if (result == -ENOENT && info.exit.is_error) ++witnessed;
                    }
                    target_open = false;
                } else {
                    throw std::runtime_error("missing explicit syscall entry/exit classification");
                }
            } else if (signal == SIGTRAP && (status >> 16) == PTRACE_EVENT_EXEC) {
                // Exec event is not a syscall stop; explicit GET_SYSCALL_INFO classifies both sides.
            } else {
                deliver = signal;
            }
        }
    } catch (const std::exception& error) {
        std::cerr << "MISSING_INPUT_WITNESS_REFUSE: " << error.what() << '\n'; return 3;
    }
}
