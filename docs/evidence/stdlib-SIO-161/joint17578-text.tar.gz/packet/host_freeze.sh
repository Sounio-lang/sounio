#!/usr/bin/env bash
# PREPARED ONLY. Root explicitly invokes this AFTER final source review/commit.
source "$(dirname "$0")/common.sh"
[[ $# == 1 ]] || exit 64
expected=$1;need_head "$expected"
(cd "$HOST";sha256sum -c CONTROLLER_PREPARED.sha256)
workspace_exec cat "$CONTROL/CONTROLLER_PREPARED.sha256" | cmp - "$HOST/CONTROLLER_PREPARED.sha256"
workspace_exec bash -c 'cd "$1" && sha256sum -c CONTROLLER_PREPARED.sha256' _ "$CONTROL"
worker_exec test ! -e "$BASE/source"
worker_exec test ! -e "$BASE/packet"
workspace_exec "$WS_NODE" "$CONTROL/freeze.mjs" prepare "$ROOT" "$expected" "$CONTROL/freeze"
# Verify workspace bytes immediately before source transfer.
workspace_exec "$WS_NODE" "$CONTROL/freeze.mjs" verify-workspace "$ROOT" "$CONTROL/freeze" "$CONTROL/WORKSPACE.pre-transfer.json"
worker_exec mkdir "$BASE/source" "$BASE/packet"
workspace_exec bash -c 'cd "$1" && exec tar --null --verbatim-files-from -T "$2/PATHS.nul" -cf -' _ "$ROOT" "$CONTROL/freeze" \
 | worker_input tar -xpf - --no-same-owner -C "$BASE/source"
workspace_exec bash -c 'cd "$1" && exec tar -cf - .' _ "$CONTROL/freeze" \
 | worker_input tar -xf - -C "$BASE/packet"
worker_exec bash -c 'cd "$1" && sha256sum -c PACKET.sha256' _ "$BASE/packet" \
 > "$HOST/PACKET.worker.verify"
worker_exec bash -c 'cd "$1" && sha256sum -c "$2/SOURCE.sha256"' _ "$BASE/source" "$BASE/packet" \
 > "$HOST/SOURCE.worker.verify"
worker_exec "$NODE" "$BASE/packet/freeze.mjs" verify-source "$BASE/source" "$BASE/packet" "$BASE/SOURCE.staged.observed.json"
workspace_exec "$WS_NODE" "$CONTROL/freeze.mjs" verify-workspace "$ROOT" "$CONTROL/freeze" "$CONTROL/WORKSPACE.post-transfer.json"
printf '%s\n' "$expected" | workspace_input tee "$CONTROL/FROZEN_OK"
printf '%s\n' "$expected" | worker_input tee "$BASE/FROZEN_OK"
worker_exec sha256sum "$BASE/packet/PACKET.sha256" > "$HOST/PACKET.seal.sha256"
echo "FROZEN_NOT_SUBMITTED head=$expected"
