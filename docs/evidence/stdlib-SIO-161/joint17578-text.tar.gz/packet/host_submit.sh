#!/usr/bin/env bash
# PREPARED ONLY. Root explicitly invokes after reviewing frozen receipts.
source "$(dirname "$0")/common.sh"
[[ $# == 1 ]] || exit 64
expected=$1;need_head "$expected"
(cd "$HOST";sha256sum -c CONTROLLER_PREPARED.sha256)
worker_exec sha256sum "$BASE/packet/PACKET.sha256" | cmp - "$HOST/PACKET.seal.sha256"
packet_sha=$(cut -d" " -f1 "$HOST/PACKET.seal.sha256")
[[ "$(workspace_exec cat "$CONTROL/FROZEN_OK")" == "$expected" ]]
[[ "$(worker_exec cat "$BASE/FROZEN_OK")" == "$expected" ]]
workspace_exec "$WS_NODE" "$CONTROL/freeze.mjs" verify-workspace "$ROOT" "$CONTROL/freeze" "$CONTROL/WORKSPACE.before-submit.json"
worker_exec bash -c 'cd "$1" && sha256sum -c PACKET.sha256' _ "$BASE/packet" > "$HOST/PACKET.before-submit.verify"
# Exclusively persist the attempt before sbatch. An uncertain response is NEVER
# retried automatically; reconcile sacct/submission receipts before any action.
workspace_exec bash -c 'set -o noclobber; printf "%s\n" "$2" > "$1/SUBMISSION_ATTEMPT"' _ "$CONTROL" "$expected"
set +e
worker_exec sbatch --parsable "$BASE/packet/worker.sbatch" "$expected" "$packet_sha" > "$HOST/SUBMISSION.reply" 2> "$HOST/SUBMISSION.stderr"
submission_rc=$?
set -e
cat "$HOST/SUBMISSION.reply" | workspace_input tee "$CONTROL/SUBMISSION.reply"
cat "$HOST/SUBMISSION.stderr" | workspace_input tee "$CONTROL/SUBMISSION.stderr"
printf '%s\n' "$submission_rc" | workspace_input tee "$CONTROL/SUBMISSION.status"
[[ "$submission_rc" == 0 ]] || exit "$submission_rc"
job=$(sed 's/;.*//' "$HOST/SUBMISSION.reply")
[[ "$job" =~ ^[1-9][0-9]*$ ]] || { echo 'Uncertain sbatch response; reconcile, do not retry' >&2;exit 75; }
printf '%s\n' "$job" | workspace_input tee "$CONTROL/JOB_ID"
printf '%s\n' "$job" | worker_input tee "$BASE/JOB_ID"
tmux new-session -d -s SIO161-joint01-controller "bash $HOST/host_monitor.sh $expected $job > $HOST/monitor.stdout 2> $HOST/monitor.stderr"
echo "SUBMITTED job=$job head=$expected monitor=t560:SIO161-joint01-controller"
