#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
[[ $# == 2 ]] || exit 64
expected=$1;job=$2;need_head "$expected"
[[ "$job" =~ ^[1-9][0-9]*$ ]] || exit 64
exec 9>"$HOST/monitor.lock"
flock -n 9 || exit 75
deadline=$(( $(date +%s) + 6000 ))
while :;do
 worker_exec sacct -j "$job" -X -n -P --format=JobID,State,Elapsed,ExitCode > "$HOST/sacct.current.txt"
 row=$(awk -F'|' -v j="$job" '$1==j{print;exit}' "$HOST/sacct.current.txt")
 phase=$(printf '%s\n' "$row" | cut -d'|' -f2)
 case "$phase" in
  ""|PENDING|RUNNING|CONFIGURING|COMPLETING|SUSPENDED|REQUEUED|RESIZING) ;;
  *) break;;
 esac
 if (( $(date +%s) > deadline ));then
  echo 'Monitor deadline reached; job ID preserved, no cancel or resubmit' >&2
  printf '75\n' | workspace_input tee "$CONTROL/MONITOR_STATUS"
  exit 75
 fi
 sleep 20
done
cat "$HOST/sacct.current.txt" | workspace_input tee "$CONTROL/JOB_TERMINAL.txt"
cat "$HOST/sacct.current.txt" | worker_input tee "$BASE/JOB_TERMINAL.txt"
set +e
workspace_exec "$WS_NODE" "$CONTROL/freeze.mjs" verify-workspace "$ROOT" "$CONTROL/freeze" "$CONTROL/WORKSPACE.terminal.json" \
 > "$HOST/WORKSPACE.terminal.stdout" 2> "$HOST/WORKSPACE.terminal.stderr"
workspace_rc=$?
set -e
cat "$HOST/WORKSPACE.terminal.stdout" | workspace_input tee "$CONTROL/WORKSPACE.terminal.stdout"
cat "$HOST/WORKSPACE.terminal.stderr" | workspace_input tee "$CONTROL/WORKSPACE.terminal.stderr"
# Only text receipts return to the workspace. Original source/ELFs/results stay.
worker_exec bash -c 'cd "$1"; for f in artifacts/ALL_STATUS artifacts/RESULTS.tsv artifacts/EXECUTION_STATUS.txt artifacts/SOURCE_HEAD artifacts/e2e/receipt.v1.json artifacts/e2e/measured.v1.json JOB_TERMINAL.txt; do [[ -f "$f" ]] && printf "%s\0" "$f"; done' _ "$BASE" \
 > "$HOST/terminal.paths.nul"
cat "$HOST/terminal.paths.nul" | worker_input bash -c 'cd "$1" && tar --null -T - -cf - | gzip -n' _ "$BASE" \
 | workspace_input tee "$CONTROL/terminal-text.tar.gz" > /dev/null
worker_status=$(worker_exec cat "$BASE/artifacts/ALL_STATUS" 2>/dev/null || printf 'missing')
overall=1
if [[ "$phase" == COMPLETED && "$worker_status" == 0 && "$workspace_rc" == 0 ]];then overall=0;fi
printf 'worker_status=%s\nworkspace_catalog_rc=%s\ncontroller_status=%s\n' "$worker_status" "$workspace_rc" "$overall" \
 | workspace_input tee "$CONTROL/CONTROLLER_STATUS.txt"
printf '%s\n' "$overall" | workspace_input tee "$CONTROL/MONITOR_STATUS"
echo "JOINT_TERMINAL job=$job state=$phase worker=$worker_status workspace=$workspace_rc overall=$overall"
exit "$overall"
