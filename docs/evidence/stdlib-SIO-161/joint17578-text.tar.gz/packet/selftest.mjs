#!/usr/bin/env node
// Operational controller controls only. No source freeze, compiler, or Slurm job.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
const base=path.dirname(fileURLToPath(import.meta.url));
const dir=fs.mkdtempSync(path.join(base,'selftest-'));
let cases=0;
function invoke(file,args,name,expected){
 const p=spawnSync(process.execPath,[path.join(base,file),...args],{encoding:'utf8'});
 fs.writeFileSync(path.join(dir,name+'.stdout'),p.stdout);
 fs.writeFileSync(path.join(dir,name+'.stderr'),p.stderr);
 fs.writeFileSync(path.join(dir,name+'.status'),String(p.status)+'\n');
 assert.equal(p.status,expected,name+': '+p.stderr);
 cases++;console.log('PASS '+name);
}
const root=path.join(dir,'source'),packet=path.join(dir,'packet');
fs.mkdirSync(root);fs.mkdirSync(packet);fs.writeFileSync(path.join(root,'a'),'metadata-only\n');
fs.writeFileSync(path.join(root,'b'),'metadata-only\n');fs.symlinkSync('a',path.join(root,'link'));
const entries=['a','b','link'].map(name=>{
 const p=path.join(root,name),s=fs.lstatSync(p);
 return{path:name,kind:s.isSymbolicLink()?'symlink':'file',mode:s.mode&0o777,link:s.isSymbolicLink()?fs.readlinkSync(p):null,
 sha256:createHash('sha256').update(fs.readFileSync(p)).digest('hex')};
});
fs.writeFileSync(path.join(packet,'SOURCE_FILES.json'),JSON.stringify(entries,null,2)+'\n');
const verify=name=>[root,packet,path.join(dir,name+'.observed.json')];
invoke('freeze.mjs',['verify-source',...verify('source-good')],'source-good',0);
fs.writeFileSync(path.join(root,'extra'),'extra');
invoke('freeze.mjs',['verify-source',...verify('source-added')],'source-added',1);
fs.unlinkSync(path.join(root,'extra'));
fs.writeFileSync(path.join(root,'a'),'changed');
invoke('freeze.mjs',['verify-source',...verify('source-content')],'source-content',1);
fs.writeFileSync(path.join(root,'a'),'metadata-only\n');
fs.unlinkSync(path.join(root,'link'));fs.symlinkSync('b',path.join(root,'link'));
invoke('freeze.mjs',['verify-source',...verify('source-symlink')],'source-symlink',1);
fs.unlinkSync(path.join(root,'link'));fs.symlinkSync('a',path.join(root,'link'));
invoke('freeze.mjs',['prepare',root,'NOT_FINAL_HEAD',path.join(dir,'must-not-freeze')],'no-final-head',1);
assert.equal(fs.existsSync(path.join(dir,'must-not-freeze')),false);
fs.mkdirSync(path.join(root,'tests/stdlib/genomics_batch'),{recursive:true});
fs.writeFileSync(path.join(root,'tests/stdlib/synthetic-metadata-only.sio'),'// SYNTHETIC_METADATA_ONLY\n');
fs.writeFileSync(path.join(root,'tests/stdlib/genomics_batch/scale_main.sio'),'// SYNTHETIC_METADATA_ONLY\n');
const started=new Date(Date.now()-1000).toISOString();
function document(failing=false){
 const row={status:failing?'fail':'pass',test_path:'tests/stdlib/synthetic-metadata-only.sio',mode:'check-only',reason:failing?'synthetic':'',owner:'',unblock_condition:'',exit_code:failing?1:0,detail_excerpt:''};
 return{schema:'sounio.stdlib.e2e.result.v1',generated_at_utc:new Date().toISOString(),command:'bash scripts/stdlib/run_stdlib_e2e.sh',
 context:{root_dir:root,souc_bin:root+'/bin/souc',stdlib_path:root+'/stdlib',filter:''},
 totals:{pass:failing?1:2,fail:failing?1:0,skip:0,total:2},results:[row,{...row,status:'pass',test_path:'tests/stdlib/genomics_batch/scale_main.sio',mode:'check-only',exit_code:0,reason:''}],failures:failing?[row]:[],ignored:[]};
}
function e2e(name,obj,runner,expected){
 const input=path.join(dir,name+'.json'),out=path.join(dir,name+'.receipt.json');
 fs.writeFileSync(input,JSON.stringify(obj));
 invoke('verify_e2e.mjs',[input,out,root,String(runner),started],name,expected);
 return JSON.parse(fs.readFileSync(out,'utf8'));
}
assert.equal(e2e('metadata-valid',document(),0,0).measurement,'valid');
assert.equal(e2e('metadata-real-failure',document(true),1,0).runner_rc,1);
e2e('metadata-hidden-failures',document(true),0,1);
let obj=document();obj.results=[];obj.totals={pass:0,fail:0,skip:0,total:0};e2e('metadata-empty',obj,0,1);
obj=document();obj.generated_at_utc='2000-01-01T00:00:00Z';e2e('metadata-stale',obj,0,1);
obj=document();obj.totals.fail=1;e2e('metadata-totals',obj,0,1);
obj=document();obj.context.filter='subset';e2e('metadata-filtered',obj,0,1);
obj=document();obj.failures=[obj.results[0]];e2e('metadata-projection',obj,0,1);
obj=document();obj.results[1].mode='run-pass';e2e('metadata-scale-mode',obj,0,1);
obj=document();obj.results=[obj.results[1]];obj.totals={pass:1,fail:0,skip:0,total:1};e2e('metadata-scale-only-partial',obj,0,1);
obj=document();obj.results=[obj.results[1],obj.results[1]];e2e('metadata-duplicate-path',obj,0,1);
obj=document();obj.results[0].test_path='tests/stdlib/unlisted.sio';e2e('metadata-added-path',obj,0,1);
console.log('JOINT_CONTROLLER_METADATA_SELFTEST_PASS cases='+cases+' synthetic_only=true dir='+dir);
