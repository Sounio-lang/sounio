#!/usr/bin/env bash
# Original external-input caller, never a thousand-gene numerical rerun.
set -euo pipefail
[[ $# == 4 ]] || exit 64
root=$1;packet=$2;out=$3;witness=$4
mkdir "$out";mkdir "$out/empty-cwd"
trap 'scale_probe_rc=$?;printf "%s\n" "$scale_probe_rc" > "$out/STATUS"' EXIT
cd "$root"
old="$packet/scale-main-before.sio"
sha256sum "$old" "$packet/scale-annotation.json" tests/stdlib/genomics_batch/scale_main.sio > "$out/SOURCES.sha256"
sha256sum "$witness" > "$out/WITNESS.before.sha256"
bin/souc check "$old" > "$out/before.check.stdout" 2> "$out/before.check.stderr"
! grep -Eq '^[[:space:]]*error:|error\[E' "$out/before.check."{stdout,stderr}
bin/souc compile "$old" -o "$out/before.elf" > "$out/before.compile.stdout" 2> "$out/before.compile.stderr"
! grep -Eq '^[[:space:]]*error:|error\[E' "$out/before.compile."{stdout,stderr}
chmod +x "$out/before.elf";sha256sum "$out/before.elf" > "$out/ELF.before.sha256"
[[ ! -e "$out/empty-cwd/shard_start.txt" ]]
(cd "$out/empty-cwd";timeout --kill-after=5 15 "$witness" "$out/before.syscalls.txt" "$out/before.elf") \
 > "$out/before.native.stdout" 2> "$out/before.native.stderr"
grep -Fxq 'child_exit=1' "$out/before.syscalls.txt"
grep -Eq '^syscall=open(at)? path=shard_start.txt result=-2$' "$out/before.syscalls.txt"
grep -Fxq 'accepted=true' "$out/before.syscalls.txt"
! grep -Eq 'GENOMICS_BATCH_SCALE_PASS|SCALE_LAYOUT|SCALE_RANGE|SCALE_PROGRESS|SCALE_PROFILE' "$out/before.native.stdout"
bin/souc check tests/stdlib/genomics_batch/scale_main.sio > "$out/after.check.stdout" 2> "$out/after.check.stderr"
! grep -Eq '^[[:space:]]*error:|error\[E' "$out/after.check."{stdout,stderr}
grep -Fxq '//@ check-only' tests/stdlib/genomics_batch/scale_main.sio
sha256sum -c "$out/SOURCES.sha256" > "$out/SOURCES.verify.txt"
sha256sum -c "$out/ELF.before.sha256" > "$out/ELF.verify.txt"
sha256sum -c "$out/WITNESS.before.sha256" > "$out/WITNESS.verify.txt"
echo JOINT_SCALE_MISSING_INPUT_BEFORE_AND_CHECK_ONLY_AFTER_PASS
