#!/usr/bin/env node
// Source-custody metadata only. No scientific calculation, build, or submission.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const controller = path.dirname(fileURLToPath(import.meta.url));
const prefixes = ['stdlib/', 'tests/', 'examples/', 'scripts/stdlib/', 'scripts/lib/'];
const exact = ['bin/souc', 'bin/madaros', 'bin/souc-lean-single-x86_64',
 'bin/souc-lean-single-x86_64.SeedReceipt.json', 'scripts/ci/souc-native-wrapper.sh',
 'artifacts/stdlib/stdlib_e2e_result.v1.json',
 'self-hosted/compiler/lean_single.sio',
 'scripts/ci/canonical_compiler_gate.sh', 'scripts/ci/seed_receipt_provenance_gate.sh',
 'scripts/ci/verify_lean_seed.sh', 'scripts/ci/private_field_borrow_gate.sh',
 'scripts/dev/write_seed_receipt.mjs',
 'docs/evidence/stdlib-SIO-172/before_variance/variance_witness.sio',
 'docs/evidence/stdlib-SIO-172/before_variance/phonon_original.sio',
 'docs/evidence/stdlib-SIO-172/ci_repair_20261025/original_phonon_factor_private.sio'];
const seedSha = '13003a8b9b1bf4bfc64ad8d13eb0795d722888fabef5bbb2913b4f7b83bb454b';
const fixtureSha = 'c02d2ac60c5d2a6ec8b8161e7f1d244ccf47412db3e9943c283493cdac551fe2';
const checksum = data => createHash('sha256').update(data).digest('hex');
function need(value, message) { if (!value) throw new Error(message); }
function git(root, args) { return execFileSync('git', ['-C', root, ...args], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }); }
function state(root) {
 return { head: git(root, ['rev-parse', 'HEAD']).trim(), branch: git(root, ['branch', '--show-current']).trim(),
  porcelain: git(root, ['status', '--porcelain=v1', '--untracked-files=all']), captured_at_utc: new Date().toISOString() };
}
function selected(root) {
 const tracked = new Set(git(root, ['ls-files', '-z']).split('\0').filter(Boolean));
 const names = new Set([...tracked].filter(name => prefixes.some(p => name.startsWith(p)) || exact.includes(name)));
 for (const name of exact) need(names.has(name), 'required tracked input missing: ' + name);
 // Retain tracked symlinks and their exact file targets. Never copy a compiler tree.
 for (const name of names) {
  need(!/[\\\r\n]/.test(name), 'unsupported checksum filename: ' + name);
  const absolute = path.join(root, name), stat = fs.lstatSync(absolute);
  if (stat.isSymbolicLink()) {
   const link = fs.readlinkSync(absolute);
   need(!path.isAbsolute(link), 'absolute input symlink: ' + name);
   const target = path.relative(root, path.resolve(path.dirname(absolute), link));
   need(!target.startsWith('../') && tracked.has(target), 'symlink target must be tracked inside repo: ' + name);
   need(fs.statSync(path.join(root, target)).isFile(), 'symlink directory/invalid target: ' + name);
   names.add(target);
  }
 }
 return [...names].sort();
}
function entry(root, name) {
 const absolute = path.join(root, name), stat = fs.lstatSync(absolute);
 need(stat.isFile() || stat.isSymbolicLink(), 'unexpected source entry: ' + name);
 return { path: name, kind: stat.isSymbolicLink() ? 'symlink' : 'file',
  mode: stat.mode & 0o777, link: stat.isSymbolicLink() ? fs.readlinkSync(absolute) : null,
  sha256: checksum(fs.readFileSync(absolute)) };
}
function walk(root, prefix = '') {
 const entries = [];
 for (const name of fs.readdirSync(path.join(root, prefix)).sort()) {
  const rel = prefix ? prefix + '/' + name : name, stat = fs.lstatSync(path.join(root, rel));
  if (stat.isDirectory()) entries.push(...walk(root, rel)); else entries.push(rel);
 }
 return entries.sort();
}
function write(filename, content) { fs.writeFileSync(filename, content); }
function prepare(root, expected, output) {
 need(/^[0-9a-f]{40}$/.test(expected), 'expected root-final HEAD required');
 need(!fs.existsSync(output), 'fresh freeze receipt path required');
 const observed = state(root);
 need(observed.head === expected && observed.branch === 'devpass/SIO-161-consolidation-20261025', 'HEAD/branch differs from explicit root freeze');
 need(observed.porcelain === '', 'root-final worktree must be clean before freeze');
 const names = selected(root), entries = names.map(name => entry(root, name));
 need(entries.find(e => e.path === 'bin/souc-lean-single-x86_64').sha256 === seedSha, 'fresh tracked seed13003 required');
 need(entries.find(e => e.path === 'artifacts/stdlib/stdlib_e2e_result.v1.json').sha256 === fixtureSha, 'historical fixture identity mismatch');
 need(entries.find(e => e.path === 'self-hosted/compiler/lean_single.sio').sha256 === '702b4bf38036b11d61929a6135af5432de75859ff656361aa95c0dd2bd80b9a5', 'current monolithic compiler source mismatch');
 const oldScale = fs.readFileSync('/workspace/.tmp/SIO161-scale-main-before.sio');
 const scaleIdentityBytes = fs.readFileSync('/workspace/.tmp/SIO161-scale-annotation.json');
 const scaleIdentity = JSON.parse(scaleIdentityBytes);
 const newScale = fs.readFileSync(path.join(root, scaleIdentity.file));
 need(scaleIdentity.header_lines === 3 && scaleIdentity.old_mode === 'run-pass' && scaleIdentity.new_mode === 'check-only', 'scale annotation contract');
 need(checksum(oldScale) === scaleIdentity.before_sha256 && checksum(newScale) === scaleIdentity.after_sha256, 'scale caller identity');
 const body = b => b.toString('utf8').split('\n').slice(3).join('\n');
 need(body(oldScale) === body(newScale) && checksum(body(newScale)) === scaleIdentity.unchanged_body_sha256, 'scale numerical body changed');
 fs.mkdirSync(output);
 write(path.join(output, 'scale-main-before.sio'), oldScale);
 write(path.join(output, 'scale-annotation.json'), scaleIdentityBytes);
 write(path.join(output, 'SOURCE_HEAD'), expected + '\n');
 write(path.join(output, 'WORKSPACE_STATE.before.json'), JSON.stringify(observed, null, 2) + '\n');
 write(path.join(output, 'SOURCE_FILES.json'), JSON.stringify(entries, null, 2) + '\n');
 write(path.join(output, 'SOURCE.sha256'), entries.map(e => e.sha256 + '  ' + e.path + '\n').join(''));
 write(path.join(output, 'PATHS.nul'), names.join('\0') + '\0');
 const controlNames = ['freeze.mjs', 'verify_e2e.mjs', 'worker.sbatch', 'bootstrap.sh', 'scale_probe.sh', 'trace_missing_input.cpp', 'trace_controls.sh', 'toolchain_manifest.sh', 'private_manifests.sh', 'host_freeze.sh', 'host_submit.sh', 'host_monitor.sh', 'common.sh', 'selftest.mjs', 'README.PREPARED.md', 'NODE_BASELINE.sha256', 'NODE_RUNTIME_BASELINE.sha256', 'NODE_BASELINE.ldd.txt', 'NODE_BASELINE.version', 'CONTROLLER_PREPARED.sha256'];
 for (const name of controlNames) fs.copyFileSync(path.join(controller, name), path.join(output, name));
 write(path.join(output, 'CONTROLLER.sha256'), controlNames.map(name => checksum(fs.readFileSync(path.join(output, name))) + '  ' + name + '\n').join(''));
 const metadata = fs.readdirSync(output).sort();
 write(path.join(output, 'PACKET.sha256'), metadata.map(name => checksum(fs.readFileSync(path.join(output, name))) + '  ' + name + '\n').join(''));
 console.log('SOURCE_FREEZE_PREPARED head=' + expected + ' entries=' + entries.length);
}
function verify(root, packet, receipt, workspace = false) {
 const expected = JSON.parse(fs.readFileSync(path.join(packet, 'SOURCE_FILES.json'), 'utf8'));
 const names = workspace ? selected(root) : walk(root);
 const actual = names.map(name => entry(root, name));
 const observed = workspace ? state(root) : null;
 write(receipt, JSON.stringify({ entries: actual, workspace: observed }, null, 2) + '\n');
 need(JSON.stringify(actual) === JSON.stringify(expected), 'source catalog names/content/modes/symlinks changed');
 if (workspace) {
  need(observed.head === fs.readFileSync(path.join(packet, 'SOURCE_HEAD'), 'utf8').trim(), 'terminal workspace HEAD changed');
  need(observed.porcelain === '', 'workspace became dirty after freeze');
 }
 console.log('SOURCE_CATALOG_MATCH entries=' + actual.length + (workspace ? ' workspace_HEAD=' + observed.head : ''));
}
try {
 const [mode, root, first, second] = process.argv.slice(2);
 if (mode === 'prepare') prepare(root, first, second);
 else if (mode === 'verify-source') verify(root, first, second);
 else if (mode === 'verify-workspace') verify(root, first, second, true);
 else throw new Error('usage: prepare ROOT EXPECTED_HEAD OUT | verify-source|verify-workspace ROOT PACKET RECEIPT');
} catch (error) { console.error('JOINT_CUSTODY_REFUSE: ' + error.message); process.exitCode = 1; }
