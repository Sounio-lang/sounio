#!/usr/bin/env bash
# Verify every retained private-gate ELF, including A64 compile-only artifacts.
set -euo pipefail
[[ $# == 2 ]] || exit 64
out=$1;index=$2
[[ -d $out && -f $out/RESULTS.tsv ]]
: > "$index"
count=0
while IFS= read -r -d '' manifest;do
 sha256sum -c "$manifest"
 sha256sum "$manifest" >> "$index"
 count=$((count+1))
done < <(find "$out" -type f -name '*.ELF.sha256' -print0 | LC_ALL=C sort -z)
[[ $count -ge 7 ]]
# No emitted ELF may lack its own original pre-execution manifest.
while IFS= read -r -d '' elf;do
 [[ -s ${elf%.elf}.ELF.sha256 ]]
done < <(find "$out" -type f -name '*.elf' -size +0c -print0)
for target in x86_64-linux aarch64-linux;do
 for name in multimodule_public main_public legacy_nested_public;do [[ -s $out/$target.$name.ELF.sha256 ]];done
done
[[ -s $out/x86_64-linux.global_public.ELF.sha256 ]]
echo "PRIVATE_ELF_MANIFESTS_VERIFIED count=$count"
