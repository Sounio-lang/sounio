#!/usr/bin/env bash
# Actual lightweight metadata-only controls; run exclusively inside joint Slurm.
set -euo pipefail
[[ $# == 2 ]] || exit 64
packet=$1;out=$2
mkdir "$out" "$out/empty" "$out/existing"
trap 'rc=$?;printf "%s\n" "$rc" > "$out/STATUS"' EXIT
g++ -std=c++23 -O2 -Wall -Wextra -Werror "$packet/trace_missing_input.cpp" -o "$out/witness.elf" > "$out/build.stdout" 2> "$out/build.stderr"
sha256sum "$out/witness.elf" > "$out/ELF.before.sha256"
printf 'fixture\texpected\tactual\n' > "$out/RESULTS.tsv"
for item in open:0 openat:0 noopen:2 other:2 wrong-exit:2;do
 fixture=${item%:*};expected=${item#*:};actual=0
 (cd "$out/empty";timeout --kill-after=2 5 "$out/witness.elf" "$out/$fixture.receipt.txt" "$out/witness.elf" "--fixture-$fixture") \
  > "$out/$fixture.stdout" 2> "$out/$fixture.stderr" || actual=$?
 printf '%s\t%s\t%s\n' "$fixture" "$expected" "$actual" >> "$out/RESULTS.tsv"
 [[ "$actual" == "$expected" ]]
done
printf '0' > "$out/existing/shard_start.txt"
actual=0
(cd "$out/existing";timeout --kill-after=2 5 "$out/witness.elf" "$out/existing.receipt.txt" "$out/witness.elf" --fixture-openat) \
 > "$out/existing.stdout" 2> "$out/existing.stderr" || actual=$?
printf 'existing\t2\t%s\n' "$actual" >> "$out/RESULTS.tsv"
[[ "$actual" == 2 ]]
sha256sum -c "$out/ELF.before.sha256" > "$out/ELF.verify.txt"
echo JOINT_SYSCALL_WITNESS_SIX_ACTUAL_CONTROLS_PASS
