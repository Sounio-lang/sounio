#!/usr/bin/env bash
# Exact root CXX tool/ldd catalogue function, invoked before tracer compilation.
set -euo pipefail
[[ $# == 1 ]] || exit 64
out=$(dirname "$1")
cxx_manifest() {
    local tool resolved
    for tool in "$(command -v g++)" "$(g++ -print-prog-name=cc1plus)" \
      "$(g++ -print-prog-name=collect2)" "$(g++ -print-prog-name=as)" \
      "$(g++ -print-prog-name=ld)" "$(g++ -print-file-name=libstdc++.so)" \
      "$(g++ -print-file-name=libgcc_s.so.1)" "$(g++ -print-file-name=libquadmath.so.0)"; do
        if [[ "$tool" != */* ]]; then tool=$(command -v "$tool") || return 1; fi
        resolved=$(readlink -f "$tool") || return 1
        [[ -f "$resolved" ]] || return 1
        printf '%s\n' "$resolved"
        ldd "$resolved" > "$out/.cxx-ldd" 2>&1 || return 1
        if grep -q 'not found' "$out/.cxx-ldd"; then return 1; fi
        awk '/=> \// {print $3} /^[[:space:]]*\// {print $1}' "$out/.cxx-ldd"
    done | LC_ALL=C sort -u | xargs -r sha256sum
}
cxx_manifest > "$1"
[[ -s $1 ]]
sha256sum -c "$1"
