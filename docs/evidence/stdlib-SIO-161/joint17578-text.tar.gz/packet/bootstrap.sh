#!/usr/bin/env bash
# Fresh retained source builds; standard gates also run without being modified.
set -euo pipefail
[[ $# == 4 ]] || exit 64
root=$1;out=$2;g0=$3;seed=$4
mkdir "$out"
trap 'bootstrap_rc=$?;printf "%s\n" "$bootstrap_rc" > "$out/STATUS"' EXIT
cd "$root"
src=self-hosted/compiler/lean_single.sio
sha256sum "$src" "$g0" "$seed" > "$out/INPUTS.sha256"
"$g0" "$src" "$out/M1.elf" > "$out/M1.stdout" 2> "$out/M1.stderr"
chmod +x "$out/M1.elf";sha256sum "$out/M1.elf" > "$out/STAGES.sha256"
"$out/M1.elf" "$src" "$out/M2.elf" > "$out/M2.stdout" 2> "$out/M2.stderr"
chmod +x "$out/M2.elf";sha256sum "$out/M2.elf" >> "$out/STAGES.sha256"
"$out/M2.elf" "$src" "$out/M3.elf" > "$out/M3.stdout" 2> "$out/M3.stderr"
chmod +x "$out/M3.elf";sha256sum "$out/M3.elf" >> "$out/STAGES.sha256"
cmp "$out/M2.elf" "$out/M3.elf"
cmp "$out/M2.elf" "$seed"
SOUNIO_CANONICAL_SOUC="$seed" SOUNIO_SEED_ELF="$seed" SOUNIO_SEED_RECEIPT_REQUIRED=1 \
 bash scripts/ci/canonical_compiler_gate.sh > "$out/canonical.stdout" 2> "$out/canonical.stderr"
SOUNIO_SEED_BOOTSTRAP="$g0" SOUNIO_SEED_DDC=1 SOUNIO_SEED_DDC_FROM="$g0" \
 bash scripts/ci/verify_lean_seed.sh > "$out/verify.stdout" 2> "$out/verify.stderr"
sha256sum -c "$out/INPUTS.sha256" > "$out/INPUTS.verify.txt"
sha256sum -c "$out/STAGES.sha256" > "$out/STAGES.verify.txt"
echo JOINT_FRESH_BOOTSTRAP_M2_M3_AND_CANONICAL_PASS
