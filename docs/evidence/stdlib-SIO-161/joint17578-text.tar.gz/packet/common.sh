#!/usr/bin/env bash
# Run host scripts on t560-proxmox; its kubectl already accesses both pods.
set -euo pipefail
CONTROL=/workspace/.tmp/SIO161-joint01
ROOT=/workspace/sounio-stdlib-consolidation-20261025
BASE=/scratch/sounio-stdlib-inference-scale-20261024/SIO161-joint01
HOST=/tmp/SIO161-joint01
WS_NODE=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node
NODE=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node
workspace_exec() { timeout 180 kubectl --request-timeout=180s -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server -- "$@"; }
workspace_input() { timeout 600 kubectl --request-timeout=180s -n beagle exec -i sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server -- "$@"; }
worker_exec() { timeout 180 kubectl --request-timeout=180s -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- "$@"; }
worker_input() { timeout 600 kubectl --request-timeout=180s -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- "$@"; }
need_head() { [[ "$1" =~ ^[0-9a-f]{40}$ ]] || { echo 'Explicit root-final40hexHEAD required' >&2;exit 64; }; }
