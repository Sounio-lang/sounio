# SIO161-joint01 — PREPARED ONLY

No source freeze, scientific workload, E2E suite, or Slurm submission has been
performed by this preparation. Root must first finish/review/commit its source
and provide the final 40-character HEAD.

Controller source: /workspace/.tmp/SIO161-joint01.
Durable host mirror: /tmp/SIO161-joint01 on t560-proxmox.
Worker: /scratch/sounio-stdlib-inference-scale-20261024/SIO161-joint01.

Host scripts run on t560, whose existing kubectl reaches both pods. They use
the existing workspace user openvscode-server and worker user sounio. There is
no credential copying, cluster configuration change, or Node installation.

## Root-reviewed execution sequence

First inspect the controller files and CONTROLLER_PREPARED.sha256. Then, only
after the final source HEAD is ready, invoke these on t560:

~~~bash
bash /tmp/SIO161-joint01/host_freeze.sh FINAL_ROOT_HEAD
bash /tmp/SIO161-joint01/host_submit.sh FINAL_ROOT_HEAD
~~~

Freeze and submit are separate steps. Freeze refuses a dirty source worktree,
a different branch/HEAD, an old seed, a different historical JSON fixture, or an
existing worker source/packet directory. It records the branch, HEAD, dirty
receipt, tracked file list and contents/modes/symlinks before streaming.
Worker and workspace catalogs must match. A partial transfer is preserved and
never silently overwritten.

Submission records an exclusive attempt before sbatch; an uncertain reply must
be reconciled, not retried. The exact source HEAD and packet-manifest SHA are
arguments to the Slurm script. The monitor runs in t560 tmux session
SIO161-joint01-controller and survives a Mac/SSH disconnect. It waits up to6000
seconds, records terminal state and compares the terminal workspace catalog to
the frozen source. No automatic cancellation or resubmission occurs.

## Frozen inputs and tools

The selection includes every tracked stdlib/tests/examples file; every tracked
scripts/stdlib and scripts/lib file; scripts/ci/souc-native-wrapper.sh; only
bin/souc, bin/madaros, bin/souc-lean-single-x86_64 and its SeedReceipt; and ONE
historical JSON artifacts/stdlib/stdlib_e2e_result.v1.json.

Two tracked tests/frontend symlinks require exactly two additional target files:
self-hosted/compiler/lexer.sio and parser.sio. They are included as explicit
symlink closure, preserving link targets. The monolithic compiler source lean_single.sio (SHA702b4bf38036b11d61929a6135af5432de75859ff656361aa95c0dd2bd80b9a5) is also included, along with exactly the canonical/provenance/seed/private CI helpers, the Node SeedReceipt checker and three archived SIO172 witnesses. No whole compiler or bin tree is copied.

The historical JSON SHA is
c02d2ac60c5d2a6ec8b8161e7f1d244ccf47412db3e9943c283493cdac551fe2.
It is a metadata selftest fixture only, never the E2E measurement.

External Madaros .ready is pinned to a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3.
The fresh tracked seed must be13003a8b9b1bf4bfc64ad8d13eb0795d722888fabef5bbb2913b4f7b83bb454b.
Existing SIO226 Node is reused in place, SHA
81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90;
its original Node/runtime receipts are retained and checked. The job creates
only an isolated PATH symlink. CXX/ld/ldd/library records are captured; compiler,
Node and runtime contents are checked again at completion.

## Job and acceptance

Slurm UID1000, cpu-ops/cpuops-t560-proxmox,1 CPU,4 GiB,75 minutes, exportNIL,
stack524288 KiB. Metadata selftest runs first. Fresh retained G0-to-M1-to-M2-to-M3 builds plus the unchanged canonical/seed gates run under a180-second bound. Full Stage2 private-field qualification with EXTRA172_ROOT follows under120 seconds. A C++23 x86_64 Linux ptrace observer is compiled only inside Slurm and first exercises six real operational controls: missing open/openat accepted; unrelated exit1, other missing path, wrong exit and successful open refused. The old scale caller is positively checked/compiled, then run only in an EMPTYcwd under15 seconds: the observer must record an open/openat of literal shard_start.txt returning -ENOENT and child exit1, without numerical campaign progress. Generic assertions and bare nonzero exits cannot satisfy this witness. The observer has its own20-second alarm, PTRACE_O_EXITKILL and child PDEATHSIG; timeout also bounds execution. The new caller must pass check-only. Original scale source and header-identity JSON are sealed packet auxiliaries, outside the tracked source catalog.

Both complete selections are attempted independently even after these phases fail. The science runner gets at most2600 seconds and unfiltered E2E at most1600; remaining wall time is computed against a4440-second deadline, with180 seconds reserved for integrity checks and time reserved for E2E before science starts. Real timeout/failure statuses remain explicit.

A failing first phase never suppresses the E2E attempt. Each phase's real exit
status is retained. E2E writes a fresh absolute output JSON; its receipt checks
schema, frozen-source context, empty filter, nonempty results, exact totals,
status counts, projections, exact unique frozen tests/stdlib/**/*.sio path census and timestamp bounded by the actual run. The scale caller's actual E2E row must be pass/check-only; contradictory success status with failed results is rejected. A real
suite failure with valid JSON is a valid measurement AND a failing overall job.

The frozen source, retained deep-gate child executables/figures, bootstrap stages and syscall-observer executable remain on the worker. The unchanged bin/madaros universal-E2E run mode may remove its own temporary executables; this protocol does not claim those temporary E2E ELFs are retained.
Only selected terminal text receipts return to the workspace. No quotas or
historical artifacts are changed or removed. No Python is used.

Root-owned Notion EPIC161 remains the workflow authority for this joint
qualification; the controller's state/receipts must be linked there by root.

Transport functions have explicit operating-system bounds (180 seconds for metadata exec,600 seconds for streams), because API request-timeout does not bound an established exec stream. A timeout preserves partial receipts and is never an automatic retry. There is no strace or generic assertion fallback: the source-sealed C++ syscall observer is mandatory. Its source is part of the packet catalogue; the built observer and original scale ELF are hashed before and after execution and at the final footer. Compiler tool custody includes g++, cc1plus, collect2, assembler, linker, three direct runtime libraries and complete ldd closure, matching the root runner function. Every private-gate ELF manifest is verified immediately after that phase and again at completion; missing expected positive manifests fail qualification.

REVIEW03 supersedes preparation protocols REVIEW01/REVIEW02 while preserving their immutable directories. The observer uses PTRACE_GET_SYSCALL_INFO explicit entry/exit classification, rejects a non-x86_64 tracee ABI, and fails closed if the kernel lacks that API; it does not infer syscall parity from the initial signal stop. Metadata-only selftests now include refusal of a self-consistent scale-only partial suite, duplicate paths and unlisted paths. The six real observer controls remain unrun until the joint Slurm allocation. No successful full-run claim is made by preparation.
