// Operational provenance only: original frozen catalogue is an exact subset.
import fs from 'node:fs';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const p=process.argv[2];
const originalBytes=fs.readFileSync(p+'/ORIGINAL_SOURCE_FILES.json');
assert.equal(createHash('sha256').update(originalBytes).digest('hex'),'e664d8a090730069a777835482e4f13b7fee1f014ddb948ce8e6b7aa28c74b3b');
const original=JSON.parse(originalBytes),extended=JSON.parse(fs.readFileSync(p+'/SOURCE_FILES.json'));
const added='docs/evidence/stdlib-SIO-174/before/callback_time.sio';
assert.equal(original.length,10159);assert.equal(extended.length,10160);
assert.equal(JSON.stringify(extended.filter(e=>e.path!==added)),JSON.stringify(original));
assert.equal(extended.filter(e=>e.path===added).length,1);
assert.equal(extended.find(e=>e.path===added).sha256,'5fe3bf9700c51ecbaabbcbc38cba7141153198fd0de7502c37417297b538d8e8');
console.log('ORIGINAL_10159_ENTRIES_BYTE_IDENTICAL_PLUS_ONE_TRACKED_174_INPUT');
