#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
[[ $# == 1 && "$1" =~ ^[1-9][0-9]*$ ]] || exit 64
job=$1
exec 9>"$HOST/monitor.lock";flock -n 9 || exit 75
deadline=$(( $(date +%s)+3600 ));read_failures=0
while :;do
 rc=0
 worker_run sacct -j "$job" -X -n -P --format=JobID,State,Elapsed,ExitCode > "$HOST/sacct.current.txt" 2> "$HOST/sacct.current.stderr" || rc=$?
 if [[ $rc == 0 ]];then
  row=$(awk -F'|' -v j="$job" '$1==j{print;exit}' "$HOST/sacct.current.txt")
  state=$(printf '%s\n' "$row" | cut -d'|' -f2)
  case "$state" in ""|PENDING|RUNNING|CONFIGURING|COMPLETING|SUSPENDED|REQUEUED) ;; *) break;;esac
 else
  read_failures=$((read_failures+1))
  cp "$HOST/sacct.current.stderr" "$HOST/transport-read-$read_failures.stderr"
  printf '%s\n' "$rc" > "$HOST/transport-read-$read_failures.status"
 fi
 if (( $(date +%s)>deadline ));then printf '75\n' > "$HOST/MONITOR_STATUS";exit 75;fi
 sleep 20
done
cp "$HOST/sacct.current.txt" "$HOST/JOB_TERMINAL.txt"
cat "$HOST/JOB_TERMINAL.txt" | worker_in tee "$BASE/JOB_TERMINAL.txt"
cat "$HOST/JOB_TERMINAL.txt" | workspace_in tee "$CONTROL/JOB_TERMINAL.txt"
worker_status=$(worker_run cat "$BASE/artifacts/ALL_STATUS" 2>/dev/null || printf 'missing')
overall=1
if [[ "$state" == COMPLETED && "$worker_status" == 0 ]];then overall=0;fi
printf 'job=%s\nstate=%s\nworker_status=%s\ncontroller_status=%s\nread_transport_failures=%s\n' "$job" "$state" "$worker_status" "$overall" "$read_failures" > "$HOST/CONTROLLER_STATUS.txt"
cat "$HOST/CONTROLLER_STATUS.txt" | workspace_in tee "$CONTROL/CONTROLLER_STATUS.txt"
printf '%s\n' "$overall" > "$HOST/MONITOR_STATUS"
printf '%s\n' "$overall" | workspace_in tee "$CONTROL/MONITOR_STATUS"
echo "FULLGIT_TERMINAL job=$job state=$state worker=$worker_status overall=$overall"
exit "$overall"
