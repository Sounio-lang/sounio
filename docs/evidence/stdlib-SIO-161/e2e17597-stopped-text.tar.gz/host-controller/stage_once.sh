#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
exec 9>"$HOST/stage.lock";flock -n 9 || exit 75
set -o noclobber
date -u > "$HOST/STAGE_ATTEMPT"
worker_run bash -c 'set -e;id;date -u;free -b;df -B1 /scratch;available=$(df -B1 --output=avail /scratch | tail -1);[[ "$available" -ge 21474836480 ]];[[ ! -e "$1" ]];mkdir "$1" "$1/source" "$1/packet" "$1/logs"' _ "$BASE" > "$HOST/RESOURCE_PREFLIGHT.txt"
workspace_run git -C "$ROOT" rev-parse "$HEAD^{commit}" > "$HOST/SOURCE_COMMIT.txt"
[[ "$(cat "$HOST/SOURCE_COMMIT.txt")" == "$HEAD" ]]
workspace_run bash -c 'set -e;cd "$1";{ awk "{print \$2}" INPUTS.sha256;printf "INPUTS.sha256\n"; } | tar -T - -cf -' _ "$CONTROL" | worker_in tar -xf - -C "$BASE/packet"
worker_run bash -c 'set -e;cd "$1";printf "%s  %s\n" "$2" INPUTS.sha256 | sha256sum -c -;sha256sum -c INPUTS.sha256' _ "$BASE/packet" "$INPUT_SHA" > "$HOST/PACKET.staged.verify"
# Fixed commit export only. No worktree overlay, .git history or source filtering.
workspace_run git -C "$ROOT" archive --format=tar "$HEAD" | worker_in tar -xpf - --no-same-owner -C "$BASE/source"
worker_run "$NODE" "$BASE/packet/fullgit_custody.mjs" verify "$BASE/source" "$BASE/packet" "$BASE/STAGED_SOURCE.json" > "$HOST/SOURCE.staged.verify"
worker_run bash -c 'cd "$1" && sha256sum -c "$2/STAGED_SOURCE.json.REGULAR.sha256"' _ "$BASE/source" "$BASE" > "$HOST/REGULAR.staged.verify"
worker_run sha256sum "$BASE/STAGED_SOURCE.json" > "$HOST/STAGED_SOURCE.seal.sha256"
printf '%s\n' "$HEAD" | worker_in tee "$BASE/STAGED_OK"
cat "$HOST/SOURCE.staged.verify"
cat "$HOST/STAGED_SOURCE.seal.sha256"
echo FULL24468_GIT_STAGE_VERIFIED_NO_JOB_SUBMITTED
