#!/usr/bin/env bash
set -euo pipefail
cd /tmp/SIO161-E2E-fullgit01
set +e
bash restage_modes02.sh > stage02.stdout 2> stage02.stderr
rc=$?
set -e
printf '%s\n' "$rc" > STAGE02_STATUS
exit "$rc"
