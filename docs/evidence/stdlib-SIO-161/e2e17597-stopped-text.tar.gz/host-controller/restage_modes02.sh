#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
exec 9>"$HOST/stage.lock";flock -n 9 || exit 75
set -o noclobber
date -u > "$HOST/STAGE02_ATTEMPT"
[[ "$(cat "$HOST/STAGE_STATUS")" == 1 ]]
worker_run bash -c 'set -e;b=$1;[[ ! -e "$b/JOB_ID" && ! -e "$b/SUBMISSION_ATTEMPT" && ! -e "$b/source.attempt01.git-default-modes" ]];stat -c "%a %n" "$b/source/.claudeignore" "$b/source/bin/souc";mv "$b/source" "$b/source.attempt01.git-default-modes";mkdir "$b/source";available=$(df -B1 --output=avail /scratch | tail -1);[[ "$available" -ge 21474836480 ]];df -B1 /scratch' _ "$BASE" > "$HOST/STAGE01_MODE_FAILURE.txt"
workspace_run git -C "$ROOT" -c tar.umask=0022 archive --format=tar "$HEAD" | worker_in tar -xpf - --no-same-owner -C "$BASE/source"
worker_run "$NODE" "$BASE/packet/fullgit_custody.mjs" verify "$BASE/source" "$BASE/packet" "$BASE/STAGED_SOURCE.json" > "$HOST/SOURCE02.staged.verify"
worker_run bash -c 'cd "$1" && sha256sum -c "$2/STAGED_SOURCE.json.REGULAR.sha256"' _ "$BASE/source" "$BASE" > "$HOST/REGULAR02.staged.verify"
worker_run sha256sum "$BASE/STAGED_SOURCE.json" > "$HOST/STAGED_SOURCE.seal.sha256"
printf '%s\n' "$HEAD" | worker_in tee "$BASE/STAGED_OK"
cat "$HOST/SOURCE02.staged.verify";cat "$HOST/STAGED_SOURCE.seal.sha256"
echo FULL24468_GIT_STAGE02_VERIFIED_NO_JOB_SUBMITTED
