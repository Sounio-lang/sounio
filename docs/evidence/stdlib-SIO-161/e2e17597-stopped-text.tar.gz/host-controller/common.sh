#!/usr/bin/env bash
set -euo pipefail
HOST=/tmp/SIO161-E2E-fullgit01
CONTROL=/workspace/.tmp/SIO161-E2E-fullgit01
ROOT=/workspace/sounio-stdlib-consolidation-20261025
BASE=/scratch/sounio-stdlib-inference-scale-20261024/SIO161-E2E-fullgit01
HEAD=3c7c8073411a7e7254d0d9424f59f8e49eb49180
NODE=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node
WSNODE=/workspace/.home/openvscode-server/.config/nvm/versions/node/v22.22.2/bin/node
INPUT_SHA=93af62ab70b83f43f20cfb0a3e3c74b2ff87565620661e30f2cd3cc4e52d9fc6
workspace_run(){ timeout 600 kubectl --request-timeout=180s -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server -- "$@"; }
workspace_in(){ timeout 600 kubectl --request-timeout=180s -n beagle exec -i sounio-workspace-control-0 -c workspace-ssh -- runuser -u openvscode-server -- "$@"; }
worker_run(){ timeout 180 kubectl --request-timeout=120s -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- "$@"; }
worker_in(){ timeout 600 kubectl --request-timeout=180s -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- "$@"; }
