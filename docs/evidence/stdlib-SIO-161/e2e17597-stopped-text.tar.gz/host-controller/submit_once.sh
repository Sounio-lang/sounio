#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
[[ "$(cat "$HOST/STAGE02_STATUS")" == 0 ]]
[[ "$(worker_run cat "$BASE/STAGED_OK")" == "$HEAD" ]]
staged_sha=$(cut -d' ' -f1 "$HOST/STAGED_SOURCE.seal.sha256")
[[ "$staged_sha" == e419369a6f6860253fc57015d2706688d159b2c3a3d8a065491b60a19f0b2ffb ]]
worker_run "$NODE" "$BASE/packet/fullgit_custody.mjs" verify "$BASE/source" "$BASE/packet" "$BASE/SOURCE.before-submit.json" > "$HOST/SOURCE.before-submit.verify"
worker_run cmp "$BASE/SOURCE.before-submit.json" "$BASE/STAGED_SOURCE.json"
worker_run bash -c 'cd "$1" && sha256sum -c INPUTS.sha256' _ "$BASE/packet" > "$HOST/PACKET.before-submit.verify"
# Persist every attempt before sbatch; never retry an uncertain submit reply.
workspace_run bash -c 'set -o noclobber;date -u > "$1/SUBMISSION_ATTEMPT"' _ "$CONTROL"
set +e
worker_run bash -c 'set -euo pipefail;cd "$1";set -o noclobber;date -u > SUBMISSION_ATTEMPT;set +e;sbatch --parsable packet/worker.sbatch "$2" "$3" > SUBMISSION.reply 2> SUBMISSION.stderr;rc=$?;set -e;printf "%s\n" "$rc" > SUBMISSION.status;cat SUBMISSION.reply;cat SUBMISSION.stderr >&2;[[ $rc == 0 ]];job=$(sed "s/;.*//" SUBMISSION.reply);[[ "$job" =~ ^[1-9][0-9]*$ ]];printf "%s\n" "$job" > JOB_ID' _ "$BASE" "$INPUT_SHA" "$staged_sha" > "$HOST/SUBMISSION.reply" 2> "$HOST/SUBMISSION.stderr"
rc=$?
set -e
printf '%s\n' "$rc" > "$HOST/SUBMISSION.status"
cat "$HOST/SUBMISSION.reply" | workspace_in tee "$CONTROL/SUBMISSION.reply"
cat "$HOST/SUBMISSION.stderr" | workspace_in tee "$CONTROL/SUBMISSION.stderr"
printf '%s\n' "$rc" | workspace_in tee "$CONTROL/SUBMISSION.status"
[[ $rc == 0 ]] || exit "$rc"
job=$(sed 's/;.*//' "$HOST/SUBMISSION.reply")
[[ "$job" =~ ^[1-9][0-9]*$ ]] || exit 75
printf '%s\n' "$job" > "$HOST/JOB_ID"
printf '%s\n' "$job" | workspace_in tee "$CONTROL/JOB_ID"
tmux new-session -d -s SIO161-E2E-fullgit01-monitor "bash $HOST/monitor.sh $job > $HOST/monitor.stdout 2> $HOST/monitor.stderr"
echo "FULLGIT_E2E_SUBMITTED_ONCE job=$job source=$HEAD monitor=t560:SIO161-E2E-fullgit01-monitor"
