#!/usr/bin/env bash
set -euo pipefail
cd /tmp/SIO161-E2E-fullgit01
exec 8>submit.lock;flock -n 8 || exit 75
set -o noclobber
date -u > SUBMIT_CONTROLLER_ATTEMPT
set +e
bash submit_once.sh > submit.stdout 2> submit.stderr
rc=$?
set -e
printf '%s\n' "$rc" > SUBMIT_CONTROLLER_STATUS
exit "$rc"
