#!/usr/bin/env bash
set -euo pipefail
cd /tmp/SIO161-E2E-fullgit01
set +e
bash stage_once.sh > stage.stdout 2> stage.stderr
rc=$?
set -e
printf '%s\n' "$rc" > STAGE_STATUS
exit "$rc"
