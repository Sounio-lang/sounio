// Operational Git materialization custody only. No scientific calculation.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const head='3c7c8073411a7e7254d0d9424f59f8e49eb49180';
const hash=(data,kind='sha256')=>createHash(kind).update(data).digest('hex');
function need(x,msg){if(!x)throw Error(msg);}
function tree(packet){
 const rawBytes=fs.readFileSync(path.join(packet,'GIT_TREE.raw.nul'));
 need(hash(rawBytes)==='5a5a03e7226491a6f0d92ef0236ff6371ed119d0909812eb01c128e055a5f2fa','exact3c7 Git-tree manifest identity');
 const raw=rawBytes.toString('utf8');
 const entries=raw.split('\0').filter(Boolean).map(row=>{
  const m=row.match(/^(\d{6}) (\w+) ([0-9a-f]{40}) +([0-9]+)\t([\s\S]+)$/);
  need(m,'unrecognized git ls-tree row');
  const [,mode,type,blob,size,name]=m;
  need(type==='blob'&&['100644','100755','120000'].includes(mode),'gitlink/unexpected mode '+name);
  need(!path.isAbsolute(name)&&!name.split('/').includes('..')&&!/[\r\n\\]/.test(name),'unsafe source name');
  return{path:name,git_mode:mode,git_blob:blob,blob_bytes:Number(size)};
 }).sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 need(entries.length===24468,'expected24468tracked entries');need(new Set(entries.map(e=>e.path)).size===24468,'duplicate source path');
 need(entries.filter(e=>e.git_mode==='120000').length===15,'expected15symlinks');
 need(entries.reduce((n,e)=>n+e.blob_bytes,0)===922928729,'tracked blob byte total differs');
 return entries;
}
function names(root,prefix=''){
 const out=[];
 for(const d of fs.readdirSync(path.join(root,prefix),{withFileTypes:true})){
  const rel=prefix?prefix+'/'+d.name:d.name;
  if(d.isDirectory())out.push(...names(root,rel));else out.push(rel);
 }return out.sort();
}
function verify(root,packet,receipt){
 need(!fs.existsSync(path.join(root,'.git')),'Git history must not be materialized');
 const expected=tree(packet),actualNames=names(root);
 need(JSON.stringify(actualNames)===JSON.stringify(expected.map(e=>e.path)),'full tracked path census differs (missing/extra/export-filtered entries)');
 const observed=expected.map(e=>{
  const absolute=path.join(root,e.path),stat=fs.lstatSync(absolute);
  const symlink=e.git_mode==='120000';
  need(symlink?stat.isSymbolicLink():stat.isFile(),'entry kind differs '+e.path);
  need((stat.mode&0o777)===(symlink?0o777:e.git_mode==='100755'?0o755:0o644),'mode differs '+e.path);
  const link=symlink?fs.readlinkSync(absolute):null;
  const bytes=symlink?Buffer.from(link):fs.readFileSync(absolute);
  need(bytes.length===e.blob_bytes,'blob length differs '+e.path);
  need(hash(Buffer.concat([Buffer.from('blob '+bytes.length+'\0'),bytes]),'sha1')===e.git_blob,'Git blob identity differs '+e.path);
  return{...e,mode:stat.mode&0o777,link,sha256:hash(bytes)};
 });
 const originalBytes=fs.readFileSync(path.join(packet,'ORIGINAL_SOURCE_FILES.json'));
 need(hash(originalBytes)==='e664d8a090730069a777835482e4f13b7fee1f014ddb948ce8e6b7aa28c74b3b','original selected catalogue identity');
 const original=JSON.parse(originalBytes);
 need(original.length===10159,'original selected catalogue count');
 for(const e of original){
  const absolute=path.join(root,e.path),stat=fs.lstatSync(absolute);
  need((stat.mode&0o777)===e.mode,'original entry mode changed '+e.path);
  need((stat.isSymbolicLink()?fs.readlinkSync(absolute):null)===e.link,'original entry link changed '+e.path);
  need(hash(fs.readFileSync(absolute))===e.sha256,'original10159 source bytes changed '+e.path);
 }
 const missingList=fs.readFileSync(path.join(packet,'MISSING_TRACKED_INPUTS.txt'),'utf8').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 need(missingList.length===17&&new Set(missingList).size===17,'expected exact17 formerly missing inputs');
 for(const item of missingList)need(observed.some(e=>e.path===item),'formerly missing tracked input absent '+item);
 const out={kind:'full_git_tree_materialization',source_head:head,entries:observed,tracked_entries:24468,symlinks:15,gitlinks:0,total_blob_bytes:922928729,all_git_blobs_modes_links_match:true,original10159_entries_identical:true,formerly_missing17_present:true};
 fs.writeFileSync(receipt,JSON.stringify(out,null,2)+'\n');
 fs.writeFileSync(receipt+'.REGULAR.sha256',observed.filter(e=>e.git_mode!=='120000').map(e=>e.sha256+'  '+e.path+'\n').join(''));
 fs.writeFileSync(receipt+'.SYMLINKS.json',JSON.stringify(observed.filter(e=>e.git_mode==='120000'),null,2)+'\n');
 console.log('FULL_GIT_TREE_MATCH head='+head+' entries=24468 symlinks=15 gitlinks=0 bytes=922928729 original10159_identical=true missing17_present=true');
}
try{
 const [mode,root,packet,receipt]=process.argv.slice(2);
 if(mode==='verify')verify(root,packet,receipt);
 else if(mode==='inspect')console.log(JSON.stringify({head,entries:tree(packet).length,symlinks:15,gitlinks:0,total_blob_bytes:922928729}));
 else throw Error('usage: inspect unused PACKET | verify ROOT PACKET RECEIPT');
}catch(error){console.error('FULL_GIT_CUSTODY_REFUSE: '+error.message);process.exitCode=1;}
