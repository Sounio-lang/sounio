# Read-only audit of fresh SIO161 E2E failures

Input: Slurm17578 source3c7c8073411a7e7254d0d9424f59f8e49eb49180;
JSON SHA2561d75374a4dac5b9cfcbd0d5013dfdeffdfd8265ff472adf3cd8e33ca276b33fe.
Comparison: remote-main commit26c2a7a7e23c957acadb311d373d7d7f1d07e9b6.
315 pass /99 fail /213 skip =627 measured. Pass modes:272 run-pass and43 check-only.
No code, annotation, timeout, selection, compiler or root-worktree changes. No new jobs.

## First observable failure classification

| Class | Cases |
|---|---:|
| Unresolved import closure refusal |9|
| Parse refusal |7|
| Type refusal |9|
| Missing/unsupported method |7|
| E259 private field |13|
| E175 private function |2|
| Undeclared name |1|
| Unsupported extern |2|
| Format literal refusal |1|
| Check refused but first diagnostic lost from six-line excerpt |5|
| Whole-wrapper30s timeout, phase unresolved |17|
| Other nonzero run-wrapper exits, phase unresolved |22|
| Exit132, SIGILL-compatible but actual phase/signal not proven |3|
| Exit181, high nonzero wrapper status without signal proof |1|

The first ten rows are the56 check refusals; remaining43 are run-wrapper failures.
Only the recorded first visible diagnostic is classified. In particular, the5
truncated checks are epistemic/test_walley_frechet_compose, pbpk/test_rapamycin_units_bridge,
stats/test_logistic_e2e, stats/test_ols_diag_e2e and stats/test_ols_madaros_e2e.

run_stdlib_e2e.sh lines184 and221 retain head -6 of output, often just the compiler
banner. Line215 wraps bin/souc run in30s. bin/madaros lines814-831 build before
executing the temporary ELF. Thus neither run-timeout nor run-failed is sufficient
evidence of native runtime/algorithm cost, native crash or missing runtime input.
Full first-error streams are not in the supplied JSON. No recorded ENOENT or
staging-missing-input diagnosis was found. This is not proof that none exists.

## Source and data comparison

REPORT.json contains all99 rows, resolved static import edges and object IDs in
both commits. Resolution follows the actual module_frontend.sio search precedence:
local, up to8 ancestors, repo root, configured stdlib/repo stdlib, self-hosted,
package/lib or package/mod, then named-item fallback. super paths are handled;
comment/string contents are excluded. This is a conservative lexical source-graph
reconstruction, not a new compiler invocation or proof of reachability. The61
visible compiler module counts all agree with the reconstructed closure counts.

90 failures have complete reconstructed closures with identical source blobs and
identified literal-resource blobs in both heads. This is source parity, not an
executed main26c pass/fail baseline. All99 fixtures themselves are identical.
9 have unresolved imports in both heads; an unchanged fixture cannot establish
a complete baseline for them. Eight also have identical resolved subsets. The
remaining physics/test_pbpk_phonon_q has a changed resolved subset: phonon and
pbpk_phonon changed, phonon_factor newly imported, numeric_buffer and math/pure
newly consumed by that graph. Its SAME phonon_quantity and pbpk_phonon_q imports
are absent in BOTH trees. Therefore no integration-introduced failure is proven.
Those new resolved nodes are not claimed to have changed their own source blobs.

The9 unresolved fixtures/paths:
- analysis/test_analysis: analysis
- ffi/test_slice: ffi
- http/test_http_e2e: http
- infra/test_infra_core: infra
- json/test_json_e2e: json
- physics/test_mechanics: physics::mechanics
- physics/test_pbpk_phonon_q: physics::phonon_quantity and physics::pbpk_phonon_q
- physics/test_phonon_quantity: physics::phonon_quantity
- systems/test_systems: systems

The explicit fMRI NIfTI1/NIfTI2/motion inputs have equal Git blob IDs in both
heads and their SHA256 values match the frozen SOURCE catalog. No fMRI staging
gap is supported; its observed first error is E011 in nifti_read_file_buffer_into.
Dynamic IO calls are separately listed in REPORT.json; literal-path scanning is
not a general dataflow proof. Large resource payloads are compared by Git identity
without copying them into this audit. No compiler/runtime-baseline job was run.

## Proven stage omissions, separate from first-failure attribution

A read-only UID1000 existence probe at2026-10-25T23:51:33Z confirms all17 paths
in MISSING_TRACKED_INPUTS.txt are ABSENT from the actual source root. They are
tracked files referenced as literal inputs by five failed Pireus test closures,
with equal Git blobs in source3c7 and main26c, but absent from the frozen catalog.
The five fixtures are multiprobe_block_certification, operator_autogenesis,
operator_discovery_engine, operator_novelty_frontier and operator_seed_kernel.
The omitted inputs include six garden/contract Markdown files, eight versioned
freeze/parity/material/orbit receipts and three evidence text files. See the full
path list and source identities in MISSING_TRACKED_INPUTS.json.

The consuming functions explicitly check/read these resources: operator_autogenesis
path constructors:621-624 and oag_build_admission:704-714; operator_seed_kernel
path constructors:428-431 and osk_build_seed_admission:783-793;
operator_novelty_frontier constructors:534-537 and onf_build_lineage:585-605.
Those guards return invalid/incomplete admission or lineage on missing inputs.
This establishes a real execution-environment gap. Truncated run-wrapper output
still does not establish which missing input, compiler phase or native assertion
caused the recorded nonzero result. No status is relabeled as fixed or baseline.

A future bounded staging repair can include only the exact consumed tracked
receipts and hashes, then capture full first diagnostics on the approved replay.
Do not copy the entire tools tree or increase timeouts. No staging repair or replay
was performed in this audit. Literal scanning remains a conservative static
inventory, not proof that every possible dynamically constructed input is covered.

## Highest priority bounded repair candidates (unimplemented)

1. **Statistics shape compatibility — existing SIO183.**
   tests/stdlib/stats/test_shapiro_e2e.sio:31 declares a256-element array;
   line33 passes it to stats/shapiro_wilk.sio:34, whose canonical signature is
   &[f64;100]. The recorded E009 span921..947 identifies that call. Both source
   closures have6 identical nodes. Two related8-node OLS fixtures declare a
   256-element residual array and pass it to the same100-element API at
   test_ols_diag_e2e.sio:85 / test_ols_madaros_e2e.sio:72. Their first current
   diagnostic is truncated, so this is an additional static mismatch candidate,
   not a claim about their first error. A bounded fix can retain the active data
   and oracle/tolerance while adapting only the Shapiro input/residual buffers;
   keep Cook/OLS256 buffers unchanged. Do not widen or duplicate the estimator.

2. **Particle physics array arity — existing SIO183.**
   particle_physics/systematics.sio:49-52 declares Measurement.syst_errs:[f64;4],
   but measurement_new:184-188 initializes eight elements. The exact first E016
   span6023..6060 names that initializer. The ten-node closure is byte-identical
   to main26c. Repair the constructor to its declared four-systematic contract,
   preserving all four active contributions and the existing numerical checks;
   do not change uncertainty formulas merely to pass compilation.

3. **Analysis facade import — existing SIO184.**
   analysis/test_analysis.sio:11 imports analysis, while its own header names
   stdlib/analysis/lib.sio. analysis.sio is absent in both trees; analysis/lib.sio
   exists and exports the exact numerical_derivative/integral/ConvergenceResult
   surface. Consumer import analysis::lib is a concrete candidate, preserving
   all numerical assertions. No compiler resolver fallback or test skip is needed.

4. **Public result/read-only metadata surfaces — existing SIO181.**
   plot/test_canvas_e2e.sio:7 reads c.width; Canvas.width is private at
   plot/canvas.sio:73-77 and only canvas_new is exported. Stats ARIMA test:71
   reads result.ar_coeffs; ARIMAResult fields at arima.sio:65-77 are private.
   Recorded E259 spans identify those exact accesses. Both two-node closures
   are unchanged. Prefer a reviewed read-only public accessor contract rather
   than weakening privacy, changing the compiler or silently dropping assertions.
   The wider13 visible E259 cases need individual intended-API review; the
   legacy card's14 count is not a refreshed diagnosis of the truncated case.

5. **Math external API mismatch — owner/contract review needed.**
   math/test_core_e2e.sio:26 calls abs; math/pure.sio:46 declares it private.
   The exact E175 span886..901 names abs. max/min/pi/floor/ceil are also private
   despite the fixture's public-API comment. This is a concrete source contract
   mismatch in the unchanged two-node closure. Choose the intended public scalar
   surface before adapting the fixture; do not automatically publish all helpers
   or copy private numerical implementations into a test.

Physics quantity bridge imports above need real backed API/units work; their
absence in both trees is not fixed by staging copies or bigger timeouts. No
stub/alias that changes the dimensional or uncertainty contract is proposed.

## Existing backlog mapping and limits

- SIO181 E259 fields: https://app.notion.com/p/4043f37f9371810db8f2d480a54f027b
- SIO183 types14: https://app.notion.com/p/4043f37f937181c1a6a3c93fd707af58
- SIO184 parse/closure20: https://app.notion.com/p/4043f37f937181cfb4c0f22521e99644
- SIO264 operator test corpus: https://app.notion.com/p/4043f37f93718195b1deebf71418f407
- SIO263 evidence corpus: https://app.notion.com/p/4043f37f937181229090d2a354c72b50
  are existing related Pireus backlog; neither proves this staging catalog complete.
- SIO185 timeout work: https://app.notion.com/p/4043f37f937181bf9309ee06a61bd790
  is Claude's release/3.0 train and legacy22-task scope, NOT an executed source
  baseline for3c7. Related work only; no old outcome is imported into this audit.
- SIO278 separates ChangedTests compile/runtime envelopes; related observability
  work, not a fix already applied to this global E2E runner.
- SIO275 JSON emission preserved measured schema/status semantics. It does not
  explain or erase the99 failures and does not authorize changing their budgets.

No duplicate card was created. Root owns EPIC161 updates. Only directly related
171 was annotated: four genomic check-only passes and twelve no-annotation skips;
no genomic failure here, and none of those records replaces actual17535/17586
or establishes20k runtime/global-normalization qualification.
