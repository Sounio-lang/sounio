#define main pilot256_entry
#include "genomics_batch_scale_reference.cpp"
#undef main
int main(int argc,char**argv){try{
 if(argc!=3)return 64;
 auto baseline=read_metrics(argv[1]),candidate=read_metrics(argv[2]);
 emit("baseline_native_seconds",baseline.elapsed);
 emit("candidate_native_seconds",candidate.elapsed);
 emit("candidate_over_baseline_elapsed",candidate.elapsed/baseline.elapsed);
 emit("baseline_peak_KiB",baseline.rss);
 emit("candidate_peak_KiB",candidate.rss);
 emit("candidate_over_baseline_peak",candidate.rss/baseline.rss);
 std::cout<<"SCOPE actual1000_point_only_same_printed_outputs;two_observations;timing_calculation_separate_from_numerical_oracle\n";
 std::cout<<"SIO171_SHARD_METRICS_CPP_PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"SIO171_SHARD_METRICS_REJECT "<<e.what()<<'\n';return 2;}}
