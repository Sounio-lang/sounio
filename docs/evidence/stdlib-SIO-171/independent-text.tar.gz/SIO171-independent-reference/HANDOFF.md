# SIO-171 independent numerical oracle handoff
UTC: 2026-10-25
Owner: devpass / SIO-171-independent-reference
Worktree: /workspace/sounio-SIO-171-20261025
Base HEAD: 92a610c5bb522820047ff003a5a0e836b37af97d
Only owned repository path: tests/reference/genomics_batch_independent_reference.cpp
No production, fixture, gate, report or documentation files edited/staged.

Final source SHA256: 45545f1ad7310d37462d78d6d5a666a4b186ffbf22ee6fe4fc1c9b0f26617ce4
Reused independent Gaussian prior model:
tests/reference/deep_stats_dispersion_reference.cpp
SHA256 5976db0755ad0cd8c9cc3deaab356aa713cc0fd2c78acc8bd4245b1a550ce60b

Frozen final source packet: source04/
Build/native concordance: Slurm17416 run05/ STATUS0; -std=c++23 -O2 -Wall -Wextra -Werror -lquadmath
Oracle ELF SHA256: c59f94d1351eaef45eba647bc0e5c7d470f62cf77f03a641c390a09bbb3660ea
Environment: Slurm cpu-ops, UID1000, stack524288, cpus1, mem4096M, no quota changes.
Case0 native BOTH outputs (Slurm17403/source06) byte-identical hash:
cff219b9c3a287d8521ce02d6833fe4642d12d0d3de3b7726726f79a18bf3728
Positive prior original Mad native output (Slurm17406/prior02):
490fdcaf422c5ddc603a5b241ea0483e10f7ffec59af152c9e81d1e8ff1105f7

CLI:
reference [case0.native.stdout ...]
reference --prior [tracked-prior.native.stdout ...]
reference --prior-original-marker [original17406.native.stdout ...]
Last command uses exact original old marker explicitly. No old stdout was edited.
controls01/prior-current-marker.txt is a labeled parser-only copy positive control;
it does not prove native execution of the tracked fixture with its new marker.

Numerical method:
- Exact integer fixture counts, mathematical positive-count geometric anchors,
  per-sample median log ratios (including even median), centered factors/offsets.
- Group NB score solved by independent bounded bisection with heterogeneous
  offsets; no arithmetic group mean shortcut, native IRLS or native QR reused.
- Integer-count log1p finite product NB2 likelihood; independently bracketed
  profile-score roots over requested finite interval plus Poisson candidate.
- Profile finite-difference curvatures at two scales, restored n curvature factor.
- Existing independent binary128 direct 2x2 Gram model for canonical Gaussian
  working-prior trend/leverage sampling correction, no production pivoted QR.
- For tau>0, independent penalized profile stationary roots and objective/full
  likelihood; does not substitute Gaussian mapped log-alpha. Nine genes differ
  by more than .001 in log-alpha from that proxy in the frozen positive case.
- Conditional fixed-final-alpha Fisher contrast/SE using independent group info.
- Two-sided Normal tails via binary128 erfc, independent of production GammaQ.
- Full original-family BH/BY including effective p=1 unavailable rows.
- Closed ordered parser checks all 24 numeric/12 status fields per gene, all
  sample factors/offsets, actual per-row work sums and budgets, metadata,
  original gene IDs and all TSV availability/NA fields and duplicate/missing rows.
- Numerical tolerance: mean/factors/offsets 2e-12 (with explicit tiny floors),
  point likelihood 2e-10; other chained profile/prior/Fisher quantities 2e-4
  relative plus 2e-6 absolute. These reflect the 1e-5 native outer stop scale
  and downstream propagation. Structural zeros/classes/statuses exact.
- No claim of globally proven profile unimodality or calibrated finite-sample
  inference. CR, active high-outlier routes and additional production failure
  states are not yet qualified by these ML fixtures.
- Positive fixture native BOTH/current marker replay belongs to Stats final
  gate; current receipt claims original17406 Mad only, case0 BOTH.

Slurm17417 controls01/ STATUS0: all11 corruptions rejected with code2:
missing-marker, extra-row, nonfinite-factor, duplicate-sample, wrong-family-BH,
wrong-eligible, wrong-work, hidden-unavailable, wrong-gene-ID,
Gaussian-proxy-instead-of-real-refit, false-p-availability.

Preserved preparatory failures:
17408 run01: omitted explicit PATH under --export=NIL, g++ could not find cc1plus.
17415 run04: all numeric prior checks passed, then strict geneID checker expected
uppercase hexadecimal while real TSV emits lowercase for gene9+. Fixed oracle
format expectation only to %02x, no production data/expectations changed.
17410 run02 (initial case0 source01) BOTH pass; 17413 run03 extended canonical
positive model pass; final17416 source04 supersedes these for final claims.

