#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run06/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run06/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
cd /scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/source05
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run06
trap 's=$?; echo "$s" > "$out/STATUS"' EXIT
id > "$out/identity.txt"
g++ --version > "$out/gcc.txt"
sha256sum tests/reference/*.cpp tests/run-pass/*.sio > "$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/genomics_batch_independent_reference.cpp -lquadmath -o "$out/reference" >"$out/build.stdout" 2>"$out/build.stderr"
/usr/bin/time -v "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/lean_single.native.stdout >"$out/reference.stdout" 2>"$out/reference.stderr"
/usr/bin/time -v "$out/reference" --prior-original-marker /scratch/sounio-stdlib-inference-scale-20261024/SIO171/prior02/madaros.native.stdout >"$out/prior.reference.stdout" 2>"$out/prior.reference.stderr"

# Raw p=zero/negative and BH/BY zero must fail independently of TSV.
for kind in zero negative;do
 replacement=0
 if [[ $kind == negative ]];then replacement=-0.01;fi
 awk -v v="$replacement" '/^GENE 3$/{gene=1} /^GENE 4$/{gene=0} /^VALUE 16$/{column=1;print;next} /^VALUE /{column=0} gene&&column&&/^V /{print "V "v;next}{print}' /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout > "$out/p-$kind.txt"
 rc=0;"$out/reference" "$out/p-$kind.txt" >"$out/p-$kind.stdout" 2>"$out/p-$kind.stderr"||rc=$?
 echo "$kind $rc">>"$out/probability-controls.statuses";test "$rc" == 2
done
for field in BH BY;do
 sed "0,/^$field /s/^$field .*/$field 0/" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout > "$out/$field-zero.txt"
 rc=0;"$out/reference" "$out/$field-zero.txt">"$out/$field-zero.stdout" 2>"$out/$field-zero.stderr"||rc=$?
 echo "$field-zero $rc">>"$out/probability-controls.statuses";test "$rc" == 2
done

sha256sum "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/*.native.stdout > "$out/ARTIFACT.sha256"

