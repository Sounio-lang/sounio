#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run01/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run01/slurm.%j.stderr
set -euo pipefail
ulimit -s 524288
ulimit -c 0
cd /scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/source01
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run01
trap 's=$?; echo "$s" > "$out/STATUS"' EXIT
id > "$out/identity.txt"
g++ --version > "$out/gcc.txt"
sha256sum tests/reference/*.cpp tests/run-pass/*.sio > "$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra tests/reference/genomics_batch_independent_reference.cpp -lquadmath -o "$out/reference" >"$out/build.stdout" 2>"$out/build.stderr"
/usr/bin/time -v "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/lean_single.native.stdout >"$out/reference.stdout" 2>"$out/reference.stderr"
sha256sum "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/*.native.stdout > "$out/ARTIFACT.sha256"

