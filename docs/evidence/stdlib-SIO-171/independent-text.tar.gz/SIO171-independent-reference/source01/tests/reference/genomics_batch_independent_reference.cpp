// C++23 binary128 independent oracle: frozen SIO171 G8 N12 P2 ML case0.
// Compile on Slurm: g++ -std=c++23 -O2 this.cpp -lquadmath -o reference.
// Usage: reference [native.stdout ...]. Solves heterogeneous-offset group
// score equations and outer profile stationary points independently of IRLS/QR.
// The existing qualified C++ direct-Gram working-prior model is reused below.
// Scope: case0 zero prior variance; CR/positive prior require further fixtures.
#define main sio171_existing_prior_main
#include "deep_stats_dispersion_reference.cpp"
#undef main
#include <algorithm>
#include <sstream>
#include <iostream>
#include <numeric>
namespace batch {
constexpr int G=8,N=12;using Row=std::array<Q,N>;
Q q(const char*s){return strtoflt128(s,nullptr);}
struct Profile{Q t=0,alpha=0,ll=0,score=0;Row mu{};};
struct Gene{std::array<Q,24>v{};std::array<int,12>s{};Q bh=1,by=1;};
struct Model{std::array<Row,G>y{};Row factor{},offset{};std::array<Gene,G>gene{};Fit prior{};int eligible=0;};
Q pmf(int y,Q mu,Q a){if(a==0)return y*logq(mu)-mu-lgammaq(Q(y+1));Q sum=0;
 for(int k=0;k<y;++k)sum+=log1pq(a*k);
 return sum-lgammaq(Q(y+1))+y*logq(mu)-(y+1/a)*log1pq(a*mu);}
Q scale(const Row&y,const Row&s,int group,Q a){Q lo=q("1e100"),hi=0,sy=0,ss=0;
 for(int j=group*6;j<(group+1)*6;++j){lo=fminq(lo,y[j]/s[j]);hi=fmaxq(hi,y[j]/s[j]);sy+=y[j];ss+=s[j];}
 if(a==0)return sy/ss;
 // Strictly decreasing score; normalized count extrema enclose unique root.
 for(int k=0;k<120;++k){Q mid=(lo+hi)/2;if(mid==lo||mid==hi)break;Q z=0;
  for(int j=group*6;j<(group+1)*6;++j){Q mu=s[j]*mid;z+=(y[j]-mu)/(1+a*mu);}if(z>0)lo=mid;else hi=mid;}
 return(lo+hi)/2;}
Profile eval(const Row&y,const Row&s,Q t,bool poisson=false){Profile p;p.t=poisson?Q(0):t;p.alpha=poisson?Q(0):expq(t);
 for(int g=0;g<2;++g){Q m=scale(y,s,g,p.alpha);require(m>0,"finite group MLE");
  for(int j=g*6;j<(g+1)*6;++j){Q mu=s[j]*m;p.mu[j]=mu;int count=int(y[j]);p.ll+=pmf(count,mu,p.alpha);
   if(!poisson){Q r=1/p.alpha,h=0;for(int k=0;k<count;++k)h+=1/(r+k);
    p.score+=-r*(h-log1pq(mu/r)+(mu-y[j])/(r+mu));}}}return p;}
Profile maximize(const Row&y,const Row&s){Profile best=eval(y,s,0,true),left=eval(y,s,-10);if(left.ll>best.ll)best=left;
 // Scan all fixture-scale score brackets; no global-unimodality theorem claimed.
 for(int k=1;k<=96;++k){auto right=eval(y,s,Q(-10)+Q(12)*k/96);if(right.ll>best.ll)best=right;
  if(left.score>0&&right.score<0){Q lo=left.t,hi=right.t;for(int j=0;j<112;++j){Q mid=(lo+hi)/2;if(mid==lo||mid==hi)break;
    if(eval(y,s,mid).score>0)lo=mid;else hi=mid;}auto p=eval(y,s,(lo+hi)/2);if(p.ll>best.ll)best=p;}left=right;}return best;}
Q curvature(const Row&y,const Row&s,const Profile&p,Q h){return(2*p.ll-eval(y,s,p.t+h).ll-eval(y,s,p.t-h).ll)/(N*h*h);}
Model expected(){Model m;std::vector<Row>logs;
 for(int i=0;i<G;++i){Row v{};Q center=0;for(int j=0;j<N;++j){int noise=i==0?0:((j*7+i*3)%11)-5;
   int count=(i+1)*20+noise*(i+1)+(j>=6?(i+1)*10:0);if(i==7)count=0;m.y[i][j]=count;
   if(i<7){v[j]=logq(Q(count));center+=v[j]/N;}}
  if(i<7){for(auto&x:v)x-=center;logs.push_back(v);}}
 Q center=0;for(int j=0;j<N;++j){std::vector<Q>col;for(auto&v:logs)col.push_back(v[j]);std::sort(col.begin(),col.end());
  m.offset[j]=col[col.size()/2];center+=m.offset[j]/N;}
 for(int j=0;j<N;++j){m.offset[j]-=center;m.factor[j]=expq(m.offset[j]);}
 std::vector<Q>means,alpha,variance;std::vector<int>ids;
 for(int i=0;i<G;++i){auto&g=m.gene[i];g.s.fill(-1);g.s[5]=300;for(int j=0;j<N;++j)g.v[0]+=m.y[i][j]/m.factor[j]/N;
  if(i==7){g.s[0]=3;g.s[1]=-1;g.s[3]=1;continue;}auto p=maximize(m.y[i],m.factor);
  g.s[0]=0;g.v[1]=p.alpha;g.v[2]=p.t;g.v[3]=g.v[4]=p.ll/N;
  g.s[1]=p.alpha==0?1:0;g.s[3]=p.alpha==0?2:0;g.s[4]=p.alpha==0?0:1;
  if(p.alpha==0){g.v[20]=1;continue;}require(p.t>-10&&p.t<2,"fixture interior");
  Q h=Q(1)/256;g.v[22]=curvature(m.y[i],m.factor,p,h);g.v[23]=curvature(m.y[i],m.factor,p,h/2);
  require(g.v[22]>0&&g.v[23]>0,"positive curvature");g.v[5]=1/(N*g.v[23]);
  means.push_back(g.v[0]);alpha.push_back(p.alpha);variance.push_back(g.v[5]);ids.push_back(i);}
 m.eligible=int(ids.size());require(m.eligible==4,"frozen eligible set");m.prior=fit(means,alpha,variance,q(".05"),1,2);
 require(m.prior.prior==0,"case0 zero prior variance");
 for(size_t k=0;k<ids.size();++k){int i=ids[k];auto&g=m.gene[i];Q trend=logq(m.prior.a0+m.prior.a1/g.v[0]);
  g.s[5]=g.s[7]=g.s[8]=g.s[9]=g.s[10]=0;g.s[11]=2;require(m.prior.flags[k]==0,"case0 no outliers");
  g.v[6]=m.prior.mapped[k];g.v[7]=m.prior.variance[k];g.v[8]=trend;g.v[9]=expq(trend);g.v[10]=trend;
  auto p=eval(m.y[i],m.factor,trend);Q info[2]{};for(int j=0;j<N;++j)info[j/6]+=p.mu[j]/(1+g.v[9]*p.mu[j]);
  g.v[13]=logq(scale(m.y[i],m.factor,1,g.v[9]))-logq(scale(m.y[i],m.factor,0,g.v[9]));
  g.v[14]=sqrtq(1/info[0]+1/info[1]);g.v[15]=g.v[13]/g.v[14];
  // erfc is independent of production GammaQ(1/2,z^2/2).
  g.v[16]=erfcq(fabsq(g.v[15])/sqrtq(Q(2)));g.v[17]=logq(g.v[16]);g.v[18]=g.v[19]=1;}
 std::array<int,G>order{};std::iota(order.begin(),order.end(),0);auto pv=[&](int i){return m.gene[i].v[18]==1?m.gene[i].v[16]:Q(1);};
 std::stable_sort(order.begin(),order.end(),[&](int a,int b){return pv(a)<pv(b);});Q harmonic=0;for(int i=1;i<=G;++i)harmonic+=Q(1)/i;
 Q bh=1,by=1;for(int rank=G;rank>0;--rank){int i=order[rank-1];bh=fminq(bh,pv(i)*G/rank);by=fminq(by,pv(i)*G*harmonic/rank);m.gene[i].bh=bh;m.gene[i].by=by;}return m;}
struct Reader{std::ifstream in;std::string path;size_t line=0;Reader(std::string p):in(p),path(p){require(bool(in),"native open");}
 std::string get(){std::string s;require(bool(std::getline(in,s)),"native EOF");++line;if(!s.empty()&&s.back()=='\r')s.pop_back();return s;}
 void literal(std::string e){auto a=get();if(a!=e)throw std::runtime_error(path+":"+std::to_string(line)+": expected "+e+" got "+a);}
 Q number(std::string prefix){auto s=get();require(s.starts_with(prefix),"native prefix");auto n=s.substr(prefix.size());char*end=nullptr;Q x=strtoflt128(n.c_str(),&end);
  require(end!=n.c_str()&&*end=='\0'&&!isnanq(x)&&!isinfq(x),"finite native number");return x;}};
void close(Q a,Q e,std::string field,Q rel,Q abs){if(fabsq(a-e)>rel*fabsq(e)+abs){char av[100],ev[100];quadmath_snprintf(av,sizeof(av),"%.24Qg",a);quadmath_snprintf(ev,sizeof(ev),"%.24Qg",e);throw std::runtime_error(field+": actual="+av+" independent="+ev);}}
std::vector<std::string>split(std::string s){std::vector<std::string>v;std::istringstream in(s);std::string x;while(std::getline(in,x,'\t'))v.push_back(x);return v;}
int integer(Q x){require(floorq(x)==x&&x>=-1&&x<=10000000,"integer status");return int(x);}
void validate(const Model&m,std::string path){Reader r(path);r.literal("PREP 0");r.literal("ELIGIBLE "+std::to_string(m.eligible));r.literal("SHRINK 0");
 std::istringstream work(r.get());std::string key,extra;int wp=-1,wr=-1;require(bool(work>>key>>wp>>wr)&&key=="WORK"&&!(work>>extra),"WORK schema");
 close(r.number("PRIOR_A0 "),m.prior.a0,"prior a0",q(".0002"),q("1e-10"));close(r.number("PRIOR_A1 "),m.prior.a1,"prior a1",q(".0002"),q("1e-10"));close(r.number("PRIOR_VAR "),m.prior.prior,"prior variance",0,0);
 for(int j=0;j<N;++j){r.literal("SAMPLE "+std::to_string(j));close(r.number("FACTOR "),m.factor[j],"factor",q("2e-12"),q("2e-14"));close(r.number("OFFSET "),m.offset[j],"offset",q("2e-12"),q("2e-14"));}
 int evals=0;std::array<Gene,G>actual{};
 for(int i=0;i<G;++i){r.literal("GENE "+std::to_string(i));auto&a=actual[i];auto&e=m.gene[i];
  for(int j=0;j<12;++j){a.s[j]=integer(r.number("STATUS "+std::to_string(j)+" "));if(j==2){require(a.s[j]>=1&&a.s[j]<=128,"point budget");evals+=a.s[j];}
   else if(j==6)require(a.s[j]==-1,"case0 no profile refit evaluations");else require(a.s[j]==e.s[j],"gene status/availability");}
  for(int j=0;j<24;++j){r.literal("VALUE "+std::to_string(j));a.v[j]=r.number("V ");Q rel=q(".0002"),abs=q("2e-6");
   if(j==0){rel=q("2e-12");abs=q("2e-12");}if(e.v[j]==0||j==18||j==19||j==20||j==21)rel=abs=0;
   if(j==3||j==4){rel=q("2e-10");abs=q("2e-10");}close(a.v[j],e.v[j],"gene "+std::to_string(i)+" value "+std::to_string(j),rel,abs);}
  a.bh=r.number("BH ");a.by=r.number("BY ");close(a.bh,e.bh,"full family BH",q(".0002"),q("2e-6"));close(a.by,e.by,"full family BY",q(".0002"),q("2e-6"));}
 require(evals==wp&&wr==0,"actual work sums");
 r.literal("#model=NB2_log_link;dispersion_prior=Gaussian_working;alpha=plug_in;assumptions_assessed=false;finite_sample_calibrated=false;global_optimality_assessed=false");
 r.literal("#BH_requirement=valid_p_values_and_independence_or_PRDS;BY_requirement=valid_p_values;family=all_original_gene_rows;unavailable_effective_p=1;display_significant_digits=15");
 r.literal("gene_row\tgene_id_hex\tpoint_status\tcurvature_status\tprior_eligible\trefit_status\trefit_route\tcovariance_status\tcontrast_status\ttail_status\toutlier\tpoint_available\trefit_available\tp_available\tlog_p_available\tbase_mean\tpoint_alpha\tgaussian_mapped_log_alpha\tfinal_alpha\tcontrast\tstandard_error\tz\tp\tlog_p\tBH\tBY");
 for(int i=0;i<G;++i){auto f=split(r.get());require(f.size()==26,"TSV width");auto&a=actual[i];require(f[0]==std::to_string(i),"TSV row order");require(f[1]=="474141414"+std::to_string(i+1),"gene ID");
  const int sc[8]{0,3,4,5,11,7,8,9};for(int k=0;k<8;++k)require(f[k+2]==std::to_string(k==2?(a.s[4]==1?1:0):a.s[sc[k]]),"TSV statuses");
  bool po=i!=7,fi=i>=3&&i<=6;require(f[10]=="0","TSV outlier");require(f[11]==(po?"1":"0"),"TSV point availability");for(int k=12;k<=14;++k)require(f[k]==(fi?"1":"0"),"TSV final availability");
  const int vc[9]{0,1,6,9,13,14,15,16,17};for(int k=0;k<9;++k){bool available=k==0||(k==1?po:fi);if(!available){require(f[15+k]=="NA","TSV unavailable must be NA");continue;}
   char*end=nullptr;Q x=strtoflt128(f[15+k].c_str(),&end);require(end!=f[15+k].c_str()&&*end=='\0'&&!isnanq(x)&&!isinfq(x),"TSV finite");close(x,a.v[vc[k]],"TSV scientific consistency",0,0);}
  for(int k=0;k<2;++k){char*end=nullptr;Q x=strtoflt128(f[24+k].c_str(),&end);require(end!=f[24+k].c_str()&&*end=='\0'&&!isnanq(x)&&!isinfq(x),"TSV adjustment");close(x,k==0?a.bh:a.by,"TSV adjustment consistency",0,0);}}
 r.literal("GENOMICS_BATCH_PASS");std::string tail;require(!std::getline(r.in,tail),"trailing native rows");std::printf("GENOMICS_BATCH_INDEPENDENT_CONCORDANCE_PASS %s\n",path.c_str());}
}
int main(int argc,char**argv){try{auto m=batch::expected();std::printf("CASE0 G8 N12 P2 ML eligible=%d\n",m.eligible);row("independent_prior_a0",m.prior.a0);row("independent_prior_a1",m.prior.a1);row("independent_prior_variance",m.prior.prior);
 for(int i=0;i<batch::G;++i){std::printf("INDEPENDENT_GENE %d\n",i);for(int j:{0,1,2,3,5,9,13,14,15,16,17,22,23}){auto label="v"+std::to_string(j);row(label.c_str(),m.gene[i].v[j]);}row("BH",m.gene[i].bh);row("BY",m.gene[i].by);}
 for(int i=1;i<argc;++i)batch::validate(m,argv[i]);std::puts("GENOMICS_BATCH_INDEPENDENT_CPP_PASS");return 0;}catch(const std::exception&e){std::fprintf(stderr,"GENOMICS_BATCH_ORACLE_REJECT %s\n",e.what());return 2;}}
