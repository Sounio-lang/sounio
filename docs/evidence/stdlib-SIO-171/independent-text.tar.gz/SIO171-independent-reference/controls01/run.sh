#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/controls01/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/controls01/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/controls01
ref=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run05/reference
small=/scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout
prior=/scratch/sounio-stdlib-inference-scale-20261024/SIO171/prior02/madaros.native.stdout
trap 's=$?; echo "$s" > "$out/STATUS"' EXIT
sha256sum "$ref" "$small" "$prior" > "$out/INPUTS.sha256"
head -n -1 "$small" > "$out/missing-marker.txt"
{ cat "$small";echo EXTRA; } > "$out/extra-row.txt"
sed '0,/FACTOR /s/FACTOR .*/FACTOR nan/' "$small" > "$out/nonfinite-factor.txt"
sed '0,/SAMPLE 0/s/SAMPLE 0/SAMPLE 0\nSAMPLE 0/' "$small" > "$out/duplicate-sample.txt"
sed '0,/BH /s/BH .*/BH 0.01/' "$small" > "$out/wrong-family-BH.txt"
sed '0,/STATUS 4 0/s/STATUS 4 0/STATUS 4 1/' "$small" > "$out/wrong-eligible.txt"
sed '0,/WORK /s/WORK .*/WORK 0 0/' "$small" > "$out/wrong-work.txt"
awk 'BEGIN{FS=OFS="\t"} $1=="0"&&NF==26{$18="0"}{print}' "$small" > "$out/hidden-unavailable.txt"
awk 'BEGIN{FS=OFS="\t"} $1=="0"&&NF==26{$2="4741414142"}{print}' "$small" > "$out/wrong-gene-ID.txt"
awk '/^VALUE 6$/{c=6;print;next}/^VALUE 10$/{c=10;print;next}/^VALUE /{c=-1}/^V /&&c==6{mapped=$2} /^V /&&c==10{print "V "mapped;next}{print}' "$prior" > "$out/Gaussian-proxy-instead-of-real-refit.txt"
awk 'BEGIN{FS=OFS="\t"} $1=="11"&&NF==26{$14="1"}{print}' "$prior" > "$out/false-p-availability.txt"
sed 's/GENOMICS_BATCH_PASS/GENOMICS_BATCH_PRIOR_PASS/' "$prior" > "$out/prior-current-marker.txt"
"$ref" --prior "$out/prior-current-marker.txt" > "$out/prior-marker-positive.stdout" 2> "$out/prior-marker-positive.stderr"
for name in missing-marker extra-row nonfinite-factor duplicate-sample wrong-family-BH wrong-eligible wrong-work hidden-unavailable wrong-gene-ID;do
 rc=0;"$ref" "$out/$name.txt" > "$out/$name.stdout" 2> "$out/$name.stderr"||rc=$?
 echo "$name $rc" >> "$out/negative.statuses";test "$rc" == 2
 grep -q GENOMICS_BATCH_ORACLE_REJECT "$out/$name.stderr"
done
for name in Gaussian-proxy-instead-of-real-refit false-p-availability;do
 rc=0;"$ref" --prior-original-marker "$out/$name.txt" > "$out/$name.stdout" 2> "$out/$name.stderr"||rc=$?
 echo "$name $rc" >> "$out/negative.statuses";test "$rc" == 2
 grep -q GENOMICS_BATCH_ORACLE_REJECT "$out/$name.stderr"
done
sha256sum "$out"/*.txt > "$out/CONTROL_FILES.sha256"
echo GENOMICS_BATCH_11_NEGATIVE_CONTROLS_PASS

