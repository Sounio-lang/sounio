#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run04/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run04/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
cd /scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/source03
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/run04
trap 's=$?; echo "$s" > "$out/STATUS"' EXIT
id > "$out/identity.txt"
g++ --version > "$out/gcc.txt"
sha256sum tests/reference/*.cpp tests/run-pass/*.sio > "$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/genomics_batch_independent_reference.cpp -lquadmath -o "$out/reference" >"$out/build.stdout" 2>"$out/build.stderr"
/usr/bin/time -v "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/madaros.native.stdout /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/lean_single.native.stdout >"$out/reference.stdout" 2>"$out/reference.stderr"
/usr/bin/time -v "$out/reference" --prior-original-marker /scratch/sounio-stdlib-inference-scale-20261024/SIO171/prior02/madaros.native.stdout >"$out/prior.reference.stdout" 2>"$out/prior.reference.stderr"
sha256sum "$out/reference" /scratch/sounio-stdlib-inference-scale-20261024/SIO171/probe06/*.native.stdout > "$out/ARTIFACT.sha256"

