#include <quadmath.h>
#include <cstdio>
#include <string>
#include <stdexcept>
#include <algorithm>
int main(int argc,char**argv){
 if(argc!=2)return 1;
 for(int shard=0;shard<20;++shard){int start=1000*shard;
  std::string path=std::string(argv[1])+"/"+std::to_string(start)+".txt";
  auto f=std::fopen(path.c_str(),"w");if(!f)throw std::runtime_error("model output");
  std::fprintf(f,"SCALE_LAYOUT 20000 1000 512 2 1000000\nSCALE_RANGE %d %d\n",start,start+1000);
  for(int done=0;done<1000;){done=std::min(done+16,1000);std::fprintf(f,"SCALE_PROGRESS %d\n",done);}
  for(int local=0;local<1000;++local){int row=start+local,base=row%7+1;
   char b[120];quadmath_snprintf(b,sizeof(b),"%.35Qg",logq(__float128(base))+logq(__float128(2))/2);
   std::fprintf(f,"SCALE_POINT %d 0 64\nSCALE_ID %d 71 %d %d %d %d\n0\n%s\n0\n",row,row,65+row/17576,65+(row/676)%26,65+(row/26)%26,65+row%26,b);
  }
  std::fputs("SCALE_EVALUATIONS 64000\nSCALE_STATE 1000 2 0\nGENOMICS_BATCH_SCALE_PASS\n",f);std::fclose(f);
 }
}
