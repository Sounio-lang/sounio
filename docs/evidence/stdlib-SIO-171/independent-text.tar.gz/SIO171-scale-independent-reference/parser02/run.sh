#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:05:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/parser02/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/parser02/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/parser02
source=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/source01
trap 's=$?;echo "$s">"$out/STATUS"' EXIT
echo SYNTHETIC_PARSER_CONTROLS_ONLY_NO_NATIVE_FITS > "$out/SCOPE.txt"
id>"$out/identity.txt";g++ --version>"$out/compiler.txt"
cd "$source"
sha256sum tests/reference/*.cpp tests/stdlib/genomics_batch/scale_main.sio>"$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/genomics_batch_scale_independent_reference.cpp -lquadmath -o "$out/reference">"$out/build.stdout" 2>"$out/build.stderr"
cat >"$out/model_reports.cpp" <<'CPP'
#include <quadmath.h>
#include <cstdio>
#include <string>
#include <stdexcept>
#include <algorithm>
int main(int argc,char**argv){
 if(argc!=2)return 1;
 for(int shard=0;shard<20;++shard){int start=1000*shard;
  std::string path=std::string(argv[1])+"/"+std::to_string(start)+".txt";
  auto f=std::fopen(path.c_str(),"w");if(!f)throw std::runtime_error("model output");
  std::fprintf(f,"SCALE_LAYOUT 20000 1000 512 2 1000000\nSCALE_RANGE %d %d\n",start,start+1000);
  for(int done=0;done<1000;){done=std::min(done+16,1000);std::fprintf(f,"SCALE_PROGRESS %d\n",done);}
  for(int local=0;local<1000;++local){int row=start+local,base=row%7+1;
   char b[120];quadmath_snprintf(b,sizeof(b),"%.35Qg",logq(__float128(base))+logq(__float128(2))/2);
   std::fprintf(f,"SCALE_POINT %d 0 64\nSCALE_ID %d 71 %d %d %d %d\n0\n%s\n0\n",row,row,65+row/17576,65+(row/676)%26,65+(row/26)%26,65+row%26,b);
  }
  std::fputs("SCALE_EVALUATIONS 64000\nSCALE_STATE 1000 2 0\nGENOMICS_BATCH_SCALE_PASS\n",f);std::fclose(f);
 }
}
CPP
g++ -std=c++23 -O2 -Wall -Wextra -Werror "$out/model_reports.cpp" -lquadmath -o "$out/model_reports">"$out/model.build.stdout" 2>"$out/model.build.stderr"
mkdir "$out/model";"$out/model_reports" "$out/model"
set --
for start in $(seq 0 1000 19000);do set -- "$@" "$out/model/$start.txt";done
"$out/reference" "$@" >"$out/model.full.stdout" 2>"$out/model.full.stderr"
"$out/reference" --partial "$out/model/0.txt" >"$out/model.partial.stdout" 2>"$out/model.partial.stderr"
reject(){ name="$1";shift;rc=0;"$out/reference" "$@" >"$out/$name.stdout" 2>"$out/$name.stderr"||rc=$?;echo "$name $rc">>"$out/negative.statuses";test "$rc" == 2;grep -q GENOMICS_BATCH_SCALE_ORACLE_REJECT "$out/$name.stderr";}
reject missing19shards "$out/model/0.txt"
reject duplicate-shard --partial "$out/model/0.txt" "$out/model/0.txt"
sed '0,/SCALE_ID 0 71/s/SCALE_ID 0 71/SCALE_ID 0 70/' "$out/model/0.txt">"$out/ID.txt"
reject wrong-ID --partial "$out/ID.txt"
sed '0,/SCALE_POINT 0 0/s/SCALE_POINT 0 0/SCALE_POINT 0 3/' "$out/model/0.txt">"$out/status.txt"
reject failed-point --partial "$out/status.txt"
sed '0,/SCALE_PROGRESS 16/s/SCALE_PROGRESS 16/SCALE_PROGRESS 32/' "$out/model/0.txt">"$out/progress.txt"
reject wrong-progress --partial "$out/progress.txt"
sed 's/SCALE_EVALUATIONS 64000/SCALE_EVALUATIONS 0/' "$out/model/0.txt">"$out/work.txt"
reject wrong-work --partial "$out/work.txt"
sed 's/SCALE_STATE 1000 2 0/SCALE_STATE 999 2 0/' "$out/model/0.txt">"$out/state.txt"
reject incomplete-state --partial "$out/state.txt"
awk '/^SCALE_ID /{k=1;print;next} k==1{k=2;print;next} k==2{k=0;print "nan";next}{print}' "$out/model/0.txt">"$out/nonfinite.txt"
reject nonfinite-fit --partial "$out/nonfinite.txt"
head -n -1 "$out/model/0.txt">"$out/truncated.txt"
reject truncation --partial "$out/truncated.txt"
sha256sum "$out/reference" "$out/model_reports.cpp" "$out/model_reports" "$out/model"/*.txt>"$out/ARTIFACTS.sha256"
echo SYNTHETIC_SCALE_PARSER_9_CONTROLS_PASS

