#include <quadmath.h>
#include <string>
#include <stdexcept>
#include <cstdio>
namespace batch {
void close(__float128,__float128,std::string,__float128,__float128);
void probability_close(__float128,__float128,const std::string&);
}
int main(){
 using Q=__float128;
 Q tiny=strtoflt128("1e-100",nullptr);
 // Same old generic absolute allowance accepts zero for a representable tail.
 batch::close(0,tiny,"old generic allowance",strtoflt128(".0002",nullptr),strtoflt128("2e-6",nullptr));
 batch::probability_close(tiny,tiny,"representable small tail");
 Q bad[]{0,-tiny,2*tiny,-1,Q(1)+strtoflt128(".01",nullptr)};
 int rejected=0;
 for(Q x:bad){bool caught=false;try{batch::probability_close(x,tiny,"bad small tail");}catch(const std::runtime_error&){caught=true;}if(!caught)return 2;++rejected;}
 std::printf("GENOMICS_SMALL_POSITIVE_PROBABILITY_HARDENING_PASS rejected=%d expected=1e-100 old_generic_accepted_zero=true\n",rejected);
}
