#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:05:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/probability01/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/probability01/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-scale-independent-reference/probability01
source=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-independent-reference/source05/tests/reference/genomics_batch_independent_reference.cpp
trap 's=$?;echo "$s">"$out/STATUS"' EXIT
sha256sum "$source">"$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -Werror -c "$source" -o "$out/production-reference.o" >"$out/object.stdout" 2>"$out/object.stderr"
objcopy --redefine-sym main=sio171_reference_original_main "$out/production-reference.o" "$out/testable-reference.o"
cat >"$out/control.cpp" <<'CPP'
#include <quadmath.h>
#include <string>
#include <stdexcept>
#include <cstdio>
namespace batch {
void close(__float128,__float128,std::string,__float128,__float128);
void probability_close(__float128,__float128,const std::string&);
}
int main(){
 using Q=__float128;
 Q tiny=strtoflt128("1e-100",nullptr);
 // Same old generic absolute allowance accepts zero for a representable tail.
 batch::close(0,tiny,"old generic allowance",strtoflt128(".0002",nullptr),strtoflt128("2e-6",nullptr));
 batch::probability_close(tiny,tiny,"representable small tail");
 Q bad[]{0,-tiny,2*tiny,-1,Q(1)+strtoflt128(".01",nullptr)};
 int rejected=0;
 for(Q x:bad){bool caught=false;try{batch::probability_close(x,tiny,"bad small tail");}catch(const std::runtime_error&){caught=true;}if(!caught)return 2;++rejected;}
 std::printf("GENOMICS_SMALL_POSITIVE_PROBABILITY_HARDENING_PASS rejected=%d expected=1e-100 old_generic_accepted_zero=true\n",rejected);
}
CPP
g++ -std=c++23 -O2 -Wall -Wextra -Werror "$out/control.cpp" "$out/testable-reference.o" -lquadmath -o "$out/control">"$out/build.stdout" 2>"$out/build.stderr"
"$out/control">"$out/control.stdout" 2>"$out/control.stderr"
sha256sum "$out/control.cpp" "$out/control" "$out"/*.o>"$out/ARTIFACTS.sha256"

