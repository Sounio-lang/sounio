import fs from 'node:fs';
import path from 'node:path';
const b='/scratch/sounio-stdlib-inference-scale-20261024/SIO171-global-normalization';
const out='/scratch/sounio-stdlib-inference-scale-20261024/SIO171-global-normalization-text07';
if(fs.readFileSync(path.join(b,'final07/STATUS'),'utf8').trim()!=='0')throw Error('gate not successful');
if(!fs.existsSync(path.join(b,'final07.source.final.verify')))throw Error('outer source closure absent');
if(fs.existsSync(out))throw Error('fresh custody root required');fs.mkdirSync(out);
function copy(src,rel){const data=fs.readFileSync(src);if(data.length>=4&&data[0]===127&&data[1]===69&&data[2]===76&&data[3]===70)return;const dst=path.join(out,rel);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,data);}
function walk(src,rel,filter=()=>true){for(const entry of fs.readdirSync(src,{withFileTypes:true})){const name=path.join(rel,entry.name),full=path.join(src,entry.name);if(!filter(name,entry))continue;if(entry.isDirectory())walk(full,name,filter);else if(entry.isFile())copy(full,name);}}
for(const entry of fs.readdirSync(b,{withFileTypes:true}))if(entry.isFile())copy(path.join(b,entry.name),entry.name);
for(const name of ['check01','probe02','probe03','probe04','private05'])walk(path.join(b,name),name);
for(const name of fs.readdirSync(b).filter(x=>/^source0[1-7]$/.test(x))){
 for(const file of ['stdlib/genomics/count_normalization.sio','stdlib/genomics/count_pipeline.sio','stdlib/genomics/count_pipeline_report.sio','tests/stdlib/genomics_batch/global_normalization.sio','tests/reference/genomics_global_normalization_reference.cpp','tests/compile-fail/genomics_normalization_private.sio','scripts/stdlib/genomics_global_normalization_gate.sh']){
  const src=path.join(b,name,file);if(fs.existsSync(src))copy(src,path.join(name,file));
 }
}
walk(path.join(b,'final07'),'final07',(name,entry)=>!name.startsWith('final07/mutation/stdlib'));
for(const file of ['count_normalization.sio','count_pipeline.sio','count_pipeline_report.sio'])copy(path.join(b,'final07/mutation/stdlib/genomics',file),path.join('final07/mutation/stdlib/genomics',file));
fs.writeFileSync(path.join(out,'SOURCE_PROVENANCE.txt'),'qualified_commit=ef4c670cf4e8f9f938c97040fa8503790b5c8df2\nbase_commit=3c7c8073411a7e7254d0d9424f59f8e49eb49180\nproduction_source_checkpoint=63c04df8981bd91b697064bca98ffd475443517c\nfull_source_catalog_entries=2117\nfull_sources_reconstructible_from_base_plus_feature_commits=true\nfull_unchanged_stdlib_snapshots_excluded_from_compact_packet=true\nELF_payloads_excluded_hash_receipts_retained_originals_on_worker=true\nprepared_final06_NOT_SUBMITTED=true\nnew_final_job=17586\noriginal_unused_helper_check_accepted_by_seed13003=true\nno_IEEE_compiler_universal_privacy_or_distributed20k_claim=true\n');
console.log(out);
