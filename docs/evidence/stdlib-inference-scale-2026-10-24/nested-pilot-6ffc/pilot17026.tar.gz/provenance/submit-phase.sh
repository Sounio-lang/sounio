#!/usr/bin/env bash
# Explicit root invocation only. No automatic pilot->round chaining.
set -euo pipefail
[[ $# == 3 ]] || { echo 'usage: pilot|round ROOT_GENUINE_RECEIPT ROOT_AUTHORIZED_REMAINING_SECONDS' >&2;exit 64; }
phase=$1;receipt=$(realpath "$2");budget=$3
[[ $(id -u) == 1000 && $budget =~ ^[1-9][0-9]{0,4}$ ]] || exit 65
base=/scratch/sounio-stdlib-inference-scale-20261024
packet=$base/nested_qualification_final03/packet
campaign=$base/nested_qualification_final03/campaign
case "$phase" in pilot) ((budget<=900)) || exit 64;template=count_profile_qualification_pilot.sbatch;namespace=pilot_nested_B31;; round) ((budget<=86400)) || exit 64;template=count_profile_qualification_round.sbatch;namespace=qualification_nested_B199;; *) exit 64;; esac
exec 8>"$packet/submission.lock"
flock -n 8 || exit 75
[[ -s "$packet/ROOT_AUTHORIZATION_LEDGER.tsv" ]] || { echo 'root allocation ledger required' >&2;exit 65; }
mapfile -t authorizations < <(awk -F '\t' -v p="$phase" 'NR>1&&$1==p {print}' "$packet/ROOT_AUTHORIZATION_LEDGER.tsv")
[[ ${#authorizations[@]} == 1 ]] || { echo 'one root authorization row for this phase required' >&2;exit 65; }
IFS=$'\t' read -r ledger_phase ledger_budget prior_charge authorization_reference extra <<< "${authorizations[0]}"
[[ $ledger_phase == "$phase" && $ledger_budget == "$budget" && $prior_charge =~ ^(0|[1-9][0-9]{0,4})$ && -n $authorization_reference && -z ${extra:-} ]] || exit 65
((prior_charge<=86400 && prior_charge+budget<=86400)) || { echo 'authorized cumulative24h would be exceeded' >&2;exit 65; }
[[ ! -e "$packet/$phase.SUBMISSION_ATTEMPT" && ! -e "$campaign/$namespace" ]] || { echo 'existing attempt/output requires explicit root review; no overwrite/retry' >&2;exit 75; }
"$packet/verify-ready.sh" "$receipt" > "$packet/$phase.readiness.stdout" 2> "$packet/$phase.readiness.stderr"
source=$base/combined_final_cache04/source
compiler=$base/compiler_effectbridge01/artifacts/madaros.elf
# Persist intent first: a lost sbatch reply must never cause automatic resubmission.
printf 'phase=%s\nremaining_authorized_seconds=%s\nreceipt=%s\n' "$phase" "$budget" "$receipt" > "$packet/$phase.SUBMISSION_ATTEMPT"
sha256sum "$receipt" "$packet/ROOT_AUTHORIZATION_LEDGER.tsv" "$packet/$template" >> "$packet/$phase.SUBMISSION_ATTEMPT"
rc=0
sbatch --chdir="$campaign" --output="$base/nested_qualification_final03/logs/$phase-%j.out" --error="$base/nested_qualification_final03/logs/$phase-%j.err" "$packet/$template" "$source" "$campaign" "$compiler" "$receipt" "$budget" > "$packet/$phase.submission.stdout" 2> "$packet/$phase.submission.stderr" || rc=$?
printf '%s\n' "$rc" > "$packet/$phase.submission.status"
cat "$packet/$phase.submission.stdout" "$packet/$phase.submission.stderr"
exit "$rc"
