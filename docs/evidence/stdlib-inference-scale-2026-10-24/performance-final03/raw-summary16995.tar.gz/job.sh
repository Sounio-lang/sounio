#!/bin/bash
#SBATCH --job-name=cache-custody-summary
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=1024M
#SBATCH --time=00:05:00
#SBATCH --export=NIL
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=/scratch/sounio-stdlib-inference-scale-20261024/custody_summary_final01
b=/scratch/sounio-stdlib-inference-scale-20261024/custody_bundle01
cd "$b"
trap 'echo "$?" > "$r/STATUS"' EXIT
[[ $(id -u) == 1000 ]]
sha256sum -c COLLECTED_INPUTS.sha256 > "$r/INPUTS.before.verify"
g++ --version > "$r/COMPILER.version"
sha256sum /usr/bin/g++ > "$r/COMPILER.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -pedantic tools/custody_summary.cpp -o "$r/summary.elf" > "$r/compile.stdout" 2> "$r/compile.stderr"
sha256sum "$r/summary.elf" > "$r/ELF.sha256"
"$r/summary.elf" "$b" > "$r/RESOURCE_SUMMARY.tsv" 2> "$r/RESOURCE_SUMMARY.stderr"
sha256sum -c COLLECTED_INPUTS.sha256 > "$r/INPUTS.after.verify"
