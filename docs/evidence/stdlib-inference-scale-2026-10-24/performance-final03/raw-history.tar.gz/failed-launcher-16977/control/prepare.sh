#!/bin/bash
# Metadata/custody only. Run once after root releases an immutable candidate.
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: CANDIDATE_FROZEN_SOURCE NEW_PACKET_ROOT' >&2;exit 64; }
candidate=$(realpath "$1");r=$2
case "$candidate" in /scratch/*/source) ;; *) echo 'frozen scratch source required' >&2;exit 65;;esac
[[ -d "$candidate/stdlib" && ! -e "$r" ]] || exit 65
mkdir -p "$r";r=$(realpath "$r")
cp -a "$(dirname "$0")" "$r/control"
(cd "$r" && find control -type f -print0|sort -z|xargs -0 sha256sum)>"$r/CONTROL.sha256"
mkdir -p "$r"/{source-before,source-after,artifacts,runs,logs,tmp,tools}
cp -a /scratch/sounio-stdlib-advanced-20261023/full02/source/stdlib "$r/source-before/"
cp -a "$candidate/stdlib" "$r/source-after/"
drivers=/scratch/sounio-stdlib-inference-scale-20261024/nested_benchmark_inputs01
cp -p "$drivers/before-driver.sio" "$r/source-before/workload.sio"
cp -p "$drivers/after-driver.sio" "$r/source-after/workload.sio"
printf '%s\n' "$candidate" >"$r/CANDIDATE_SOURCE.txt"
for v in before after;do (cd "$r/source-$v" && find stdlib workload.sio -type f -print0|sort -z|xargs -0 sha256sum)>"$r/INPUTS.$v.sha256";done
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
sha256sum "$compiler" >"$r/COMPILER.sha256"
grep -q '^92d2108ef595c5382d582aa363df6e95dab907a554f039d5f8f008073e535c21 ' "$r/COMPILER.sha256"
printf 'variant\ttrial\tstdout\tresource\tstatus\telf\tsource_sha256\telf_sha256\tcompiler_sha256\tinput_manifest\tinput_manifest_sha256\n' >"$r/RUNS.header.tsv"
printf 'PREPARED ONLY; no build, preflight, submission or native execution.\n' >"$r/PREPARED"
