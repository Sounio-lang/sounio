# Prepared B199 benchmark protocol — NOT SUBMITTED

Root must first release the final immutable candidate after pilot07 and final
correctness. Nothing in this packet submits a job. No candidate is selected yet.

1. Run `bash prepare.sh /scratch/.../FINAL/source /scratch/.../NEW_B199_PACKET`.
   This copies only baseline ORIGINAL full02 stdlib and final frozen candidate
   stdlib, plus the exact already-custodied B199 before/after drivers. It performs
   metadata copies/hashes only. n256/alpha0/case0/B199/maxfits400, data and seeds
   remain exactly those sources; no pilot substitutions.
2. Root submits `control/build.sbatch PACKET` via the existing Slurm login route,
   with persistent chdir/output/error names. It compiles each variant exactly
   once using compiler92d2108e, then compiles the existing C++ analyzer and tiny
   preflight adapter. Candidate preflight uses the SAME after ELF and validates
   complete available B199 output through the analyzer's scientific parser.
   It is outside RUNS.tsv and cannot substitute for a measured trial. Failure
   prevents all pair jobs. This allocation allows35min, not a timing claim.
3. Only after BUILD_STATUS0 + PREFLIGHT_PASS, submit three separate pair.sbatch
   jobs with arguments PACKET 1/2/3. Each requests1CPU/4GiB/45min. Serialize them
   (afterok dependencies) to avoid competing benchmark allocations. Pair1/3 order
   is before→after; pair2 is after→before. Each invocation is a fresh process.
4. After all three PAIR status0, run analyze.sbatch. It assembles exactly six
   eleven-field rows and invokes the unchanged analyzer in FULL mode. Numerical
   medians/ratios/resource criteria are computed only by C++23 inside Slurm.

The preflight and pair calls use srun --cpu-bind=cores. Read-only controller
configuration reports TaskPlugin=task/cgroup,task/affinity and
SelectTypeParameters=CR_CORE_MEMORY; srun help advertises --cpu-bind. Actual binding
must still be read from each run's taskset/proc context, not inferred from config.
The wrapper records Slurm IDs, hostname, actual CPU/memory affinity, cgroup path
and readable cgroup v2 cpu.max/cpuset/memory.max. If a file is not exposed, it is
not fabricated. GNU time wraps direct ELF execution inside the bound step, so
step startup and file hashing are outside the measured native resource interval.
Compiler/integrity/source/ELF/stdout/status/resource/context receipts are retained.
Parent stack ceiling524288KiB is a ceiling, not an RSS reservation.

Each measured ELF has1260second timeout, with kill grace15seconds. A pair thus has
bounded execution time within its45min allocation plus verification overhead;
any failure or allocation timeout leaves raw partial outputs and no accepted
six-row report. No run is retried/dropped to obtain a faster sample.

Historical baseline B199 operational observation was roughly16minutes, while
candidate B199 duration remains unmeasured. Budget three45minute pair allocations
plus35minute build/preflight and5minute C++ analysis allocations conservatively.
These are requested ceilings, not projected runtime or statistical measurements.
No2x speedup or ≤5%RSS outcome is asserted before all three actual pairs pass.
The unchanged analyzer also requires CAL_RESULT/P/RNG identical across all six;
if correctness changes those outputs, it fails rather than normalizing them.
Drivers emit only final RNG/hits/B, so counters_available remains false. No
uniform/proposal counts are invented. This comparison is a single fixed dataset,
not a general scalability or calibration result.

Canonical drivers:
- before051c13a928911442fa4eb4b724bd2d0b21e6af18068df01e4c264b6af73bdd1f
- after96dcce2757d36f97fa478f6b2850018fb4c523979ba2d5f2d8422173b9953352
Compiler92d2108ef595c5382d582aa363df6e95dab907a554f039d5f8f008073e535c21.
