// C++23 validation only. This run is excluded from the three measured pairs.
#define main benchmark_saved_main
#include "count_profile_benchmark_reference.cpp"
#undef main
int main(int argc,char**argv){try{need(argc==2,"preflight stdout argument");const auto row=scientific(argv[1],199);std::cout<<"preflight_only_not_measured\ttrue\n"<<row.result_line<<'\n'<<row.p_line<<'\n';return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
