#!/bin/bash
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=$(realpath "$1");v=$2;trial=$3
[[ $v == before || $v == after ]];[[ $trial =~ ^[123]$ || $trial == preflight ]]
[[ $(id -u) == 1000 && ${SLURM_JOB_ID:-} =~ ^[1-9][0-9]*$ ]]
prefix="$r/runs/$v-$trial";[[ ! -e "$prefix.status" && ! -e "$prefix.stdout" ]]
ulimit -s 524288
{
 printf 'slurm_job_id=%s\nslurm_step_id=%s\nstack_kb=%s\n' "$SLURM_JOB_ID" "${SLURM_STEP_ID:-}" "$(ulimit -s)"
 hostname;taskset -pc $$;grep -E 'Cpus_allowed_list|Mems_allowed_list' /proc/self/status
 cat /proc/self/cgroup
 for name in cpu.max cpuset.cpus.effective cpuset.mems.effective memory.max;do
  cgroup=$(awk -F: '$1==0 {print $3}' /proc/self/cgroup)
  f="/sys/fs/cgroup$cgroup/$name";if [[ -r $f ]];then printf '%s=' "$f";cat "$f";fi
 done
} >"$prefix.context"
(cd "$r" && sha256sum -c "artifacts/$v.ELF.sha256") >"$prefix.elf-before.verify"
(cd "$r/source-$v" && sha256sum -c "$r/INPUTS.$v.sha256") >"$prefix.inputs-before.verify"
rc=0
(cd "$r/source-$v"; /usr/bin/time -v -o "$prefix.resource" timeout --kill-after=15 1260 env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C COUNT_PROFILE_CALIBRATION_CASE=0 "$r/artifacts/$v.elf") >"$prefix.stdout" 2>"$prefix.stderr" || rc=$?
printf '%s\n' "$rc" >"$prefix.status"
(cd "$r" && sha256sum -c "artifacts/$v.ELF.sha256") >"$prefix.elf-after.verify"
(cd "$r/source-$v" && sha256sum -c "$r/INPUTS.$v.sha256") >"$prefix.inputs-after.verify"
sha256sum "$prefix.stdout" "$prefix.stderr" "$prefix.resource" "$prefix.context" >"$prefix.OUTPUTS.sha256"
[[ $rc == 0 ]] || exit "$rc"
[[ $trial == preflight ]] && exit 0
srcsha=$(sha256sum "$r/source-$v/workload.sio");elfsha=$(sha256sum "$r/artifacts/$v.elf");csha=$(sha256sum /scratch/sounio-stdlib-inference-scale-20261024/compiler_effectbridge01/artifacts/madaros.elf);msha=$(sha256sum "$r/INPUTS.$v.sha256")
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$v" "$trial" "$prefix.stdout" "$prefix.resource" "$prefix.status" "$r/artifacts/$v.elf" "${srcsha%% *}" "${elfsha%% *}" "${csha%% *}" "$r/INPUTS.$v.sha256" "${msha%% *}" >"$prefix.row.tsv"
