#!/usr/bin/env bash
# PREPARED ONLY. Root executes explicitly after reviewing actual analysis17033.
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
base=/scratch/sounio-stdlib-inference-scale-20261024
packet=$base/nested_qualification_final03/packet
campaign=$base/nested_qualification_final03/campaign
analysis=$base/profile_B199_final03
receipt=$base/combined_final_cache04/FUNCTIONAL_GATE_RECEIPT.txt
ledger=$packet/ROOT_AUTHORIZATION_LEDGER.tsv
[[ $(id -u) == 1000 ]]

# Actual completed analysis; job success alone does not establish target success.
[[ -f "$analysis/ANALYSIS_STATUS" ]]
[[ $(cat "$analysis/ANALYSIS_STATUS") == 0 ]]
sacct -j 17033 --format=JobID,State,ExitCode -P --noheader |
  awk -F'|' '$1=="17033" {
    count++; if($2!="COMPLETED" || $3!="0:0") bad=1
  } END {exit count!=1 || bad}'

require_report() {
  awk -F'\t' -v key="$1" -v expected="$2" '
    $1==key {count++; if(NF!=2 || $2!=expected) bad=1}
    END {exit count!=1 || bad}
  ' "$analysis/REPORT.tsv"
}
require_report mode full_B199_three_pairs
require_report scientific_rows_identical true
require_report descriptive_time_target_at_least2x true
require_report descriptive_maxrss_target_at_most5percent true

# Correct packet and current readiness before any authorization is written.
cd "$packet"
actual=$(sha256sum ROUND_HARDCAP_FILES)
[[ ${actual%% *} == db223b45278cfbe91cb9e7c9dd1e143a6b27e8f308a25a2eb3346fd52407da42 ]]
sha256sum -c ROUND_HARDCAP_FILES
actual=$(sha256sum verify-ready.sh)
[[ ${actual%% *} == ae405b62dcef05eb5f89604d80dad3ae41f36fa93296a6850b3c86a04a3ab1e9 ]]
bash verify-ready.sh "$receipt" \
  > round.operator-readiness.stdout 2> round.operator-readiness.stderr

report_sha=$(sha256sum "$analysis/REPORT.tsv")
report_sha=${report_sha%% *}

# Authorize once under the same lock as the launcher. Closing this subshell
# releases the lock before the launcher acquires its own descriptor.
(
  exec 9>"$packet/submission.lock"
  flock -n 9
  [[ ! -e "$packet/round.SUBMISSION_ATTEMPT" ]]
  [[ ! -e "$campaign/qualification_nested_B199" ]]
  [[ ! -e "$packet/ROOT_AUTHORIZATION_LEDGER.before-round-17033.tsv" ]]

  awk -F'\t' '$1=="pilot" {
    count++
    if(NF!=4 || $2!="900" || $3!="0" ||
       $4!="root-approved-plan-full17020-source6ffc") bad=1
  } END {exit count!=1 || bad}' "$ledger"
  awk -F'\t' '$1=="round" {count++} END {exit count!=0}' "$ledger"

  cp -p "$ledger" "$packet/ROOT_AUTHORIZATION_LEDGER.before-round-17033.tsv"
  printf 'round\t85500\t900\troot-approved-after17033-targets-report-%s\n' \
    "$report_sha" >> "$ledger"
)

# No retry or rollback on failure: retain intent and inspect actual scheduler state.
bash "$packet/submit-phase-hardcap.sh" round "$receipt" 85500
