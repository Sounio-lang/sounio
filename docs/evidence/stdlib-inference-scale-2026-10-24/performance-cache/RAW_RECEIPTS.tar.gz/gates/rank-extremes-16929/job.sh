#!/bin/bash
#SBATCH --job-name=rank-extremes03
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:05:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-advanced-20261023/rank_fastlocal02/source
#SBATCH --output=/scratch/sounio-stdlib-advanced-20261023/rank_extremes03/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-advanced-20261023/rank_extremes03/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin
ulimit -s 524288
r=/scratch/sounio-stdlib-advanced-20261023/rank_extremes03
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
export SOUNIO_STDLIB_PATH=$PWD/stdlib
sha256sum "$compiler" "$r/driver.sio" stdlib/stats/regression/{nb2_likelihood,nb2_log_increment}.sio > "$r/INPUTS.sha256"
timeout 180 "$compiler" check "$r/driver.sio" > "$r/check.stdout" 2> "$r/check.stderr"
timeout 240 "$compiler" build "$r/driver.sio" --target native -o "$r/driver.elf" > "$r/compile.stdout" 2> "$r/compile.stderr"
chmod +x "$r/driver.elf"
rc=0
timeout 60 "$r/driver.elf" > "$r/native.stdout" 2> "$r/native.stderr" || rc=$?
printf '%s\n' "$rc" > "$r/native.status"
[[ $rc == 0 ]]
grep -Fq 'CHECKED RANK DIFFERENCE PASS' "$r/native.stdout"
sha256sum "$r/driver.elf" > "$r/ELF.sha256"
sha256sum -c "$r/INPUTS.sha256" > "$r/INPUTS.after.verify"
printf '0\n' > "$r/STATUS"
