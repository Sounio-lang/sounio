#!/bin/bash
#SBATCH --job-name=stdlib-profile-pilot31
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/profile_pilot06/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/profile_pilot06/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=/scratch/sounio-stdlib-inference-scale-20261024/profile_pilot06
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
finish(){ local rc=$?; printf '%s\n' "$rc" > "$r/STATUS"; }
trap finish EXIT
[[ $(id -u) == 1000 ]]
[[ $(cat /scratch/sounio-stdlib-advanced-20261023/normalizer_cache01/artifacts/STATUS) == NORMALIZER_CACHE_FOCUSED_PASS ]]
ulimit -s 524288
export TMPDIR="$r/tmp"
sha256sum "$compiler" > "$r/COMPILER.sha256"
printf '%s  %s\n' 92d2108ef595c5382d582aa363df6e95dab907a554f039d5f8f008073e535c21 "$compiler" | sha256sum -c -
for v in before after; do
 (cd "$r/source-$v"; find stdlib workload.sio -type f -print0 | sort -z | xargs -0 sha256sum) > "$r/INPUTS.$v.sha256"
done
sha256sum "$r/tools/count_profile_benchmark_reference.cpp" "$r/job.sh" > "$r/TOOLS.sha256"
g++ -std=c++23 -O2 -Wall -Wextra "$r/tools/count_profile_benchmark_reference.cpp" -o "$r/tools/analyzer" > "$r/tools/compile.stdout" 2> "$r/tools/compile.stderr"
# Mandatory nesting/preflight fixture; no grouped-B2 comparator is applied to it.
cd "$r/source-after"
export SOUNIO_STDLIB_PATH="$r/source-after/stdlib"
status_fixture=/scratch/sounio-stdlib-advanced-20261023/normalizer_cache01/source/tests/run-pass/stdlib_deep_stats_count_profile_nested.sio
sha256sum "$status_fixture" > "$r/NESTING_INPUT.sha256"
timeout 180 "$compiler" check "$status_fixture" > "$r/artifacts/nesting.check.stdout" 2> "$r/artifacts/nesting.check.stderr"
timeout 240 "$compiler" build "$status_fixture" --target native -o "$r/artifacts/nesting.elf" > "$r/artifacts/nesting.compile.stdout" 2> "$r/artifacts/nesting.compile.stderr"
chmod +x "$r/artifacts/nesting.elf"
timeout 300 "$r/artifacts/nesting.elf" > "$r/artifacts/nesting.stdout" 2> "$r/artifacts/nesting.stderr"
while IFS= read -r marker; do [[ -z $marker ]] || grep -Fq -- "$marker" "$r/artifacts/nesting.stdout"; done < <(sed -nE 's|^//@ expect-stdout(-contains)?: ||p' "$status_fixture")
printf '0\n' > "$r/artifacts/nesting.status"
for v in before after; do
 cd "$r/source-$v"
 export SOUNIO_STDLIB_PATH="$r/source-$v/stdlib"
 /usr/bin/time -v -o "$r/artifacts/$v.compile.resource" timeout 240 "$compiler" build workload.sio --target native -o "$r/artifacts/$v.elf" > "$r/artifacts/$v.compile.stdout" 2> "$r/artifacts/$v.compile.stderr"
 chmod +x "$r/artifacts/$v.elf"
done
printf 'variant\ttrial\tstdout\tresource\tstatus\telf\tsource_sha256\telf_sha256\tcompiler_sha256\tinput_manifest\tinput_manifest_sha256\n' > "$r/RUNS.tsv"
for v in before after; do
 cd "$r/source-$v"
 rc=0
 /usr/bin/time -v -o "$r/runs/$v.resource" timeout --kill-after=10 600 env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C COUNT_PROFILE_CALIBRATION_CASE=0 "$r/artifacts/$v.elf" > "$r/runs/$v.stdout" 2> "$r/runs/$v.stderr" || rc=$?
 printf '%s\n' "$rc" > "$r/runs/$v.status"
 [[ $rc == 0 ]] || exit "$rc"
 srcsha=$(sha256sum workload.sio);elfsha=$(sha256sum "$r/artifacts/$v.elf");csha=$(sha256sum "$compiler");msha=$(sha256sum "$r/INPUTS.$v.sha256")
 printf '%s\t1\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$v" "$r/runs/$v.stdout" "$r/runs/$v.resource" "$r/runs/$v.status" "$r/artifacts/$v.elf" "${srcsha%% *}" "${elfsha%% *}" "${csha%% *}" "$r/INPUTS.$v.sha256" "${msha%% *}" >> "$r/RUNS.tsv"
 sha256sum -c "$r/INPUTS.$v.sha256" > "$r/INPUTS.$v.verify"
done
"$r/tools/analyzer" --pilot "$r/source-before/workload.sio" "$r/source-after/workload.sio" "$r/RUNS.tsv" "$compiler" > "$r/REPORT.tsv" 2> "$r/REPORT.stderr"
sha256sum -c "$r/NESTING_INPUT.sha256" > "$r/NESTING_INPUT.after.verify"
sha256sum -c "$r/TOOLS.sha256" > "$r/TOOLS.after.verify"
sha256sum -c "$r/COMPILER.sha256" > "$r/COMPILER.verify"
