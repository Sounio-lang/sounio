#!/bin/bash
#SBATCH --job-name=trace-typed11
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:10:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-advanced-20261023/trace_typed12/source
#SBATCH --output=/scratch/sounio-stdlib-advanced-20261023/trace_typed12/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-advanced-20261023/trace_typed12/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin
ulimit -s 524288
run=/scratch/sounio-stdlib-advanced-20261023/trace_typed12
src=$run/source
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler/artifacts/madaros.elf
sha256sum "$compiler" stdlib/stats/regression/{count_fit_trace.sio,dynamic_count_glm.sio,dynamic_dispersion.sio,dynamic_count_profile_bootstrap.sio,nb2_likelihood.sio,nb2_log_increment.sio,count_profile_embedding.sio} tests/run-pass/stdlib_scale_count_profile_{traced,nested_bootstrap}.sio tests/reference/{deep_stats_count_profile_bootstrap_reference,deep_count_sampling_reference}.cpp > "$run/INPUTS.sha256"
g++ -std=c++23 -O2 tests/reference/deep_stats_count_profile_bootstrap_reference.cpp -lquadmath -o "$run/reference" > "$run/cpp.compile.stdout" 2> "$run/cpp.compile.stderr"
for name in stdlib_scale_count_profile_traced stdlib_scale_count_profile_nested_bootstrap; do
 env -i PATH=/usr/bin:/bin SOUNIO_STDLIB_PATH="$src/stdlib" SOUNIO_MADAROS_NOCACHE=1 SOUNIO_MADAROS_CACHE_READONLY=1 "$compiler" build "tests/run-pass/$name.sio" --target native -o "$run/$name.elf" > "$run/$name.compile.stdout" 2> "$run/$name.compile.stderr"
 chmod +x "$run/$name.elf"
 env -i PATH=/usr/bin:/bin /usr/bin/time -v -o "$run/$name.resource" "$run/$name.elf" > "$run/$name.stdout" 2> "$run/$name.stderr"
 printf '0\n' > "$run/$name.native.status"
 grep -q 'DEEP COUNT PROFILE NESTED BOOTSTRAP PASS' "$run/$name.stdout"
 "$run/reference" --nested-single "$run/$name.stdout" > "$run/$name.cpp.stdout" 2> "$run/$name.cpp.stderr"
 printf '0\n' > "$run/$name.cpp.status"
done
sha256sum "$run/"*.elf "$run/reference" > "$run/ELFS.sha256"
sha256sum -c "$run/INPUTS.sha256" > "$run/INPUTS.after.verify"
printf 'TYPED_CONTROL_PASS\n' > "$run/STATUS"
