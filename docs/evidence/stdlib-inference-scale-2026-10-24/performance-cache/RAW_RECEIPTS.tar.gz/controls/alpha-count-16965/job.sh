#!/bin/bash
#SBATCH --job-name=cached-rank-controls
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-advanced-20261023/cached_rank_controls02
#SBATCH --output=/scratch/sounio-stdlib-advanced-20261023/cached_rank_controls02/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-advanced-20261023/cached_rank_controls02/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin
ulimit -s 524288
r=/scratch/sounio-stdlib-advanced-20261023/cached_rank_controls02
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
for v in original alpha hit; do
 cd "$r/source-$v"
 export SOUNIO_STDLIB_PATH="$PWD/stdlib"
 fixture=tests/run-pass/stdlib_scale_count_cached_rank_far.sio
 [[ $v != hit ]] || fixture=tests/run-pass/stdlib_scale_count_cached_rank_status.sio
 sha256sum "$compiler" stdlib/stats/regression/nb2_likelihood.sio "$fixture" > "$r/$v.INPUTS.sha256"
 timeout 240 "$compiler" build "$fixture" --target native -o "$r/$v.elf" > "$r/$v.compile.stdout" 2> "$r/$v.compile.stderr"
 printf '0\n' > "$r/$v.compile.status"
 chmod +x "$r/$v.elf"
 rc=0
 timeout 60 "$r/$v.elf" > "$r/$v.stdout" 2> "$r/$v.stderr" || rc=$?
 printf '%s\n' "$rc" > "$r/$v.native.status"
 if [[ $v == original ]]; then [[ $rc == 0 ]]; else [[ $rc == 1 ]]; fi
 sha256sum -c "$r/$v.INPUTS.sha256" > "$r/$v.INPUTS.after.verify"
 sha256sum "$r/$v.elf" > "$r/$v.ELF.sha256"
done
cd "$r/source-original"
sha256sum tests/reference/count_cached_rank_reference.cpp tests/reference/count_dispersion_increment_reference.cpp > "$r/CPP_INPUTS.sha256"
timeout 240 g++ -std=c++23 -O2 tests/reference/count_cached_rank_reference.cpp -o "$r/reference" > "$r/cpp.compile.stdout" 2> "$r/cpp.compile.stderr"
timeout 180 "$r/reference" "$r/original.stdout" > "$r/cpp.stdout" 2> "$r/cpp.stderr"
sha256sum -c "$r/CPP_INPUTS.sha256" > "$r/CPP_INPUTS.after.verify"
printf 'FAR_CPP_AND_COMPILED_MUTANTS_PASS\n' > "$r/STATUS"
