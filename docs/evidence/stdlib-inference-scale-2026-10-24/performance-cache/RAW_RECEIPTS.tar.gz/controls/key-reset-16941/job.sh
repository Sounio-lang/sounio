#!/bin/bash
#SBATCH --job-name=normalizer-cache-mutants
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:10:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-advanced-20261023/normalizer_cache_controls02
#SBATCH --output=/scratch/sounio-stdlib-advanced-20261023/normalizer_cache_controls02/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-advanced-20261023/normalizer_cache_controls02/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin
ulimit -s 524288
r=/scratch/sounio-stdlib-advanced-20261023/normalizer_cache_controls02
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
for v in key reset; do
 cd "$r/source-$v"
 export SOUNIO_STDLIB_PATH="$PWD/stdlib"
 sha256sum "$compiler" stdlib/stats/regression/nb2_likelihood.sio tests/run-pass/stdlib_scale_count_normalizer_cache.sio > "$r/$v.INPUTS.sha256"
 timeout 240 "$compiler" build tests/run-pass/stdlib_scale_count_normalizer_cache.sio --target native -o "$r/$v.elf" > "$r/$v.compile.stdout" 2> "$r/$v.compile.stderr"
 printf '0\n' > "$r/$v.compile.status"
 chmod +x "$r/$v.elf"
 rc=0
 timeout 60 "$r/$v.elf" > "$r/$v.native.stdout" 2> "$r/$v.native.stderr" || rc=$?
 printf '%s\n' "$rc" > "$r/$v.native.status"
 [[ $rc == 1 ]]
 if grep -Fq 'CHECKED NORMALIZER CACHE PASS' "$r/$v.native.stdout"; then exit 1; fi
 sha256sum -c "$r/$v.INPUTS.sha256" > "$r/$v.INPUTS.after.verify"
 sha256sum "$r/$v.elf" > "$r/$v.ELF.sha256"
done
printf 'BOTH_COMPILED_MUTANTS_REJECTED\n' > "$r/STATUS"
