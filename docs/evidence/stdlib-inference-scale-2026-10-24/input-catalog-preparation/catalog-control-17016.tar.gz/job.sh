#!/bin/bash
#SBATCH --job-name=input-catalog-prewarm-control
#SBATCH --partition=cpu-ops
#SBATCH --cpus-per-task=1
#SBATCH --mem=1024M
#SBATCH --time=00:05:00
#SBATCH --export=NIL
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/input_catalog_prewarm_control01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/input_catalog_prewarm_control01/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=/scratch/sounio-stdlib-inference-scale-20261024/input_catalog_prewarm_control01
s=/scratch/sounio-stdlib-inference-scale-20261024/combined_final_cache02/source
a=$r/artifacts
finish(){ rc=$?; printf '%s\n' "$rc" > "$a/STATUS"; }
trap finish EXIT
[[ ${SLURM_JOB_ID:-} =~ ^[1-9][0-9]*$ && $(id -u) == 1000 ]] || exit 65
cd "$s"
printf 'kind\tsource\texit_status\n' > "$a/RESULTS.tsv"
old=/scratch/sounio-stdlib-inference-scale-20261024/combined_final_cache02/artifacts/INPUTS.sha256
cp "$old" "$a/ORIGINAL_INPUTS.sha256"
cp ../SOURCE_HEAD "$a/SOURCE_HEAD"
sha256sum bin/madaros-linux-x86_64.gz bin/madaros-linux-x86_64.sha256 scripts/lib/materialize_madaros_prebuilt.sh > "$a/PINNED_INPUTS.sha256"
sha256sum /scratch/sounio-stdlib-inference-scale-20261024/compiler_effectbridge01/artifacts/madaros.elf > "$a/SELECTED_COMPILER.sha256"
# Existing warm source only. No ELF execution and no cold clone or deletion.
find -L bin scripts self-hosted stdlib tests examples -type f -print0 | sort -z | xargs -0 sha256sum > "$a/WARM_FULL_CATALOG.before.sha256"
rc=0;cmp "$old" "$a/WARM_FULL_CATALOG.before.sha256" > "$a/old-vs-warm.cmp.stdout" 2> "$a/old-vs-warm.cmp.stderr" || rc=$?
[[ $rc == 1 ]]
printf 'control\told-fullcatalog:expected=1:actual=%s\t0\n' "$rc" >> "$a/RESULTS.tsv"
sort "$old" > "$a/old.sorted"
sort "$a/WARM_FULL_CATALOG.before.sha256" > "$a/warm.sorted"
comm -23 "$a/old.sorted" "$a/warm.sorted" > "$a/REMOVED_OR_CHANGED.txt"
comm -13 "$a/old.sorted" "$a/warm.sorted" > "$a/ADDED_OR_CHANGED.txt"
[[ ! -s "$a/REMOVED_OR_CHANGED.txt" ]]
[[ $(wc -l < "$a/ADDED_OR_CHANGED.txt") == 2 ]]
awk '$2!="bin/madaros-linux-x86_64"&&$2!="bin/.madaros-linux-x86_64.verified"{exit 1} END{if(NR!=2)exit 1}' "$a/ADDED_OR_CHANGED.txt"
printf 'control\texact-two-derived-files-only\t0\n' >> "$a/RESULTS.tsv"
sha256sum -c "$old" > "$a/ORIGINAL_SUBSET.verify"
want=$(awk 'NR==1{print $1}' bin/madaros-linux-x86_64.sha256)
[[ $want =~ ^[0-9a-f]{64}$ ]]
have=$(sha256sum bin/madaros-linux-x86_64);have=${have%% *}
gzip -dc bin/madaros-linux-x86_64.gz | sha256sum > "$a/DECOMPRESSED_STREAM.sha256"
read -r unpacked _ < "$a/DECOMPRESSED_STREAM.sha256"
[[ $want == "$have" && $want == "$unpacked" ]]
printf 'control\tgzip-stream-tracked-sha-materialized-elf-equal\t0\n' >> "$a/RESULTS.tsv"
# Validate the existing stamp BEFORE calling the normal-mode fast path.
source scripts/lib/materialize_madaros_prebuilt.sh
size=$(wc -c < bin/madaros-linux-x86_64 | tr -d ' ')
identity=$(_sounio_madaros_stat_inode_mtime_ctime bin/madaros-linux-x86_64)
[[ $(cat bin/.madaros-linux-x86_64.verified) == "$want $size $identity" ]]
cp bin/.madaros-linux-x86_64.verified "$a/STAMP.before.txt"
printf 'control\texisting-stamp-hash-size-inode-mtime-ctime\t0\n' >> "$a/RESULTS.tsv"
bash scripts/lib/materialize_madaros_prebuilt.sh > "$a/prewarm1.stdout" 2> "$a/prewarm1.stderr"
find -L bin scripts self-hosted stdlib tests examples -type f -print0 | sort -z | xargs -0 sha256sum > "$a/WARM_FULL_CATALOG.after1.sha256"
cmp "$a/WARM_FULL_CATALOG.before.sha256" "$a/WARM_FULL_CATALOG.after1.sha256" > "$a/after1.compare.txt"
printf 'control\tfullcatalog-stable-after-prewarm1\t0\n' >> "$a/RESULTS.tsv"
bash scripts/lib/materialize_madaros_prebuilt.sh > "$a/prewarm2.stdout" 2> "$a/prewarm2.stderr"
find -L bin scripts self-hosted stdlib tests examples -type f -print0 | sort -z | xargs -0 sha256sum > "$a/WARM_FULL_CATALOG.after2.sha256"
cmp "$a/WARM_FULL_CATALOG.after1.sha256" "$a/WARM_FULL_CATALOG.after2.sha256" > "$a/after2.compare.txt"
printf 'control\tfullcatalog-stable-after-prewarm2\t0\n' >> "$a/RESULTS.tsv"
sha256sum -c "$a/PINNED_INPUTS.sha256" > "$a/PINNED_INPUTS.after.verify"
sha256sum -c "$a/SELECTED_COMPILER.sha256" > "$a/SELECTED_COMPILER.after.verify"
printf 'OPERATIONAL CATALOG CONTROL PASS; NO COMPILER EXECUTION, CAMPAIGN OR FUNCTIONAL RECEIPT\n' > "$a/COMPLETE.txt"
