#!/bin/bash
#SBATCH --job-name=ownerfix-closure-bridge-check
#SBATCH --partition=cpu-ops
#SBATCH --cpus-per-task=1
#SBATCH --mem=16384M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_bridge01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_bridge01/logs/slurm-%j.err
set -uo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_bridge01
cd "$r/source" || exit 65
export SOUNIO_STDLIB_PATH="$r/source/stdlib" TMPDIR="$r/tmp"
export SOUNIO_MADAROS_NOCACHE=1 SOUNIO_MADAROS_CACHE_READONLY=1 SOUNIO_MADAROS_CACHE="$r/cache"
ulimit -s 524288
compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf
sha256sum "$compiler" > "$r/artifacts/COMPILER.sha256"
find self-hosted stdlib -type f -print0 | sort -z | xargs -0 sha256sum > "$r/artifacts/INPUTS.sha256"
rc=0
/usr/bin/time -v -o "$r/artifacts/after.resource" timeout 350 "$compiler" check self-hosted/compiler/main.sio > "$r/artifacts/after.stdout" 2> "$r/artifacts/after.stderr" || rc=$?
printf '%s\n' "$rc" > "$r/artifacts/after.status"
sha256sum -c "$r/artifacts/INPUTS.sha256" > "$r/artifacts/INPUTS.after.verify" || rc=1
sha256sum -c "$r/artifacts/COMPILER.sha256" > "$r/artifacts/COMPILER.after.verify" || rc=1
printf '%s\n' "$rc" > "$r/artifacts/STATUS"
exit "$rc"
