#!/bin/bash
#SBATCH --job-name=ownerfix-selfcheck-baseline
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=16384M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_baseline01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_baseline01/logs/slurm-%j.err
set -uo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
r=/scratch/sounio-stdlib-inference-scale-20261024/gen2_selfcheck_baseline01
cd "$r/source"
export SOUNIO_STDLIB_PATH="$r/source/stdlib" TMPDIR="$r/tmp"
ulimit -s 524288
find self-hosted stdlib -type f -print0 | sort -z | xargs -0 sha256sum > "$r/artifacts/INPUTS.sha256"
for mode in before after; do
 if [[ $mode == before ]]; then compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_main29ce/artifacts/madaros.elf; else compiler=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ownerfix01/artifacts/madaros.elf; fi
 sha256sum "$compiler" > "$r/artifacts/$mode.COMPILER.sha256"
 rc=0
 /usr/bin/time -v -o "$r/artifacts/$mode.resource" timeout 350 "$compiler" check self-hosted/compiler/main.sio > "$r/artifacts/$mode.stdout" 2> "$r/artifacts/$mode.stderr" || rc=$?
 printf '%s\n' "$rc" > "$r/artifacts/$mode.status"
done
sha256sum -c "$r/artifacts/INPUTS.sha256" > "$r/artifacts/INPUTS.after.verify"
printf 'BASELINE_CLASSIFICATION_COMPLETE\n' > "$r/artifacts/STATUS"
