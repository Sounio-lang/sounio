#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:10:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/perf02/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/perf02/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
export NB2_CACHE_BEFORE_ROOT=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/before02
export NB2_CACHE_AFTER_ROOT=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/after01
export NB2_CACHE_OUTPUT=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/perf02/out
exec bash /scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/perf02/source/scripts/stdlib/nb2_slot_cache_gate.sh

