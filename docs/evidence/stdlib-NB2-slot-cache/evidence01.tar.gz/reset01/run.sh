#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:10:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/reset01/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/reset01/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
base=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache
out="$base/reset01/out";mkdir "$out"
trap 's=$?;echo "$s">"$base/reset01/STATUS"' EXIT
fixture="$base/reset01/source/tests/run-pass/stdlib_nb2_slot_cache.sio"
ref="$base/reset01/source/tests/reference/nb2_slot_cache_reference.cpp"
sha256sum "$fixture" "$ref" "$base/before02/source/stdlib/stats/regression/nb2_likelihood.sio" "$base/after01/source/stdlib/stats/regression/nb2_likelihood.sio">"$out/SOURCE.sha256"
g++ -std=c++23 -O2 -Wall -Wextra -Werror "$ref" -lquadmath -o "$out/reference">"$out/build.stdout" 2>"$out/build.stderr"
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
for variant in before02 after01;do
 cd "$base/$variant/source";export SOUNIO_STDLIB_PATH="$PWD/stdlib"
 for engine in madaros lean_single;do
  export SOUNIO_SOUC_ENGINE="$engine"
  name="$out/$variant.$engine"
  bin/souc check "$fixture">"$name.check.stdout" 2>"$name.check.stderr"
  if grep -E '^error:|error\[E' "$name.check.stdout" "$name.check.stderr";then exit 71;fi
  bin/souc compile "$fixture" -o "$name.elf">"$name.compile.stdout" 2>"$name.compile.stderr"
  if grep -E '^error:|error\[E' "$name.compile.stdout" "$name.compile.stderr";then exit 72;fi
  chmod +x "$name.elf";sha256sum "$name.elf">"$name.ELF.sha256"
  "$name.elf">"$name.native.stdout" 2>"$name.native.stderr"
  "$out/reference" "$name.native.stdout">"$name.reference.stdout" 2>"$name.reference.stderr"
 done
done
for engine in madaros lean_single;do cmp "$out/before02.$engine.native.stdout" "$out/after01.$engine.native.stdout";done
echo NB2_SAME_KEY_RESET_BOTH_IDENTITY_PASS

