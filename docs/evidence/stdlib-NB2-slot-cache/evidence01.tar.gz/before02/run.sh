#!/bin/bash
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/before02/slurm.%j.stdout
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/before02/slurm.%j.stderr
set -euo pipefail
export PATH=/usr/bin:/bin LC_ALL=C LANG=C
ulimit -s 524288
ulimit -c 0
base=/scratch/sounio-stdlib-inference-scale-20261024/SIO171-nb2-slot-cache/before02
out="$base/out";mkdir "$out"
trap 's=$?;echo "$s">"$base/STATUS"' EXIT
cd "$base/source"
ln -s /scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64 bin/souc-lean-single-x86_64
export SOUNIO_STDLIB_PATH="$PWD/stdlib"
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
find stdlib tests scripts bin -type f -print0|sort -z|xargs -0 sha256sum>"$out/SOURCE.sha256"
sha256sum "$MADAROS_RAW_BIN" bin/souc-lean-single-x86_64>"$out/COMPILERS.sha256"
id>"$out/identity.txt"
g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/nb2_slot_cache_reference.cpp -lquadmath -o "$out/reference">"$out/reference.build.stdout" 2>"$out/reference.build.stderr"
for engine in madaros lean_single;do
 export SOUNIO_SOUC_ENGINE="$engine"
 for test in stdlib_nb2_slot_cache stdlib_deep_stats_nb2_likelihood stdlib_deep_nb2_likelihood_scratch stdlib_deep_stats_dispersion_profile profile_main control_main;do
  src="tests/run-pass/$test.sio"
  if [[ $test == profile_main || $test == control_main ]];then src="tests/stdlib/nb2_slot_cache/$test.sio";fi
  name="$out/$engine.$test"
  bin/souc check "$src">"$name.check.stdout" 2>"$name.check.stderr"
  if grep -E '^error:|error\[E' "$name.check.stdout" "$name.check.stderr";then exit 71;fi
  bin/souc compile "$src" -o "$name.elf">"$name.compile.stdout" 2>"$name.compile.stderr"
  if grep -E '^error:|error\[E' "$name.compile.stdout" "$name.compile.stderr";then exit 72;fi
  chmod +x "$name.elf";sha256sum "$name.elf">"$name.ELF.sha256"
  /usr/bin/time -v "$name.elf">"$name.native.stdout" 2>"$name.native.stderr"
 done
 "$out/reference" "$out/$engine.stdlib_nb2_slot_cache.native.stdout">"$out/$engine.reference.stdout" 2>"$out/$engine.reference.stderr"
done
for ref in deep_stats_nb2_likelihood deep_stats_dispersion_profile;do
 g++ -std=c++23 -O2 "tests/reference/$ref""_reference.cpp" -lquadmath -o "$out/$ref.reference">"$out/$ref.cpp.stdout" 2>"$out/$ref.cpp.stderr"
 for engine in madaros lean_single;do
  "$out/$ref.reference" "$out/$engine.stdlib_$ref.native.stdout">"$out/$engine.$ref.reference.stdout" 2>"$out/$engine.$ref.reference.stderr"
 done
done
echo NB2_SLOT_CACHE_BEFORE_PASS

