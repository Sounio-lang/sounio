#!/usr/bin/env bash
#SBATCH --job-name=SIO226-seed01
#SBATCH --partition=cpu-ops
#SBATCH --nodelist=cpuops-t560-proxmox
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:30:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/logs/slurm-%j.err
set -euo pipefail
base=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01
export PATH="$base/tools:/usr/bin:/bin" LANG=C LC_ALL=C
ulimit -s 524288;ulimit -c 0
mkdir "$base/artifacts"
out="$base/artifacts"
trap 'rc=$?;printf "%s\n" "$rc" > "$base/ALL_STATUS"' EXIT
[[ $(id -u) == 1000 ]]
id > "$out/identity.txt"
printf 'phase\texit\n' > "$out/RESULTS.tsv"
phase(){ local name=$1;shift;local rc=0; /usr/bin/time -v "$@" > "$out/$name.stdout" 2> "$out/$name.stderr" || rc=$?;printf '%s\t%s\n' "$name" "$rc" >> "$out/RESULTS.tsv";return "$rc"; }
printf '%s\n' ebb906a9ce522fe7505168772717619b3cf7ebf9 > "$out/SOURCE_HEAD.txt"
printf '%s  %s\n' 81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90 "$base/tools/node" > "$out/NODE.sha256"
sha256sum -c "$out/NODE.sha256" > "$out/NODE.initial.verify"
node --version > "$out/NODE.version"
ldd "$base/tools/node" > "$out/NODE.ldd.txt"
awk '$2 == "=>" && $3 ~ /^\// {print $3} $1 ~ /^\// {print $1}' "$out/NODE.ldd.txt" | sort -u | xargs sha256sum > "$out/NODE_RUNTIME.sha256"
sha256sum -c "$out/NODE_RUNTIME.sha256" > "$out/NODE_RUNTIME.initial.verify"
find self-hosted stdlib scripts tests -type f -print0 | sort -z | xargs -0 sha256sum > "$out/IMMUTABLE_SOURCE.sha256"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$out/INITIAL_SOURCE.sha256"
printf '%s  %s\n' 702b4bf38036b11d61929a6135af5432de75859ff656361aa95c0dd2bd80b9a5 self-hosted/compiler/lean_single.sio 8956946def36004d11ec4eca0d20c75c1e7d3d0b17ee0f0a1fdda9cd6ec0e4cc bin/souc-lean-single-x86_64 > "$out/EXPECTED_INPUTS.sha256"
sha256sum -c "$out/EXPECTED_INPUTS.sha256" > "$out/EXPECTED_INPUTS.initial.verify"
cp bin/souc-lean-single-x86_64 "$out/g0.elf"
cp bin/souc-lean-single-x86_64.SeedReceipt.json "$out/OLD_SeedReceipt.json"
phase metadata-before node scripts/ci/seed_receipt_metadata_test.mjs
rc=0;phase canonical-before bash scripts/ci/canonical_compiler_gate.sh || rc=$?
[[ $rc == 1 ]]
grep -Fq 'committed md5    = bb26fcd2aebf6e0170b6d249db3cb149' "$out/canonical-before.stdout"
grep -Fq 'self-compile md5 = 358cfd5e688c73145bd5967cf48d9335' "$out/canonical-before.stdout"
record_gen(){ printf 'g%s\t%s\t%s\t%s\n' "$1" "$(md5sum "$2" | cut -d' ' -f1)" "$(sha256sum "$2" | cut -d' ' -f1)" "$2" >> "$out/generations.tsv"; }
record_gen 0 "$out/g0.elf"
for i in 1 2 3;do
 prior=$((i-1));phase "derive-g$i" timeout 300 "$out/g$prior.elf" self-hosted/compiler/lean_single.sio "$out/g$i.elf"
 [[ -s "$out/g$i.elf" ]];chmod +x "$out/g$i.elf";record_gen "$i" "$out/g$i.elf"
done
cmp "$out/g2.elf" "$out/g3.elf" > "$out/M1-g2-g3.cmp"
retained=/scratch/sounio-stdlib-inference-scale-20261024/SIO172private/after04/host_gate/artifacts/souc-stage2
cmp "$out/g2.elf" "$retained" > "$out/RETAINED_STAGE2.cmp"
sha256sum "$retained" /scratch/sounio-stdlib-inference-scale-20261024/SIO172private/after04/source/self-hosted/compiler/lean_single.sio > "$out/RETAINED_IDENTITIES.sha256"
printf '%s  %s\n' 13003a8b9b1bf4bfc64ad8d13eb0795d722888fabef5bbb2913b4f7b83bb454b "$out/g2.elf" > "$out/EXPECTED_OUTPUT.sha256"
sha256sum -c "$out/EXPECTED_OUTPUT.sha256" > "$out/EXPECTED_OUTPUT.verify"
cp --remove-destination "$out/g2.elf" bin/souc-lean-single-x86_64
chmod +x bin/souc-lean-single-x86_64
emit_receipt(){ node scripts/dev/write_seed_receipt.mjs --out-dir "$out/receipt" --gens-tsv "$out/generations.tsv" --source self-hosted/compiler/lean_single.sio --input-seed "$out/g0.elf" --output-seed bin/souc-lean-single-x86_64 --settle-k 2 --placement slurm --slurm-partition cpu-ops --slurm-time 00:30:00 --git-commit ebb906a9ce522fe7505168772717619b3cf7ebf9 --git-branch devpass/SIO-172-bootstrap-private-borrow --canonical-gate "$1" --verify-lean-seed "$2";cp "$out/receipt/SeedReceipt.latest.json" bin/souc-lean-single-x86_64.SeedReceipt.json; }
emit_receipt skip skip > "$out/receipt-initial.stdout"
export SOUNIO_SEED_BOOTSTRAP="$out/g0.elf"
phase canonical-after bash scripts/ci/canonical_compiler_gate.sh
phase verify-after bash scripts/ci/verify_lean_seed.sh
emit_receipt pass pass > "$out/receipt-final.stdout"
phase canonical-final bash scripts/ci/canonical_compiler_gate.sh
phase verify-final bash scripts/ci/verify_lean_seed.sh
phase metadata-final node scripts/ci/seed_receipt_metadata_test.mjs
SOUNIO_PRIVATE_COMPILER="$PWD/bin/souc-lean-single-x86_64" SOUNIO_PRIVATE_OUTPUT="$base/privacy" SOUNIO_PRIVATE_EXTRA172_ROOT=/scratch/sounio-stdlib-inference-scale-20261024/SIO172private/before02/extra172 phase privacy bash scripts/ci/private_field_borrow_gate.sh
sha256sum -c "$out/IMMUTABLE_SOURCE.sha256" > "$out/IMMUTABLE_SOURCE.final.verify"
sha256sum -c "$out/NODE.sha256" > "$out/NODE.final.verify"
sha256sum -c "$out/NODE_RUNTIME.sha256" > "$out/NODE_RUNTIME.final.verify"
sha256sum -c "$out/RETAINED_IDENTITIES.sha256" > "$out/RETAINED_IDENTITIES.final.verify"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$out/FINAL_SOURCE.sha256"
sha256sum bin/souc-lean-single-x86_64 bin/souc-lean-single-x86_64.SeedReceipt.json > "$out/INSTALLED.sha256"
md5sum bin/souc-lean-single-x86_64 > "$out/INSTALLED.md5"
printf '%s\n' SIO226_SEED_REFRESH_CANONICAL_PRIVACY_PASS | tee "$out/FINAL.txt"
