#!/bin/bash
#SBATCH --job-name=SIO170-ids05
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids05/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids05/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids05/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C SOUNIO_STDLIB_PATH="$PWD/stdlib"
ulimit -s 524288
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids05
out="$r/artifacts"
raw=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
seed=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64
trap 'printf "%s\n" "$?" > "$out/STATUS"' EXIT
printf 'phase\texit_status\n' > "$out/RESULTS.tsv"
step(){ local name=$1;shift;local rc=0;"$@" > "$out/$name.stdout" 2> "$out/$name.stderr" || rc=$?;printf '%s\t%s\n' "$name" "$rc" >> "$out/RESULTS.tsv";return "$rc"; }
sha256sum "$raw" "$seed" > "$out/COMPILERS.sha256"
sha256sum stdlib/genomics/count_identities.sio stdlib/collections/integer_buffer.sio tests/stdlib/genomics_counts/ids_main.sio tests/reference/genomics_id_reference.cpp > "$out/INPUTS.sha256"
step check "$raw" check tests/stdlib/genomics_counts/ids_main.sio
step compile "$raw" compile tests/stdlib/genomics_counts/ids_main.sio -o "$out/ids.elf"
chmod +x "$out/ids.elf"
step cpp-build g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/genomics_id_reference.cpp -o "$out/reference"
step native /usr/bin/time -f 'elapsed_seconds=%e\nmax_rss_kib=%M\nexit_code=%x' -o "$out/native.resource" timeout 180 "$out/ids.elf"
step concordance "$out/reference" "$out/native.stdout"
step seed-compile "$seed" tests/stdlib/genomics_counts/ids_main.sio "$out/ids-seed.elf"
chmod +x "$out/ids-seed.elf"
step seed-native timeout 180 "$out/ids-seed.elf"
step seed-concordance "$out/reference" "$out/seed-native.stdout"
awk '$1=="ID_ROW"&&$2==1&&$3==0{$4=99} {print}' "$out/native.stdout" > "$out/group-mutant.input.stdout"
! cmp -s "$out/group-mutant.input.stdout" "$out/native.stdout"
rc=0;step group-mutant "$out/reference" "$out/group-mutant.input.stdout" || rc=$?
[[ $rc == 8 ]];grep -Fxq 'identity row/group/order 1 0' "$out/group-mutant.stderr"
grep -v '^COUNT_IDENTITIES_PASS$' "$out/native.stdout" > "$out/completion-mutant.input.stdout"
rc=0;step completion-mutant "$out/reference" "$out/completion-mutant.input.stdout" || rc=$?
[[ $rc == 9 ]];grep -Fxq 'identity completion' "$out/completion-mutant.stderr"
step inputs-unchanged sha256sum -c "$out/INPUTS.sha256"
