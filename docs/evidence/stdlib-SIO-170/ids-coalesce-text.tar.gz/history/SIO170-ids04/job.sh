#!/bin/bash
#SBATCH --job-name=SIO170-ids04
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:05:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids04/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids04/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids04/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C SOUNIO_STDLIB_PATH="$PWD/stdlib"
ulimit -s 524288
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids04
trap 'printf "%s\n" "$?" > "$r/artifacts/STATUS"' EXIT
/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64 tests/stdlib/genomics_counts/ids_main.sio "$r/artifacts/seed.elf" > "$r/artifacts/compile.stdout" 2> "$r/artifacts/compile.stderr"
chmod +x "$r/artifacts/seed.elf"
"$r/artifacts/seed.elf" > "$r/artifacts/native.stdout" 2> "$r/artifacts/native.stderr"
