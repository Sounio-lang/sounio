#!/bin/bash
#SBATCH --job-name=SIO170-ids01
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:10:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids01/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids01/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C SOUNIO_STDLIB_PATH="$PWD/stdlib"
ulimit -s 524288
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-ids01
raw=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
trap 'printf "%s\n" "$?" > "$r/artifacts/STATUS"' EXIT
"$raw" check tests/stdlib/genomics_counts/ids_main.sio > "$r/artifacts/check.stdout" 2> "$r/artifacts/check.stderr"
