record() {
    printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$out/RESULTS.tsv"
    [[ "$3" == 0 ]] || fail=1
}
