# Dynamic named counts, byte-exact identities/joins and validated CSR.
# Child receipt separates bootstrap numerical support from canonical privacy.
rc=0
MADAROS_RAW_BIN="$MADAROS_RAW_BIN" SEED_RAW_BIN="${SEED_RAW_BIN:-$repo/bin/souc-lean-single-x86_64}" timeout 1200 bash scripts/stdlib/genomics_count_identity_gate.sh "$out/genomics-count-identities" > "$out/genomics-count-identities.gate.stdout" 2> "$out/genomics-count-identities.gate.stderr" || rc=$?
record focused-gate genomics-count-identities "$rc"
