# Exhausted NB2 qualification campaign

Campaign job 17048 ended with process status 124 after exhausting the round allocation of 85,500 seconds. The preceding 900-second allocation is separate; no pilot or historical observations are pooled here. Frozen source: 6ffc1a5bd8eaebeef2d15ccced830bfbc832a648. Compiler SHA256: d74fbebe0ff442e8c77bec024d6d92325b83a98d3f1487caa1db59ef171a41e6.

Every original case status, native row and seed schedule is reconciled below, including successful cases from the unfinished batch. Generated but never executed cases and entirely ungenerated cases remain not started. Process failures are distinct from completed model refusals.

| n | alpha | planned | generated | attempted | completed | available | model unavailable | process failures | not started | rejected/available | conditional Wilson 95% |
|---|---|---|---|---|---|---|---|---|---|---|---|
|16|0|128|48|48|48|48|0|0|80|2/48|0.0115018935 to 0.139756559|
|16|.25|128|48|48|48|48|0|0|80|4/48|0.0328837568 to 0.195533018|
|16|1|128|48|48|48|48|0|0|80|5/48|0.045321719 to 0.221674217|
|64|0|128|48|48|48|48|0|0|80|4/48|0.0328837568 to 0.195533018|
|64|.25|128|48|48|48|48|0|0|80|5/48|0.045321719 to 0.221674217|
|64|1|128|48|48|48|48|0|0|80|1/48|0.00368711098 to 0.10899218|
|256|0|128|48|48|48|47|1|0|80|1/47|0.00376576804 to 0.11112981|
|256|.25|128|48|39|38|38|0|1|89|2/38|0.0145542081 to 0.172854621|
|256|1|128|32|32|32|32|0|0|96|1/32|0.00553786016 to 0.157442638|

Conditional fractions and Wilson intervals use available completed fits only, at the prespecified plus-one bootstrap p <= 0.05 rule. They are descriptive, approximate Monte Carlo summaries under an independent Bernoulli model; optional stopping, runtime selection, shared RNG streams, and model availability can invalidate a nominal coverage interpretation. The plug-in MC standard error is zero at zero observed rejections; the Wilson upper endpoint remains positive. Rates are never pooled across cells.

The planned-family bounds in cells.tsv place every unavailable, failed or unattempted result anywhere in [0,1]. They are deterministic missing-outcome bounds, not confidence intervals. No full target of 128 per cell was attained. No calibration_assessed flag is changed. No claim of universal calibration or DESeq2 equivalence follows.

Work counters sum observed CAL_WORK values from completed rows only. CAL_TRACE sums are explicitly recorded prefixes; partial traces are not reconstructed from replicate counts or RNG. cases.tsv lists all planned identities and scheduled seeds, distinguishes generated data from not-started data, and includes final RNG words only where actually emitted.
