# DP5(4) FSAL, quartic dense output and event contracts: actual native + C++.
# Optional DP54_SEED_BIN selects a second independently receipted engine.
rc=0
DP54_GATE_OUTPUT="$out/dp54-focused" MADAROS_RAW_BIN="$MADAROS_RAW_BIN" \
 timeout 900 bash scripts/stdlib/dp54_dense_events_gate.sh > "$out/dp54-focused.stdout" 2> "$out/dp54-focused.stderr" || rc=$?
record focused-gate dp54-dense-events "$rc"

