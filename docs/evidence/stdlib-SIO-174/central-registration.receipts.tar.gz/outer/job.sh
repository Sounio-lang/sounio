#!/bin/bash
#SBATCH --job-name=SIO174-central
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO174-central01/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO174-central01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO174-central01/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
export SOUC_BIN="$MADAROS_RAW_BIN"
export DP54_SEED_BIN=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64
out=/scratch/sounio-stdlib-inference-scale-20261024/SIO174-central01/artifacts
mkdir "$out"
fail=0
printf 'kind\tsource\texit_status\n' > "$out/RESULTS.tsv"
sed -n '/^record() {/,/^}/p' scripts/stdlib/deep_science_gate.sh > "$out/record.exact.sh"
sed -n '/^# DP5(4) FSAL/,/^$/p' scripts/stdlib/deep_science_gate.sh > "$out/block.exact.sh"
[[ -s "$out/block.exact.sh" && -s "$out/record.exact.sh" ]]
sha256sum scripts/stdlib/deep_science_gate.sh "$MADAROS_RAW_BIN" "$DP54_SEED_BIN" > "$out/IDENTITIES.sha256"
source "$out/record.exact.sh"
source "$out/block.exact.sh"
printf '%s\n' "$fail" > "$out/STATUS"
exit "$fail"
