#!/bin/bash
# Static classification requires explicit readelf program-header evidence.
set -euo pipefail
out=$1;elf=$2
[[ -f $elf && -x $elf ]]
readelf -h "$elf" > "$out.HEADER.txt"
readelf -l "$elf" > "$out.PROGRAM_HEADERS.txt"
readelf -d "$elf" > "$out.DYNAMIC.txt"
sha256sum "$elf" > "$out"
if ! grep -Eq '^[[:space:]]*(INTERP|DYNAMIC)[[:space:]]' "$out.PROGRAM_HEADERS.txt";then
 printf 'STATIC_ELF_NO_PT_INTERP_OR_PT_DYNAMIC\n' > "$out.RUNTIME_KIND.txt"
else
 printf 'DYNAMIC_ELF_LDD_CLOSURE_REQUIRED\n' > "$out.RUNTIME_KIND.txt"
 deps=$(ldd "$elf" 2>&1)
 [[ $deps != *'not found'* ]]
 printf '%s\n' "$deps" > "$out.LDD.txt"
 printf '%s\n' "$deps" | awk '/=> \// {print $3} /^[[:space:]]*\// {print $1}' | sort -u | xargs -r sha256sum >> "$out"
fi
[[ -s $out ]]
