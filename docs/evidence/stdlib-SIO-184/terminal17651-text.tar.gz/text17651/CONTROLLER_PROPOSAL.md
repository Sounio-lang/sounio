# SIO184 Romberg focused qualification proposal — not submitted

Workspace packet: /workspace/.tmp/SIO184-analysis-wave01/packet01
Durable host: /tmp/SIO184-analysis-wave01 (not created yet)
Fresh worker: /scratch/sounio-stdlib-inference-scale-20261024/SIO184-analysis-wave01 (not created yet)
Host script: /workspace/.tmp/SIO184-analysis-wave01/host_controller.sh
Worker: packet01/worker.sbatch
Seals: SEALS.txt, TRANSFER.sha256

Root-owned four production files remain unchanged by this lane. Source variants have2398 exact path/type/mode/link/SHA entries each; only lib.sio's last_change preservation and consumer analysis::lib import differ. New regression is identical in both variants. Reference C++ SHA f42e09d296266e60644aec5b0413c6922232766e55f4c39dd6bb2913e993a286 equals the root production reference. No numeric evaluation occurred in preparation.

Request: UID1000, cpu-ops on cpuops-t560-proxmox,1CPU/4GiB/15min, exportNIL, stack524288, coredumps disabled. One780-second body with10-second kill bound reserves footer acquisition time. All C++ build/generation, Sounio checks/builds/native are inside Slurm. Timeout/failure stays failure. Original before consumer expected1 in both engines stays strict; unexpected seed acceptance is a failure, never relabeled. Before regression2 and generated201 are retained original counterexamples, after0 and C++16 strict1e-10 comparisons. No full corpus or old campaign.

Native kubectl transport is the previously proven t560 direct worker route with stdin -i for streaming. Controller creates an exclusive ATTEMPT before preflight/staging/submission and has exactly one sbatch call. Any uncertain submission requires reconciliation and must never be retried. It captures admission, terminal sacct and original outputs including retained ELFs. Git custody will be compact text only.

Preflight is repeated immediately before submission: exactUID, effective cgroup memory headroom through actual /proc/self/cgroup ancestry intersected with host MemAvailable >=20GiB, scratch >=20GiB and <=7 existing sounio jobs. Cgroup root alone exposes no memory.max, so the helper follows the actual namespace path and records each ancestor. Actual readonly preflight at10:18:16Z: effective95780106240B, scratch87085112KiB,3 existing jobs. This is preparation evidence, not future admission permission.

Metadata footers verify all original bytes, source path/type/mode/link census (addition/deletion included), packet names and hashes, all retained native manifests, reference/runtime, Node/raw/current seed and paired SeedReceipt. Raw/seed static status requires readelf showing no PT_INTERP/PT_DYNAMIC; dynamic runtimes must have a complete successful ldd closure. Node/CXX/GCC helpers/binutils and loaded libraries remain strict. Python deny125 probes are separated from zero-attempt runtime logs.

After root approves exact seals: mirror packet.tar, host_controller.sh, preflight.sh and TRANSFER.sha256 to a fresh /tmp/SIO184-analysis-wave01 on t560, verify TRANSFER, and launch a durable tmux session running host_controller.sh once. No source/code changes, staging or sbatch have occurred on the worker. Do not execute before root authorization.
