#!/bin/bash
set -euo pipefail
P=$(cd "$(dirname "$0")" && pwd)
OUT=$1
[[ $(id -u) == 1000 && -n $SLURM_JOB_ID && ! -e $OUT ]] || exit 78
mkdir "$OUT";mkdir "$OUT/tmp" "$OUT/cache"
export TMPDIR=$OUT/tmp LC_ALL=C LANG=C
N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node
RAW=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
export MADAROS_RAW_BIN=$RAW SOUNIO_MADAROS_NOCACHE=1 SOUNIO_MADAROS_CACHE_READONLY=1 SOUNIO_MADAROS_CACHE=$OUT/cache SOUNIO_BUILD_LOCK=$OUT/build.lock
unset SOUNIO_SOUC_BIN SOUNIO_MADAROS_BIN SOUNIO_REQUIRE_COMMITTED_MADAROS SOUC_NATIVE_BIN
ulimit -s 524288;ulimit -c 0
printf '%s  %s\n' a292cc263f3734b1ad6f17a2e6179b8a7874ef3e76d8f5fdfea6859290baf5d3 "$RAW" 81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90 "$N" 06c90e5b408e3f42f7dbf5c0ef34817333381a770a0734dae4493e36a496c939 "$P/before/bin/souc-lean-single-x86_64" 06c90e5b408e3f42f7dbf5c0ef34817333381a770a0734dae4493e36a496c939 "$P/after/bin/souc-lean-single-x86_64" > "$OUT/PINS.sha256"
for V in before after;do
 printf '%s  %s\n' cd9b24558998696183243ebaabb01eb0bfef80a6c519e1504912ced1caa7ebec "$P/$V/bin/souc-lean-single-x86_64.SeedReceipt.json" >> "$OUT/PINS.sha256"
done
sha256sum -c "$OUT/PINS.sha256" > "$OUT/PINS.initial.verify"
for V in before after;do (cd "$P/$V";sha256sum -c "$P/$V.sha256") > "$OUT/$V.initial.verify";done
bash "$P/install_guards.sh" "$OUT" "$P" "$OUT" "$N" > "$OUT/guards.install.stdout" 2> "$OUT/guards.install.stderr"
export PATH=$OUT/path:/usr/bin:/bin E2E_PYTHON_DENY_LOG=$OUT/python.runtime.nul
node "$P/validate_guard_controls.mjs" "$OUT" > "$OUT/guard.controls.stdout" 2> "$OUT/guard.controls.stderr"
bash "$P/verify_guards.sh" "$OUT" "$P" "$OUT" > "$OUT/guards.initial.verify"
bash "$P/toolchain_manifest.sh" "$OUT/TOOLS.before.sha256"
bash "$P/compiler_runtime_manifest.sh" "$OUT/RAW_RUNTIME.before.sha256" "$RAW"
bash "$P/compiler_runtime_manifest.sh" "$OUT/SEED_RUNTIME.before.sha256" "$P/before/bin/souc-lean-single-x86_64"
sha256sum "$P/guard_python.sh" "$P/install_guards.sh" "$P/verify_guards.sh" >> "$OUT/TOOLS.before.sha256"
fail=0
printf 'variant\tengine\tcase\tphase\trc\texpected\n' > "$OUT/RESULTS.tsv"
capture() {
 local key=$1 expectation=$2 cap=$3;shift 3
 local rc=0
 printf '%q ' "$@" > "$OUT/$key.command";printf '\n' >> "$OUT/$key.command"
 date -u +%FT%TZ > "$OUT/$key.started"
 /usr/bin/time -v -o "$OUT/$key.resource" timeout "$cap" "$@" > "$OUT/$key.stdout" 2> "$OUT/$key.stderr" || rc=$?
 date -u +%FT%TZ > "$OUT/$key.finished";echo "$rc" > "$OUT/$key.status"
 printf '%s\t%s\t%s\n' "$(printf '%s' "$key" | tr '.' '\t')" "$rc" "$expectation" >> "$OUT/RESULTS.tsv"
 [[ $rc == "$expectation" ]] || fail=1
 if [[ $expectation == 0 && ( $key == *.check || $key == *.compile ) ]] && grep -Eq '^[[:space:]]*error:|^[[:space:]]*error\[E' "$OUT/$key.stdout" "$OUT/$key.stderr";then
  echo 'status-zero-coded-error' > "$OUT/$key.INCOMPLETE";fail=1
 fi
 return 0
}
finish() {
 local rc=$?;trap - EXIT;set +e
 [[ $rc == 0 ]] || fail=1
 for V in before after;do (cd "$P/$V";sha256sum -c "$P/$V.sha256") > "$OUT/$V.final.verify" 2>&1;[[ $? == 0 ]] || fail=1;done
 sha256sum -c "$OUT/PINS.sha256" > "$OUT/PINS.final.verify" 2>&1;[[ $? == 0 ]] || fail=1
 sha256sum -c "$OUT/TOOLS.before.sha256" > "$OUT/TOOLS.final.verify" 2>&1;[[ $? == 0 ]] || fail=1
 if [[ -s $OUT/REFERENCE.before.sha256 ]];then sha256sum -c "$OUT/REFERENCE.before.sha256" > "$OUT/REFERENCE.final.verify" 2>&1;[[ $? == 0 ]] || fail=1;else fail=1;fi
 bash "$P/verify_guards.sh" "$OUT" "$P" "$OUT" > "$OUT/guards.final.verify" 2>&1;[[ $? == 0 ]] || fail=1
 [[ -f $OUT/python.runtime.nul && ! -s $OUT/python.runtime.nul ]] || fail=1
 (cd "$P";sha256sum -c FILES.sha256) > "$OUT/PACKET.final.verify" 2>&1;[[ $? == 0 ]] || fail=1
 find "$OUT" -type f -name '*.elf' -print0 | sort -z | xargs -0 -r sha256sum > "$OUT/ELFS.sha256"
 for manifest in "$OUT"/*.ELF.before.sha256 "$OUT"/RAW_RUNTIME.before.sha256 "$OUT"/SEED_RUNTIME.before.sha256;do
  [[ -f $manifest ]] || { fail=1;continue; }
  sha256sum -c "$manifest" > "$manifest.terminal.verify" 2>&1;[[ $? == 0 ]] || fail=1
 done
 echo "$fail" > "$OUT/STATUS";exit "$fail"
}
trap finish EXIT
id > "$OUT/IDENTITY.txt";scontrol show job "$SLURM_JOB_ID" > "$OUT/SLURM.txt"
capture reference.CXX.generator.compile 0 60 g++ -std=c++23 -O2 -Wall -Wextra "$P/analysis_romberg_reference.cpp" -o "$OUT/reference.elf"
[[ -x $OUT/reference.elf ]] || exit 1
bash "$P/elf_runtime_manifest.sh" "$OUT/REFERENCE.before.sha256" "$OUT/reference.elf"
capture reference.CXX.generator.generate 0 10 "$OUT/reference.elf" --generate
capture reference.CXX.generator.table 0 10 "$OUT/reference.elf" --table
cp "$OUT/reference.CXX.generator.generate.stdout" "$OUT/generated_romberg.sio"
sha256sum "$OUT/generated_romberg.sio" > "$OUT/GENERATED.before.sha256"
for V in before after;do
 cd "$P/$V"
 export SOUNIO_STDLIB_PATH=$PWD/stdlib
 for E in madaros lean_single;do
  export SOUNIO_SOUC_ENGINE=$E
  for C in consumer error generated library;do
   src=tests/stdlib/analysis/test_analysis.sio
   [[ $C != error ]] || src=tests/stdlib/analysis/test_romberg_error_estimate.sio
   [[ $C != generated ]] || src=$OUT/generated_romberg.sio
   [[ $C != library ]] || src=stdlib/analysis/lib.sio
   expected=0;[[ $V != before || $C != consumer ]] || expected=1
   key=$V.$E.$C
   capture "$key.check" "$expected" 45 bash bin/souc check "$src"
   [[ $C != library ]] || continue
   elf=$OUT/$key.elf
   capture "$key.compile" "$expected" 45 bash bin/souc compile "$src" -o "$elf"
   if [[ $expected == 0 && -s $elf ]];then
    chmod +x "$elf";sha256sum "$elf" > "$OUT/$key.ELF.before.sha256"
    native_expected=0
    [[ $V != before || $C != error ]] || native_expected=2
    [[ $V != before || $C != generated ]] || native_expected=201
    capture "$key.native" "$native_expected" 10 "$elf"
    if [[ $V == after && $C == error ]];then grep -Fq ANALYSIS_ROMBERG_ERROR_ESTIMATE_OK "$OUT/$key.native.stdout" || fail=1;fi
    if [[ $V == after && $C == generated ]];then grep -Fq ANALYSIS_CPP23_ROMBERG_CONCORDANCE_OK "$OUT/$key.native.stdout" || fail=1;fi
    sha256sum -c "$OUT/$key.ELF.before.sha256" > "$OUT/$key.ELF.final.verify" || fail=1
   elif [[ $expected == 1 ]];then [[ ! -s $elf ]] || fail=1
   else fail=1
   fi
  done
 done
done
sha256sum -c "$OUT/GENERATED.before.sha256" > "$OUT/GENERATED.final.verify" || fail=1
exit "$fail"
