#!/bin/bash
set -euo pipefail
[[ $(id -u) == 1000 ]]
id;date -u +%FT%TZ;df -Pk /scratch
available=$(awk '/MemAvailable:/{print $2*1024}' /proc/meminfo | awk '{printf "%.0f",$1}')
[[ $available =~ ^[0-9]+$ ]]
printf "host_mem_available_bytes=%s\n" "$available"
effective=$available
cg=$(awk -F: '$1=="0"{print $3}' /proc/self/cgroup)
[[ $cg == /* && $cg != *..* ]]
q=/sys/fs/cgroup$cg;seen=0
while [[ $q == /sys/fs/cgroup* ]];do
 if [[ -r $q/memory.max && -r $q/memory.current ]];then
  max=$(cat "$q/memory.max");used=$(cat "$q/memory.current");printf 'cgroup=%s max=%s current=%s\n' "$q" "$max" "$used";seen=$((seen+1))
  if [[ $max != max ]];then [[ $max =~ ^[0-9]+$ && $used =~ ^[0-9]+$ ]];headroom=$((max-used));((headroom>=0));((headroom>=effective)) || effective=$headroom;fi
 fi
 [[ $q != /sys/fs/cgroup ]] || break
 q=$(dirname "$q")
done
((seen>0));printf 'effective_memory_headroom_bytes=%s\n' "$effective"
((effective>=21474836480))
free_kb=$(df -Pk /scratch | awk 'NR==2{print $4}');((free_kb>=20971520))
queue=$(squeue -u sounio -h -o '%i %j %T');printf '%s\n' "$queue"
count=$(printf '%s\n' "$queue" | awk 'NF{n++}END{print n+0}');printf 'existing_jobs=%s\n' "$count";((count<=7))
