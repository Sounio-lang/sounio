#!/bin/bash
# Run only in durable t560 tmux after root approves this exact packet/controller.
set -euo pipefail
H=/tmp/SIO184-analysis-wave01
B=/scratch/sounio-stdlib-inference-scale-20261024/SIO184-analysis-wave01
R=(kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
RI=(kubectl -n slurm-pilot exec -i slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio --)
[[ ! -e $H/ATTEMPT ]];mkdir "$H/ATTEMPT"
date -u +%FT%TZ > "$H/ATTEMPT/STARTED_AT"
exec > >(tee "$H/ATTEMPT/stdout") 2> >(tee "$H/ATTEMPT/stderr" >&2)
trap 'echo $? > "$H/ATTEMPT/CONTROLLER_STATUS"' EXIT
(cd "$H";sha256sum -c TRANSFER.sha256)
"${RI[@]}" bash -s < "$H/preflight.sh" > "$H/ATTEMPT/preflight.txt"
"${R[@]}" bash -c 'set -euo pipefail;[[ ! -e $1 ]];mkdir "$1"' prepare "$B"
"${RI[@]}" bash -c 'set -euo pipefail;cd "$1";tar -xf -' stage "$B" < "$H/packet.tar"
"${R[@]}" bash -c 'set -euo pipefail;cd "$1/packet01";sha256sum -c FILES.sha256;N=/scratch/sounio-stdlib-inference-scale-20261024/SIO226-seed01/tools/node;echo "81925c0995b5c1427b5d538e6a90ca2fdc4daffb786b09af749beaf7369d4e90  $N" | sha256sum -c -;for V in before after;do "$N" source_census.mjs verify "$PWD/$V" "$PWD/$V.census.json";done' verify "$B" > "$H/ATTEMPT/stage.verify"
"${RI[@]}" bash -s < "$H/preflight.sh" > "$H/ATTEMPT/presubmit.preflight.txt"
date -u +%FT%TZ > "$H/ATTEMPT/SBATCH_STARTED_AT"
# One call. Any uncertainty is reconciled from this attempt; never retry submission.
"${R[@]}" sbatch --parsable "$B/packet01/worker.sbatch" > "$H/ATTEMPT/sbatch.stdout" 2> "$H/ATTEMPT/sbatch.stderr"
job=$(cat "$H/ATTEMPT/sbatch.stdout");[[ $job =~ ^[0-9]+$ ]];echo "$job" > "$H/JOB_ID"
"${R[@]}" scontrol show job "$job" > "$H/ATTEMPT/admission.txt"
printf 'SUBMITTED_ONCE_JOB=%s\n' "$job"
while :;do
 "${R[@]}" sacct -j "$job" -n -P --format=JobID,State,ExitCode,Elapsed,AllocCPUS,ReqMem > "$H/ATTEMPT/sacct.latest"
 state=$(awk -F'|' -v j="$job" '$1==j{print $2}' "$H/ATTEMPT/sacct.latest")
 case "$state" in COMPLETED|FAILED|CANCELLED*|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL|PREEMPTED)break;;esac
 sleep 15
done
cp "$H/ATTEMPT/sacct.latest" "$H/ATTEMPT/sacct.terminal"
"${RI[@]}" bash -c 'set -euo pipefail;cd "$1";tar -czf - controller-results results slurm-*.out slurm-*.err' acquire "$B" > "$H/terminal-original.tar.gz"
sha256sum "$H/terminal-original.tar.gz" > "$H/terminal-original.tar.gz.sha256"
# Original source packet and all ELFs remain on worker. Acquisition includes them;
# compact Git custody is prepared separately and excludes binary source/ELFs.
