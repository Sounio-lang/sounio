bash bin/souc check tests/stdlib/analysis/test_analysis.sio 
