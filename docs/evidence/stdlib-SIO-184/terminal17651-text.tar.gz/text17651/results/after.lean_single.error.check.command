bash bin/souc check tests/stdlib/analysis/test_romberg_error_estimate.sio 
