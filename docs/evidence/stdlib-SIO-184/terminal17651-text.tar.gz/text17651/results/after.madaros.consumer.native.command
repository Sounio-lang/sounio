/scratch/sounio-stdlib-inference-scale-20261024/SIO184-analysis-wave01/results/after.madaros.consumer.elf 
