bash bin/souc check stdlib/analysis/lib.sio 
