bash bin/souc compile tests/stdlib/analysis/test_romberg_error_estimate.sio -o /scratch/sounio-stdlib-inference-scale-20261024/SIO184-analysis-wave01/results/after.lean_single.error.elf 
