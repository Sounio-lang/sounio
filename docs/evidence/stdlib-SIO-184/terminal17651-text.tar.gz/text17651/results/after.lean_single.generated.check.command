bash bin/souc check /scratch/sounio-stdlib-inference-scale-20261024/SIO184-analysis-wave01/results/generated_romberg.sio 
