# Biostatistics validation — `stdlib/medical/survival` & `stdlib/stats/clinical`

**Date:** 2026-06-18 · **Branch:** `metrics/fregni-profile` · **Reference data:** Freireich
et al. (1963) 6-mercaptopurine leukemia trial — the canonical survival-analysis dataset,
with textbook-published answers (log-rank χ² = 16.79, p = 4.2×10⁻⁵; KM medians 23 vs 8
weeks; Cox HR placebo/6-MP ≈ 4.5).

## How this was validated (and its honest limit)

The survival module **cannot currently be executed in this checkout on either engine**:
- default `native_v2` engine → `survival.sio` fails type-check (pre-existing `i32`/`i64`
  assignment errors + `E137`); even the existing `//@ run-pass` test
  `tests/stdlib/medical/test_survival_e2e.sio` **does not pass on the default engine**;
- `lean_single` engine → cannot link a multi-module `main` (returns `error: no main`),
  confirmed even on the known-good `demo/fregni/fregni_demo.sio`.

So validation was done by a **faithful line-by-line port** of the actual `.sio` algorithms
to Python (`tests/validation/survival_freireich_reference.py`), run on the Freireich data and
cross-checked with SciPy. The corrected log-rank below is a **proposed patch**: it mirrors the
port-validated algorithm, but it was **NOT applied to the live stdlib file** because it cannot
be compiler-verified here — `native_v2` cannot type-check `survival.sio` at all (79 pre-existing
errors; the patch adds 6 more of the same `E002`/`E012` families) and `lean_single` cannot run
it. Shipping an unverifiable stdlib edit would overstate; the patch lives in this doc instead.
A runnable Sounio harness (`tests/validation/survival_freireich.sio`) and the `pub` test
wrappers it needs are included here as **PENDING** artifacts for when the engine path is
repaired and the patch is verified.

## Findings

| Method | Result | Verdict |
|---|---|---|
| **Kaplan–Meier median** (product-limit) | medians = **23 / 8 weeks** (match published) | ✅ **CORRECT** |
| **KM Greenwood SE** | computed by the port; not checked vs a published SE table | ⚠️ **not separately validated** |
| **Log-rank (as shipped)** | χ² = **4.80**, p = `exp(−χ²/2)` = **0.091** | ❌ **WRONG** — see below |
| **Log-rank (corrected algorithm, proposed patch)** | χ² = **16.793**, p = **4.17×10⁻⁵** | ✅ **port-validated** (matches SciPy); not applied/compiled |
| **Sample size, two-sample t** (`power_analysis.sio`) | n = **63/group** (d=0.5, α=.05, power=.8) | ✅ **CORRECT to normal approx** (exact noncentral-t = 64; ~1 low) |
| **Cox PH** (Newton–Raphson) | not independently ported | ⚠️ **NOT VALIDATED here** |

### The log-rank bug (and the fix)

The shipped `log_rank_test` computed expected events from a **single baseline pooled split**:

```
E_A = n_A / (n_A + n_B) × total_events            // ignores risk sets & censoring over time
χ²  = (O_A − E_A)²/E_A + (O_B − E_B)²/E_B          // Pearson 2-cell, not (O−E)²/V
p   = exp(−χ²/2)                                   // this is the χ²₂ tail, not χ²₁
```

On the Freireich data this yields χ² = 4.80 and **p ≈ 0.091 — falsely declaring one of the
most famous *significant* results in clinical biostatistics NON-significant.** Three distinct
errors: (1) expected counts ignore the time-varying risk sets and censoring; (2) the variance
denominator is `E`, not the hypergeometric `V`; (3) `exp(−χ²/2)` is the survival function of
χ² with **2** df, not 1.

The corrected algorithm (**proposed patch — not applied to the live file**, see above) is the
proper **Mantel–Haenszel** test:

```
E1 = Σ_k d_k · n1_k / n_k
V  = Σ_k d_k · (n1_k/n_k)(n2_k/n_k)(n_k − d_k)/(n_k − 1)
χ² = (O1 − E1)² / V                                 ~ χ²₁
p  = erfc( sqrt(χ²/2) )                              // correct χ²₁ upper tail (A&S 7.1.26)
```

Port of the corrected algorithm → χ² = 16.793, E1 = 19.25, V = 6.26, p = 4.17×10⁻⁵ — matching
both the published value and `scipy.stats.chi2.sf`. The Sounio implementation of this patch
(a `surv_erfc` helper + a rewritten `log_rank_test`) is parked in
`tests/validation/survival_freireich_reference.py` as the validated reference; applying it to
`stdlib/medical/survival.sio` should wait until `survival.sio` type-checks on an engine, so the
edit can actually be compiled and run rather than asserted.

## Reproduce

```bash
python3 tests/validation/survival_freireich_reference.py   # ports actual .sio algorithms
python3 tests/validation/biostat_reference_values.py       # SciPy ground truth + power refs
```

## What to tell Fregni (honest framing)

> "The Kaplan–Meier median and the power/sample-size code are numerically correct against the
> canonical Freireich trial. We found a real bug: the log-rank test used a baseline pooled
> expectation and a wrong p-value formula, which would have called the Freireich result
> non-significant (p≈0.09 instead of 4×10⁻⁵); we derived and port-validated the corrected
> Mantel–Haenszel version (χ²=16.79), but have **not yet applied it to the stdlib**, because
> the module does not currently type-check/run on either engine — so the patch must be
> compile-verified first. Validation throughout is by faithful port, not in-repo execution; the
> Greenwood SE and Cox PH are not independently validated."
