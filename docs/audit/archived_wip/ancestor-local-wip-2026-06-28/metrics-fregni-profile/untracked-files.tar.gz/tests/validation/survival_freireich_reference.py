# Faithful transliteration of stdlib/medical/survival.sio algorithms,
# run on the Freireich 6-MP dataset. Goal: confirm what the Sounio code computes.
import numpy as np
from scipy.stats import chi2 as chi2dist
mp=[(6,1),(6,1),(6,1),(7,1),(10,1),(13,1),(16,1),(22,1),(23,1),
    (6,0),(9,0),(10,0),(11,0),(17,0),(19,0),(20,0),(25,0),(32,0),(32,0),(34,0),(35,0)]
pl=[(t,1) for t in [1,1,2,2,3,4,4,5,5,8,8,8,8,11,11,12,12,15,17,22,23]]

# --- PORT of km_estimate (product-limit + Greenwood), then km_median_survival ---
def km_port(data):
    d=sorted(data,key=lambda x:x[0]); n=len(d); n_risk=n; surv=1.0; g=0.0; pts=[]
    i=0
    while i<n:
        t=d[i][0]; de=0; ce=0; j=i
        while j<n and abs(d[j][0]-t)<1e-12:
            if d[j][1]==1: de+=1
            else: ce+=1
            j+=1
        if de>0:
            surv*= (1-de/n_risk)
            if n_risk>de: g+= de/(n_risk*(n_risk-de))
            pts.append((t,surv,surv*np.sqrt(g)))
        n_risk-=de+ce; i+=de+ce
    return pts
def km_median(pts):
    for t,s,se in pts:
        if s<=0.5: return t
    return -1
# --- PORT of CURRENT log_rank_test (the buggy pooled-baseline formula) ---
def logrank_current(ga,gb):
    na,nb=len(ga),len(gb); oa=sum(e for _,e in ga); ob=sum(e for _,e in gb)
    ea=na/(na+nb)*(oa+ob); eb=nb/(na+nb)*(oa+ob)
    chi=0.0
    if ea>1e-10: chi+=(oa-ea)**2/ea
    if eb>1e-10: chi+=(ob-eb)**2/eb
    p=np.exp(-chi/2.0)           # module's surv_exp(-chi/2)
    return chi,p
# --- PORT of the PROPOSED FIX (risk-set Mantel-Haenszel + erfc p) ---
def erfc_as(x):  # Abramowitz-Stegun 7.1.26
    t=1.0/(1.0+0.3275911*abs(x))
    y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592)*t*np.exp(-x*x)
    erf=y if x>=0 else -y
    return 1-erf
def logrank_fixed(ga,gb):
    times=sorted(set(t for t,e in ga+gb if e==1))
    O1=sum(e for _,e in ga); E1=0.0; V=0.0
    for t in times:
        n1=sum(1 for tt,_ in ga if tt>=t); n2=sum(1 for tt,_ in gb if tt>=t); n=n1+n2
        d=sum(1 for tt,e in ga+gb if tt==t and e==1)
        if n>1:
            E1+= d*n1/n
            V += d*(n1/n)*(n2/n)*((n-d)/(n-1))
    chi=(O1-E1)**2/V
    z=np.sqrt(chi); p=erfc_as(z/np.sqrt(2.0))   # P(chi2_1>chi)
    return chi,p,E1,V

pmp=km_port(mp); ppl=km_port(pl)
print(f"[KM port]      median 6-MP={km_median(pmp)} (pub 23), placebo={km_median(ppl)} (pub 8)  -> KM CORRECT")
c0,p0=logrank_current(mp,pl)
print(f"[CURRENT code] log-rank chi2={c0:.3f}, p=exp(-chi/2)={p0:.4f}   <-- WRONG (ref chi2=16.79, p=4.2e-5)")
print(f"               -> would report p={p0:.3f}: FALSELY NON-SIGNIFICANT on a landmark trial")
c1,p1,E1,V=logrank_fixed(mp,pl)
print(f"[FIXED algo]   log-rank chi2={c1:.3f} (ref 16.79), p(erfc)={p1:.3e} (ref 4.2e-5), E1={E1:.2f}, V={V:.2f}  -> MATCHES")
print(f"               scipy exact p for chi2={c1:.3f}: {chi2dist.sf(c1,1):.3e}")
