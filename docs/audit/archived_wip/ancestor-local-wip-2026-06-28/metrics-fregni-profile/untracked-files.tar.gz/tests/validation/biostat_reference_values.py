import numpy as np
from scipy.stats import chi2, norm
# Freireich 6-MP leukemia trial (canonical)
# treatment (6-MP): (time, event=1/censored=0)
mp = [(6,1),(6,1),(6,1),(7,1),(10,1),(13,1),(16,1),(22,1),(23,1),
      (6,0),(9,0),(10,0),(11,0),(17,0),(19,0),(20,0),(25,0),(32,0),(32,0),(34,0),(35,0)]
pl = [(t,1) for t in [1,1,2,2,3,4,4,5,5,8,8,8,8,11,11,12,12,15,17,22,23]]
def km_median(data):
    times=sorted(set(t for t,_ in data)); n=len(data); S=1.0; med=None
    for t in times:
        d=sum(1 for tt,e in data if tt==t and e==1)
        risk=sum(1 for tt,_ in data if tt>=t)
        if d>0: S*= (1-d/risk)
        if med is None and S<=0.5: med=t
    return med
# Proper Mantel-Haenszel log-rank
def logrank(g1,g2):
    times=sorted(set(t for t,e in g1+g2 if e==1))
    O1=sum(1 for t,e in g1 if e==1); E1=0.0; V=0.0
    for t in times:
        n1=sum(1 for tt,_ in g1 if tt>=t); n2=sum(1 for tt,_ in g2 if tt>=t); n=n1+n2
        d=sum(1 for tt,e in g1+g2 if tt==t and e==1)
        if n>1:
            E1+= d*n1/n
            V += d*(n1/n)*(1-n1/n)*((n-d)/(n-1))
    chi=(O1-E1)**2/V
    return chi, E1, V, O1, chi2.sf(chi,1)
# The BROKEN formula the module uses (pooled baseline split)
def broken_logrank(g1,g2):
    na,nb=len(g1),len(g2); oa=sum(e for _,e in g1); ob=sum(e for _,e in g2)
    ea=na/(na+nb)*(oa+ob); eb=nb/(na+nb)*(oa+ob)
    chi=(oa-ea)**2/ea+(ob-eb)**2/eb
    p_module=np.exp(-chi/2)   # module's wrong p-value
    return chi, np.exp(-chi/2), chi2.sf(chi,1)
chi,E1,V,O1,p = logrank(mp,pl)
print(f"PROPER log-rank: chi2={chi:.4f} (published 16.79), O1={O1}, E1={E1:.3f}, V={V:.3f}, p={p:.3e}")
bchi,bp,bp_true=broken_logrank(mp,pl)
print(f"MODULE formula:  chi2={bchi:.4f}, module_p=exp(-chi/2)={bp:.4f}, true p for that chi2={bp_true:.4f}")
print(f"KM median 6-MP={km_median(mp)} (pub 23), placebo={km_median(pl)} (pub 8)")
# Power references (normal approx, two-sample)
za=norm.ppf(1-0.025); zb=norm.ppf(0.8)
n_ttest=2*(za+zb)**2/0.5**2
print(f"t-test n/group (d=0.5,a=.05,pw=.8) normal-approx={n_ttest:.2f} (R pwr noncentral=63.77)")
p1,p2=0.5,0.65; pbar=(p1+p2)/2
n_prop=(za*np.sqrt(2*pbar*(1-pbar))+zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2/(p2-p1)**2
print(f"two-prop n/group (.5 vs .65)={n_prop:.2f}")
