/-
# Sounio.EpistemicGraphCompose — soundness of the typed epistemic graph is COMPOSITIONAL.

Mathlib-free (Lean 4 core + `Rat`). `SounioEpistemicTensorBound.lean` proves each op
(matmul, bias-add, activation) is individually sound: its runtime uncertainty stays
under the type-level bound. This file proves the structural result that makes the
WHOLE typed graph trustworthy:

  if every layer is a sound bound-transformer, then ANY network built by composing
  them maps a (runtime ≤ type) input to a (runtime ≤ type) output — end to end,
  for arbitrary depth.

A "step" is a pair of transformers `(Fr, Ft)` — `Fr` advances the runtime uncertainty
through the op, `Ft` advances the type-level bound. Soundness of a step is the
invariant-preservation property `0 ≤ r → r ≤ t → 0 ≤ Fr r ∧ Fr r ≤ Ft t` (the `0 ≤ r`
is carried because activations scale by a non-negative Lipschitz constant). The
headline `net_sound` then says: a list of sound steps composes to a sound network.

Consequence: the compile-time budget gate (`eb_within_budget` on the type-level
output) is sound for a network of ANY depth — `Ft`-composed budget ≥ `Fr`-composed
runtime uncertainty. The compiler can refuse an over-claiming GRAPH, not just an op.
-/

namespace Sounio.EpistemicGraphCompose

/-- A step `(Fr, Ft)` is SOUND if it preserves the invariant `0 ≤ r ∧ r ≤ t`:
    starting under the type bound (and non-negative), it stays under the bound. -/
def SoundStep (Fr Ft : Rat → Rat) : Prop :=
  ∀ r t : Rat, 0 ≤ r → r ≤ t → 0 ≤ Fr r ∧ Fr r ≤ Ft t

/-- Soundness is closed under composition: chaining two sound steps is sound. -/
theorem comp_sound {f1r f1t f2r f2t : Rat → Rat}
    (h1 : SoundStep f1r f1t) (h2 : SoundStep f2r f2t) :
    SoundStep (fun x => f2r (f1r x)) (fun x => f2t (f1t x)) := by
  intro r t hr hrt
  obtain ⟨hn, hle⟩ := h1 r t hr hrt
  exact h2 (f1r r) (f1t t) hn hle

/-- Run the runtime uncertainty through a network (list of steps), in order. -/
def NetRun : List ((Rat → Rat) × (Rat → Rat)) → Rat → Rat
  | [], x => x
  | s :: rest, x => NetRun rest (s.1 x)

/-- Run the type-level bound through the same network. -/
def NetType : List ((Rat → Rat) × (Rat → Rat)) → Rat → Rat
  | [], x => x
  | s :: rest, x => NetType rest (s.2 x)

/-- END-TO-END SOUNDNESS: a network of sound steps maps a (runtime ≤ type) input to
    a (runtime ≤ type) output, for arbitrary depth. The type-level budget at the
    output is therefore a sound over-approximation of the true runtime uncertainty
    of the whole network. -/
theorem net_sound :
    ∀ (steps : List ((Rat → Rat) × (Rat → Rat))) (r t : Rat),
      (∀ s ∈ steps, SoundStep s.1 s.2) → 0 ≤ r → r ≤ t →
      0 ≤ NetRun steps r ∧ NetRun steps r ≤ NetType steps t := by
  intro steps
  induction steps with
  | nil => intro r t _ hr hrt; exact ⟨hr, hrt⟩
  | cons s rest ih =>
    intro r t hall hr hrt
    have hs : SoundStep s.1 s.2 := hall s (List.mem_cons_self ..)
    obtain ⟨hn, hle⟩ := hs r t hr hrt
    have hrest : ∀ q ∈ rest, SoundStep q.1 q.2 :=
      fun q hq => hall q (List.mem_cons_of_mem s hq)
    simp only [NetRun, NetType]
    exact ih (s.1 r) (s.2 t) hrest hn hle

-- ===========================================================================
-- The ops are sound steps (non-vacuity: real layers instantiate the abstraction)
-- ===========================================================================

/-- BIAS-ADD as a sound step (variance level): runtime adds `cr`, type adds `ct`,
    with the runtime contribution within its declared bound (`cr ≤ ct`, `0 ≤ cr`). -/
theorem biasStep_sound (cr ct : Rat) (hcr : 0 ≤ cr) (hle : cr ≤ ct) :
    SoundStep (fun v => v + cr) (fun v => v + ct) := by
  intro r t hr hrt
  refine ⟨Rat.add_nonneg hr hcr, ?_⟩
  · -- r + cr ≤ t + cr ≤ t + ct
    have s1 : r + cr ≤ t + cr := (Rat.add_le_add_right (a := r) (b := t) (c := cr)).mpr hrt
    have s2 : t + cr ≤ t + ct := (Rat.add_le_add_left (a := cr) (b := ct) (c := t)).mpr hle
    exact Rat.le_trans s1 s2

/-- ACTIVATION as a sound step (uncertainty level): runtime scales by the exact
    local derivative magnitude `Lp`, type scales by the Lipschitz constant `L`
    (sigmoid ¼, relu 1), with `0 ≤ Lp ≤ L`. -/
theorem actStep_sound (Lp L : Rat) (hLp0 : 0 ≤ Lp) (hL0 : 0 ≤ L) (hLpL : Lp ≤ L) :
    SoundStep (fun u => Lp * u) (fun u => L * u) := by
  intro r t hr hrt
  refine ⟨Rat.mul_nonneg hLp0 hr, ?_⟩
  -- Lp*r ≤ L*r ≤ L*t
  exact Rat.le_trans
    (Rat.mul_le_mul_of_nonneg_right hLpL hr)
    (Rat.mul_le_mul_of_nonneg_left hrt hL0)

/-- Non-vacuity: the abstraction is INHABITED by real composed layers. For ANY
    activation (0 ≤ Lp ≤ L) followed by ANY bias-add (0 ≤ cr ≤ ct), the composed
    layer is sound — via `comp_sound` of the two proven sound steps. (`net_sound`
    lifts the same to a list of any depth.) -/
theorem demo_compose_sound (Lp L cr ct : Rat)
    (hLp0 : 0 ≤ Lp) (hL0 : 0 ≤ L) (hLpL : Lp ≤ L) (hcr : 0 ≤ cr) (hle : cr ≤ ct) :
    SoundStep (fun x => (fun v => v + cr) ((fun u => Lp * u) x))
              (fun x => (fun v => v + ct) ((fun u => L * u) x)) :=
  comp_sound (actStep_sound Lp L hLp0 hL0 hLpL) (biasStep_sound cr ct hcr hle)

end Sounio.EpistemicGraphCompose
