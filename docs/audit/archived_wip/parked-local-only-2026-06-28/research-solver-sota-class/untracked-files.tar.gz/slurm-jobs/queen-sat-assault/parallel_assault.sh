#!/usr/bin/env bash
set -euo pipefail

QUEEN_N="${1:?queen_n}"
K="${2:?k}"
CUBE_DIR="${3:?cube_dir}"
N_SEEDS="${4:-32}"
TIMEOUT="${5:-60}"
PART="${6:-all}"
NODELIST="${7:-}"
JOB_NAME="q${QUEEN_N}k${K}"

ELF="/tmp/souc_sat_ts.elf"
EDGE="/tmp/bench/queen_${QUEEN_N}.edge"
NCUBES=$(wc -l < "${CUBE_DIR}/manifest.txt")

# Runner — assumes files already extracted in cwd
cat > /tmp/runner_${JOB_NAME}.sh << 'RUNNER'
#!/usr/bin/env bash
set +e
echo "=== $(hostname) cores=$(nproc) ==="
chmod +x souc_sat_ts.elf
EDGE=$(ls queen_*.edge | head -1)

run_one() {
  cube=$1; seed=$2
  d="r_${seed}_${cube}"
  mkdir -p "$d" 2>/dev/null
  ( cd "$d" && timeout __TMO__ "../souc_sat_ts.elf" "$seed" "__K__" 3 1 "../$EDGE" "../$cube" 2>&1 | grep -q UNSAT && echo "CRACKED $cube seed=$seed" )
}
export -f run_one
export EDGE

> tasks.txt
cat manifest.txt | while read cube; do
  s=1
  while [ $s -le __NSEEDS__ ]; do
    echo "$cube $s"
    s=$((s + 1))
  done
done

cat tasks.txt | xargs -P $(nproc) -L1 bash -c 'run_one "$@"' _

echo "=== DONE ==="
RUNNER

sed -i "s/__K__/$K/g; s/__TMO__/$TIMEOUT/g; s/__NSEEDS__/$N_SEEDS/g" /tmp/runner_${JOB_NAME}.sh

PAYLOAD=$(mktemp /tmp/${JOB_NAME}_XXXX.tar.gz)
tar czf "$PAYLOAD" \
  -C /tmp "runner_${JOB_NAME}.sh" \
  -C /tmp souc_sat_ts.elf \
  -C /tmp/bench "queen_${QUEEN_N}.edge" \
  -C "$CUBE_DIR" manifest.txt $(cat "${CUBE_DIR}/manifest.txt" | tr '\n' ' ')

echo "[$JOB_NAME] ${NCUBES} cubes × ${N_SEEDS} seeds × ${TIMEOUT}s → ${PART}:${NODELIST:-any}"

NL_OPT=""
[[ -n "$NODELIST" ]] && NL_OPT="--nodelist=$NODELIST"
OUTFILE="/tmp/${JOB_NAME}_result.txt"

base64 -w0 "$PAYLOAD" | srun --partition="$PART" --time=06:00:00 \
  --exclusive --nodes=1 $NL_OPT \
  --job-name="$JOB_NAME" \
  bash -c 'cd /orangefs/training && base64 -d > p.tar.gz && tar xzf p.tar.gz && bash runner_'"${JOB_NAME}"'.sh; rm -f p.tar.gz' > "$OUTFILE" 2>&1 &

echo "[$JOB_NAME] background → $OUTFILE (PID $!)"
rm -f "$PAYLOAD"
