import Std.Tactic.BVDecide
example (a b : BitVec 8) : a + b = b + a := by bv_decide
example (x : BitVec 4) : ¬ (x &&& 0 = 1) := by bv_decide
