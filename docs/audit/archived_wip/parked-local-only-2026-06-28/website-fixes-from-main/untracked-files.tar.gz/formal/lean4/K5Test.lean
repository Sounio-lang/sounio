import Std.Tactic.BVDecide
-- K5: 5 vertices, 2 bits each (4 colors), all 10 pairs adjacent. Not 4-colorable.
-- color of vertex i = (v >>> (2*i)) &&& 3 ; edges differ <=> slices unequal.
-- Goal: no assignment makes ALL 10 edges bichromatic.
theorem k5_not_4colorable (v : BitVec 10) :
    ¬ ( (v.extractLsb' 0 2 ≠ v.extractLsb' 2 2)
      ∧ (v.extractLsb' 0 2 ≠ v.extractLsb' 4 2)
      ∧ (v.extractLsb' 0 2 ≠ v.extractLsb' 6 2)
      ∧ (v.extractLsb' 0 2 ≠ v.extractLsb' 8 2)
      ∧ (v.extractLsb' 2 2 ≠ v.extractLsb' 4 2)
      ∧ (v.extractLsb' 2 2 ≠ v.extractLsb' 6 2)
      ∧ (v.extractLsb' 2 2 ≠ v.extractLsb' 8 2)
      ∧ (v.extractLsb' 4 2 ≠ v.extractLsb' 6 2)
      ∧ (v.extractLsb' 4 2 ≠ v.extractLsb' 8 2)
      ∧ (v.extractLsb' 6 2 ≠ v.extractLsb' 8 2) ) := by
  bv_decide
-- sanity: K4 IS 4-colorable, so the analogous statement should FAIL (we won't include it
-- as a theorem; just confirming K5 proves).
