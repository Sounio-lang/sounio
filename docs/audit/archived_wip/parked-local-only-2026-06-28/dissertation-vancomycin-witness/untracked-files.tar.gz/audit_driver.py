#!/usr/bin/env python3
"""Drive verify_mcp.py over JSON-RPC stdio to audit all Erdős theorems' axiom bases.
Classifies each theorem: SORRY (violation) / MATHLIB (violation) / native_decide / core."""
import json, re, subprocess, sys, os

DISS = "/workspace/sounio-dissertation"
L = DISS + "/formal/lean4"
FILES = ["SounioErdos90UnitSpectrum", "SounioErdos90PlanarLowerBound",
         "SounioErdos90PathionGrowth", "SounioErdosUnitDistance"]

def names_of(f):
    txt = open(f"{L}/{f}.lean", encoding="utf-8", errors="replace").read()
    return re.findall(r'^\s*(?:theorem|lemma)\s+([A-Za-z0-9_\'.]+)', txt, re.M)

# spawn the MCP
p = subprocess.Popen(["python3", f"{DISS}/verify_mcp.py"], cwd=DISS,
                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
def call(msg):
    p.stdin.write(json.dumps(msg) + "\n"); p.stdin.flush()
    while True:
        line = p.stdout.readline()
        if not line: return None
        try: m = json.loads(line)
        except: continue
        if m.get("id") == msg.get("id"): return m

call({"jsonrpc":"2.0","id":0,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{}}})
p.stdin.write(json.dumps({"jsonrpc":"2.0","method":"notifications/initialized"})+"\n"); p.stdin.flush()

def classify(axioms_line):
    if "sorryAx" in axioms_line: return "❌ SORRY"
    if re.search(r'\bMathlib\.', axioms_line): return "❌ MATHLIB"
    if "native_decide" in axioms_line or "ofReduceBool" in axioms_line: return "native_decide"
    if "Classical.choice" in axioms_line: return "core+choice"
    return "core"

summary = {}
total = {"core":0,"core+choice":0,"native_decide":0,"❌ SORRY":0,"❌ MATHLIB":0,"?":0}
for i, f in enumerate(FILES, 1):
    ns = names_of(f)
    print(f"\n## {f}  ({len(ns)} results)", flush=True)
    r = call({"jsonrpc":"2.0","id":i,"method":"tools/call",
              "params":{"name":"lean_axioms","arguments":{"file":f"{f}.lean","names":ns,"timeout":900}}})
    txt = r["result"]["content"][0]["text"] if r and "result" in r else "{}"
    obj = json.loads(txt) if txt.strip().startswith("{") else {}
    rep = obj.get("axiom_report","")
    # split report into per-theorem blocks: "'<name>' depends on axioms: [...]"
    blocks = re.split(r"(?=^'[^']+' depends on axioms)", rep, flags=re.M)
    seen = {}
    for b in blocks:
        m = re.match(r"^'([^']+)' depends on axioms:\s*(.*)", b.strip(), re.S)
        if not m:
            m2 = re.match(r"^'([^']+)' does not depend on any axioms", b.strip())
            if m2: seen[m2.group(1).split('.')[-1]] = ("✅ none", b.strip()[:120])
            continue
        short = m.group(1).split('.')[-1]
        seen[short] = (classify(m.group(2)), m.group(2).strip()[:140])
    for n in ns:
        cls, detail = seen.get(n, ("?", "(no axiom line — check build errors)"))
        key = cls if cls in total else ("?" if cls!="✅ none" else "core")
        total[key if key in total else "?"] = total.get(key if key in total else "?",0)+1
        flag = "" if cls in ("native_decide","core","core+choice","✅ none") else "  <<<"
        print(f"  {cls:14} {n}{flag}", flush=True)
    if obj.get("exit") not in (0,1):
        print(f"  [build issue exit={obj.get('exit')}] {rep[:200]}", flush=True)

print("\n===== SUMMARY =====", flush=True)
for k,v in total.items():
    if v: print(f"  {k}: {v}", flush=True)
viol = total.get("❌ SORRY",0)+total.get("❌ MATHLIB",0)
print(f"\nDOCTRINE: {'CLEAN — no sorry, no mathlib across all audited theorems' if viol==0 else f'{viol} VIOLATION(S)'}", flush=True)
p.stdin.close()
