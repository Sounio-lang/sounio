#!/bin/bash
#SBATCH --job-name=SIO170-token02
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-token02/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-token02/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-token02/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C SOUNIO_STDLIB_PATH="$PWD/stdlib"
ulimit -s 524288
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO170-token02
out="$r/artifacts"
raw=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
seed=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64
trap 'printf "%s\n" "$?" > "$out/STATUS"' EXIT
printf 'phase\texit_status\n' > "$out/RESULTS.tsv"
step(){ local name=$1;shift;local rc=0;"$@" > "$out/$name.stdout" 2> "$out/$name.stderr" || rc=$?;printf '%s\t%s\n' "$name" "$rc" >> "$out/RESULTS.tsv";return "$rc"; }
build(){ local name=$1 src=$2;step "$name.check" "$raw" check "$src";step "$name.compile" "$raw" compile "$src" -o "$out/$name.elf";chmod +x "$out/$name.elf"; }
run(){ local name=$1 elf=$2;step "$name.native" /usr/bin/time -f 'elapsed_seconds=%e\nmax_rss_kib=%M\nexit_code=%x' -o "$out/$name.resource" timeout 180 "$elf"; }
sha256sum "$raw" "$seed" > "$out/COMPILERS.sha256"
sha256sum stdlib/genomics/io/count_tsv.sio tests/stdlib/genomics_counts/token_main.sio tests/stdlib/genomics_counts/token_bench.sio tests/reference/genomics_token_reference.cpp tests/reference/count_tsv_reference.cpp "$r/before/genomics/io/count_tsv.sio" > "$out/INPUTS.sha256"
step cpp-existing.build g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/count_tsv_reference.cpp -o "$out/existing-reference"
step cpp-token.build g++ -std=c++23 -O2 -Wall -Wextra -Werror tests/reference/genomics_token_reference.cpp -o "$out/reference"
step exact-summary "$out/existing-reference"
step fixture-existing "$out/existing-reference" --fixture
step fixture-before "$out/reference" --adapt "$out/fixture-existing.stdout" legacy
step fixture-after "$out/reference" --adapt "$out/fixture-existing.stdout" into
SOUNIO_STDLIB_PATH="$r/before" build before "$out/fixture-before.stdout"
run before "$out/before.elf"
step before.reference "$out/reference" --check "$out/exact-summary.stdout" "$out/before.native.stdout"
build after "$out/fixture-after.stdout"
run after "$out/after.elf"
step after.reference "$out/reference" --check "$out/exact-summary.stdout" "$out/after.native.stdout"
step protocol-byte-identical cmp "$out/before.native.stdout" "$out/after.native.stdout"
build slot tests/stdlib/genomics_counts/token_main.sio;run slot "$out/slot.elf"
step slot.complete grep -Fx TOKEN_SLOT_PASS "$out/slot.native.stdout"
step seed-slot.compile "$seed" tests/stdlib/genomics_counts/token_main.sio "$out/seed-slot.elf";chmod +x "$out/seed-slot.elf"
run seed-slot "$out/seed-slot.elf"
step seed-slot.complete grep -Fx TOKEN_SLOT_PASS "$out/seed-slot.native.stdout"
step seed-protocol.compile "$seed" "$out/fixture-after.stdout" "$out/seed-protocol.elf";chmod +x "$out/seed-protocol.elf"
run seed-protocol "$out/seed-protocol.elf"
step seed-protocol.reference "$out/reference" --check "$out/exact-summary.stdout" "$out/seed-protocol.native.stdout"
awk 'NR==1{$4=99} {print}' "$out/after.native.stdout" > "$out/protocol-mutant.input.stdout"
! cmp -s "$out/protocol-mutant.input.stdout" "$out/after.native.stdout"
rc=0;step protocol-mutant "$out/reference" --check "$out/exact-summary.stdout" "$out/protocol-mutant.input.stdout" || rc=$?
[[ $rc == 8 ]];grep -Fxq 'token protocol status/position/rows' "$out/protocol-mutant.stderr"
grep -v '^GENOMICS_COUNT_TSV_PASS$' "$out/after.native.stdout" > "$out/completion-mutant.input.stdout"
rc=0;step completion-mutant "$out/reference" --check "$out/exact-summary.stdout" "$out/completion-mutant.input.stdout" || rc=$?
[[ $rc == 9 ]];grep -Fxq 'token completion' "$out/completion-mutant.stderr"
printf 'tokens\tposition\tvariant\n' > "$out/ORDER.tsv"
for n in 100000 1000000;do
 for variant in before after;do
  if [[ $variant == before ]];then parser="$r/before/genomics/io/count_tsv.sio";decl='';feed='let reply=count_tsv_feed(\&!state,\&bytes,1);assert(reply.status==0 \&\& reply.consumed==1)';finish='let eof=count_tsv_finish(\&!state);assert(eof.status==0 \&\& eof.finished)'
  else parser=stdlib/genomics/io/count_tsv.sio;decl='var slot=count_tsv_feed_slot()';feed='let reply:i64=count_tsv_feed_into(\&!state,\&bytes,1,\&!slot);assert(reply==0 \&\& slot.consumed==1)';finish='let eof:i64=count_tsv_finish_into(\&!state,\&!slot);assert(eof==0 \&\& slot.finished)';fi
  cat "$parser" > "$out/bench-$n-$variant.sio"
  sed -e "s/TOKEN_SLOT_DECL/$decl/" -e "s/TOKEN_COUNT/$n/" -e "s/TOKEN_FEED/$feed/" -e "s/TOKEN_FINISH/$finish/" tests/stdlib/genomics_counts/token_bench.sio >> "$out/bench-$n-$variant.sio"
  build "bench-$n-$variant" "$out/bench-$n-$variant.sio"
 done
 pos=0
 for variant in before after after before;do
  pos=$((pos+1));printf '%s\t%s\t%s\n' "$n" "$pos" "$variant" >> "$out/ORDER.tsv"
  name="bench-$n-$pos-$variant"
  run "$name" "$out/bench-$n-$variant.elf"
  step "$name.reference" "$out/reference" --bench "$n" "$out/$name.native.stdout"
 done
 step "bench-$n.same-outputs" cmp "$out/bench-$n-1-before.native.stdout" "$out/bench-$n-2-after.native.stdout"
done
step inputs-unchanged sha256sum -c "$out/INPUTS.sha256"
