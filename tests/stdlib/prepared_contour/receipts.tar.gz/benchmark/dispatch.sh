#!/bin/bash
set -uo pipefail
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-bench04
export MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready
export SOUC_BIN="$MADAROS_RAW_BIN" SOUNIO_MADAROS_NOCACHE=1 SOUNIO_MADAROS_CACHE_READONLY=1 SOUNIO_MADAROS_CACHE="$r/cache" TMPDIR="$r/tmp"
ulimit -s 524288
sha256sum "$MADAROS_RAW_BIN" > "$r/artifacts/COMPILER.sha256"
cd "$r";find before after -type f -print0 | sort -z | xargs -0 sha256sum > "$r/artifacts/INPUTS.sha256"
printf 'phase\tsource\texit_status\n' > "$r/artifacts/RESULTS.tsv"
fail=0
rc=0;g++ -std=c++23 -O2 "$r/after/tests/stdlib/prepared_contour/prepared_contour_bench_reference.cpp" -o "$r/artifacts/bench-reference" > "$r/artifacts/bench-reference.compile.log" 2>&1 || rc=$?
printf 'cpp-build\tbench-reference\t%s\n' "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || exit 1
for side in 256 1024;do
 for variant in before after;do
  cd "$r/$variant";export SOUNIO_STDLIB_PATH="$PWD/stdlib";source scripts/lib/resolve_souc.sh;sounio_require_souc
  rc=0;timeout 120 "$SOUC_BIN" check "bench-$side.sio" > "$r/artifacts/$variant-$side.check.log" 2>&1 || rc=$?
  printf 'check\t%s-%s\t%s\n' "$variant" "$side" "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || { fail=1;continue; }
  rc=0;timeout 120 "$SOUC_BIN" compile "bench-$side.sio" -o "$r/artifacts/$variant-$side.elf" > "$r/artifacts/$variant-$side.compile.log" 2>&1 || rc=$?
  printf 'compile\t%s-%s\t%s\n' "$variant" "$side" "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || { fail=1;continue; }
  chmod +x "$r/artifacts/$variant-$side.elf";sha256sum "$r/artifacts/$variant-$side.elf" > "$r/artifacts/$variant-$side.elf.sha256"
 done
 for pair in 1 2 3;do
  order='before after';[[ $pair != 2 ]] || order='after before'
  for variant in $order;do
   label="$side-pair$pair-$variant"
   [[ -x $r/artifacts/$variant-$side.elf ]] || continue
   cd "$r/$variant";export SOUNIO_STDLIB_PATH="$PWD/stdlib"
   rc=0;/usr/bin/time -f 'elapsed_seconds=%e\nmax_rss_kib=%M\nexit_code=%x' -o "$r/artifacts/$label.resource" timeout 180 "$r/artifacts/$variant-$side.elf" > "$r/artifacts/$label.stdout" 2> "$r/artifacts/$label.stderr" || rc=$?
   printf 'native\t%s\t%s\n' "$label" "$rc" >> "$r/artifacts/RESULTS.tsv"
   if [[ $rc == 0 ]];then
    rc=0;"$r/artifacts/bench-reference" "$side" "$r/artifacts/$label.stdout" > "$r/artifacts/$label.cpp.stdout" 2> "$r/artifacts/$label.cpp.stderr" || rc=$?
    printf 'cpp\t%s\t%s\n' "$label" "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || fail=1
   elif [[ $variant == after ]];then fail=1;fi
  done
 done
done
cd "$r";rc=0;sha256sum -c "$r/artifacts/INPUTS.sha256" > "$r/artifacts/INPUTS.verify" 2>&1 || rc=$?
printf 'integrity\tinputs\t%s\n' "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || fail=1
printf '%s\n' "$fail" > "$r/artifacts/STATUS";exit "$fail"
