#!/bin/bash
#SBATCH --job-name=SIO175-bench04
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-bench04
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-bench04/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-bench04/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C bash /scratch/sounio-stdlib-inference-scale-20261024/SIO175-bench04/dispatch.sh
