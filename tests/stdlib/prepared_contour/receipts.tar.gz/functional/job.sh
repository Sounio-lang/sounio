#!/bin/bash
#SBATCH --job-name=SIO175-full06
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-full06/source
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-full06/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-full06/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready SOUNIO_SEED_COMPILER=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64 bash scripts/stdlib/prepared_contour_gate.sh /scratch/sounio-stdlib-inference-scale-20261024/SIO175-full06/gate
