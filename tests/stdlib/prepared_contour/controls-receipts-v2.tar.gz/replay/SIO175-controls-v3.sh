#!/bin/bash
set -euo pipefail
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO175-controls-v3
[[ ! -e $r ]];mkdir -p "$r"/{source,artifacts,logs,tmp,cache}
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- bash -c 'cd /workspace/sounio-SIO-175-prepared-contours && tar -cf - stdlib bin/souc bin/madaros scripts/lib scripts/stdlib/prepared_contour_gate.sh tests/run-pass/viz_prepared_contour.sio tests/run-pass/stdlib_deep_viz_dynamic_contour.sio tests/run-pass/stdlib_deep_viz_contour_predicate.sio tests/reference/prepared_contour_reference.cpp tests/reference/deep_viz_dynamic_contour.cpp tests/reference/deep_viz_contour_predicate.cpp tests/stdlib/prepared_contour' | tar -xf - -C "$r/source"
printf '%s\n' add422559036ca4ec488fd8880267a8a99141e3a > "$r/SOURCE_HEAD"
cat > "$r/job.sh" <<J
#!/bin/bash
#SBATCH --job-name=SIO175-controls-v3
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=$r/source
#SBATCH --output=$r/logs/slurm-%j.out
#SBATCH --error=$r/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready SOUNIO_SEED_COMPILER=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64 bash scripts/stdlib/prepared_contour_gate.sh $r/gate
J
chown -R 1000:1000 "$r"
kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- sbatch "$r/job.sh" > "$r/SUBMISSION.txt";cat "$r/SUBMISSION.txt"
