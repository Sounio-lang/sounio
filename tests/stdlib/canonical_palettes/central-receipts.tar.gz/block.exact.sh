# Canonical palette primary data, actual Canvas/SVG colors and strict controls.
rc=0
MADAROS_RAW_BIN="$MADAROS_RAW_BIN" bash scripts/stdlib/canonical_palette_gate.sh "$out/canonical-palettes" > "$out/canonical-palettes.gate.stdout" 2> "$out/canonical-palettes.gate.stderr" || rc=$?
record focused-gate canonical-palettes "$rc"

