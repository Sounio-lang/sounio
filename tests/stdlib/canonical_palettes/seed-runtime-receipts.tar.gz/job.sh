#!/bin/bash
#SBATCH --job-name=SIO176-seed-run
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:05:00
#SBATCH --export=NIL
#SBATCH --output=/scratch/sounio-stdlib-inference-scale-20261024/SIO176-seed-runtime01/logs/slurm-%j.out
#SBATCH --error=/scratch/sounio-stdlib-inference-scale-20261024/SIO176-seed-runtime01/logs/slurm-%j.err
set -euo pipefail
export PATH=/usr/bin:/bin LANG=C LC_ALL=C
ulimit -s 524288
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO176-seed-runtime01
b=/scratch/sounio-stdlib-inference-scale-20261024/SIO176-full07
cd "$b/source"
printf 'phase\texit_status\n' > "$r/RESULTS.tsv"
phase(){ local label=$1;shift;local rc=0;"$@" > "$r/$label.stdout" 2> "$r/$label.stderr" || rc=$?;printf '%s\t%s\n' "$label" "$rc" >> "$r/RESULTS.tsv";return "$rc"; }
trap 'printf "%s\n" "$?" > "$r/STATUS"' EXIT
sha256sum "$b/gate/strict-seed.elf" "$b/gate/reference" "$b/gate/png-decoder" "$b/gate/canvas-export" > "$r/BINARIES.sha256"
cp "$b/gate/SEED_COMPILER.sha256" "$r/SEED_COMPILER.sha256"
cp "$b/gate/INPUTS.sha256" "$r/INPUTS.sha256"
chmod +x "$b/gate/strict-seed.elf"
phase seed-native /usr/bin/time -f 'elapsed_seconds=%e\nmax_rss_kib=%M\nexit_code=%x' -o "$r/seed-native.resource" timeout 120 "$b/gate/strict-seed.elf"
phase figure-concordance "$b/gate/reference" --figure tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt "$r/seed-native.stdout" "$r/actual-canvas.ppm"
phase canvas-export "$b/gate/canvas-export" "$r/actual-canvas.ppm.rle" "$r/roundtrip.ppm" "$r/actual-canvas.png"
phase lossless cmp "$r/actual-canvas.ppm" "$r/roundtrip.ppm"
phase png-native-primary "$b/gate/png-decoder" tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt tests/reference/data/font8x8_basic.h "$r/seed-native.stdout" "$r/actual-canvas.png" "$r/actual-canvas.ppm"
phase inputs-unchanged sha256sum -c "$r/INPUTS.sha256"
sha256sum "$r/seed-native.stdout" "$r/actual-canvas.png" > "$r/OUTPUTS.sha256"
