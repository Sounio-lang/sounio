#!/bin/bash
set -euo pipefail
base=/scratch/sounio-stdlib-inference-scale-20261024
r=$base/SIO176-image-isolated01
[[ ! -e $r ]];mkdir -p "$r"/{artifacts,logs}
[[ $(cat "$base/SIO176-full04/gate/STATUS") == 0 ]]
cat > "$r/dispatch.sh" <<'D'
#!/bin/bash
set -euo pipefail
base=/scratch/sounio-stdlib-inference-scale-20261024
r=$base/SIO176-image-isolated01
cd "$base/SIO176-full04/source"
reference=$base/SIO176-full04/gate/reference
exporter=$base/SIO176-full04/gate/canvas-export
positive=$base/SIO176-full03/gate/viz_canonical_palettes.native.stdout
sha256sum "$reference" "$exporter" "$positive" tests/reference/canonical_palette_reference.cpp tests/reference/scientific_canvas_export.cpp tests/reference/data/font8x8_basic.h tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt > "$r/artifacts/INPUTS.sha256"
trap 'rc=$?;printf "%s\n" "$rc" > "$r/artifacts/STATUS"' EXIT
"$reference" --figure tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt "$positive" "$r/artifacts/isolated-positive.ppm" > "$r/artifacts/reference.stdout" 2> "$r/artifacts/reference.stderr"
"$exporter" "$r/artifacts/isolated-positive.ppm.rle" "$r/artifacts/roundtrip.ppm" "$r/artifacts/isolated-positive.png" > "$r/artifacts/export.stdout" 2> "$r/artifacts/export.stderr"
cmp "$r/artifacts/isolated-positive.ppm" "$r/artifacts/roundtrip.ppm"
cmp "$r/artifacts/isolated-positive.ppm" "$base/SIO176-full03/gate/actual-canvas.ppm"
sha256sum -c "$r/artifacts/INPUTS.sha256" > "$r/artifacts/INPUTS.verify"
sha256sum "$r/artifacts/isolated-positive.ppm" "$r/artifacts/isolated-positive.png" > "$r/artifacts/OUTPUTS.sha256"
printf '%s\n' 'ISOLATED_POSITIVE_IMAGE_PASS post_mutants=true native_stdout_unmodified=true ppm_roundtrip_equal=true prior_ppm_equal=true' > "$r/artifacts/RESULT.txt"
D
cat > "$r/job.sh" <<J
#!/bin/bash
#SBATCH --job-name=SIO176-image-isolated
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=1024M
#SBATCH --time=00:02:00
#SBATCH --export=NIL
#SBATCH --output=$r/logs/slurm-%j.out
#SBATCH --error=$r/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C bash $r/dispatch.sh
J
chown -R 1000:1000 "$r"
kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- sbatch "$r/job.sh" > "$r/SUBMISSION.txt";cat "$r/SUBMISSION.txt"
