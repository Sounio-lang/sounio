#!/bin/bash
set -euo pipefail
base=/scratch/sounio-stdlib-inference-scale-20261024
r=$base/SIO176-png-decode01
[[ ! -e $r ]];mkdir -p "$r"/{artifacts,logs}
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- cat /workspace/sounio-SIO-176-canonical-palettes/tests/stdlib/canonical_palettes/png_decode_reference.cpp > "$r/source.cpp"
cp /tmp/SIO176-sips-bad.png "$r/sips-derived-observed-bad.png"
cat > "$r/dispatch.sh" <<'D'
#!/bin/bash
set -uo pipefail
base=/scratch/sounio-stdlib-inference-scale-20261024
r=$base/SIO176-png-decode01
cd "$base/SIO176-full04/source"
printf 'phase\texit_status\n' > "$r/artifacts/RESULTS.tsv"
fail=0;rc=0
g++ -std=c++23 -O2 -Wall -Wextra "$r/source.cpp" -l:libz.so.1 -o "$r/decoder" > "$r/artifacts/build.stdout" 2> "$r/artifacts/build.stderr" || rc=$?
printf 'cpp-build\t%s\n' "$rc" >> "$r/artifacts/RESULTS.tsv";[[ $rc == 0 ]] || exit 1
positive=$base/SIO176-full03/gate/viz_canonical_palettes.native.stdout
primary=tests/reference/data/canonical_palettes/BIDS-colormaps.py.txt
font=tests/reference/data/font8x8_basic.h
for name in direct isolated sips;do
 case "$name" in direct) png=$base/SIO176-full04/gate/actual-canvas.png;ppm=$base/SIO176-full04/gate/actual-canvas.ppm;;isolated)png=$base/SIO176-image-isolated01/artifacts/isolated-positive.png;ppm=$base/SIO176-image-isolated01/artifacts/isolated-positive.ppm;;sips)png=$r/sips-derived-observed-bad.png;ppm=$base/SIO176-full03/gate/actual-canvas.ppm;;esac
 rc=0;"$r/decoder" "$primary" "$font" "$positive" "$png" "$ppm" > "$r/artifacts/$name.stdout" 2> "$r/artifacts/$name.stderr" || rc=$?
 printf '%s\t%s\n' "$name" "$rc" >> "$r/artifacts/RESULTS.tsv"
 if [[ $name != sips && $rc != 0 ]];then fail=1;fi
 sha256sum "$png" "$ppm" > "$r/artifacts/$name.INPUTS.sha256"
done
sha256sum "$r/source.cpp" "$r/decoder" "$positive" "$primary" "$font" /lib/x86_64-linux-gnu/libz.so.1 > "$r/artifacts/INPUTS.sha256"
printf '%s\n' "$fail" > "$r/artifacts/STATUS";exit "$fail"
D
cat > "$r/job.sh" <<J
#!/bin/bash
#SBATCH --job-name=SIO176-png-decode
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=1024M
#SBATCH --time=00:03:00
#SBATCH --export=NIL
#SBATCH --output=$r/logs/slurm-%j.out
#SBATCH --error=$r/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C bash $r/dispatch.sh
J
chown -R 1000:1000 "$r"
kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- sbatch "$r/job.sh" > "$r/SUBMISSION.txt";cat "$r/SUBMISSION.txt"
