#!/bin/bash
set -euo pipefail
r=/scratch/sounio-stdlib-inference-scale-20261024/SIO176-full06
[[ ! -e $r ]];mkdir -p "$r"/{source,logs}
kubectl -n beagle exec sounio-workspace-control-0 -c workspace-ssh -- bash -c 'cd /workspace/sounio-SIO-176-canonical-palettes && tar -cf - stdlib bin/souc bin/madaros scripts/lib scripts/stdlib/canonical_palette_gate.sh tests/run-pass/viz_canonical_palettes.sio tests/run-pass/stdlib_deep_viz_dynamic_fields.sio tests/reference/canonical_palette_reference.cpp tests/reference/deep_viz_dynamic_fields.cpp tests/reference/data/canonical_palettes tests/reference/data/font8x8_basic.h tests/reference/scientific_canvas_export.cpp tests/stdlib/canonical_palettes' | tar -xf - -C "$r/source"
printf '%s\n' c21b0e139830ca4949f80cba62887a8922a972d7 > "$r/SOURCE_HEAD"
cat > "$r/job.sh" <<J
#!/bin/bash
#SBATCH --job-name=SIO176-full06
#SBATCH --partition=cpu-ops
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4096M
#SBATCH --time=00:15:00
#SBATCH --export=NIL
#SBATCH --chdir=$r/source
#SBATCH --output=$r/logs/slurm-%j.out
#SBATCH --error=$r/logs/slurm-%j.err
exec env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C MADAROS_RAW_BIN=/scratch/sounio-stdlib-inference-scale-20261024/compiler_ci_c21/madaros.elf.ready SOUNIO_SEED_COMPILER=/scratch/sounio-stdlib-inference-scale-20261024/SIO166/source14/bin/souc-lean-single-x86_64 bash scripts/stdlib/canonical_palette_gate.sh $r/gate
J
chown -R 1000:1000 "$r"
kubectl -n slurm-pilot exec slurm-pilot-worker-cpuops-4pvxd -c slurmd -- runuser -u sounio -- sbatch "$r/job.sh" > "$r/SUBMISSION.txt";cat "$r/SUBMISSION.txt"
